# 环境配置：需要按你的环境修改的地方

脚本是在一台具体的 G1-D、一台具体的 GPU 服务器上边做边写的，很多主机、路径、端口直接写在代码里。本文列出全部写死的值、出现在哪些文件、怎么改。

打包时做过的替换（只改了工具包里的副本）：
- GPU 服务器上的个人 conda 路径换成环境变量：shell 脚本用 `${ISAAC_ENV:?...}`（没设置会直接报错退出），`build_assembly.py` 和 `make_urdf_variants.py` 用 `ISAAC_PY`（默认值 `<ISAAC_ENV>/bin/python` 是占位符，不设置会报"文件不存在"）。
- 文档里的 GPU 服务器主机名换成 `<GPU_SERVER>`；`extras/diagnostics/` 两个脚本里的个人 Windows 路径换成环境变量 `PC_TOOLS_DIR`。
- 其余路径（`/root/unitree_sim_isaaclab/...`、`/home/unitree/...`、`/dev/shm/...`）保持原样，按下表修改。

## 1. 网络与连接

| 项 | 本机值 | 出现位置 | 怎么改 |
|---|---|---|---|
| 机器人 SSH 别名 | `unitree` | `pc/arm_client.py`（`ssh unitree <cmd>`）、所有文档命令 | 在 PC 的 `~/.ssh/config` 里配置 `Host unitree`（HostName 192.168.123.164，User unitree，免密钥登录）。本包不含任何 SSH 配置或密钥 |
| 机器人 IP | `192.168.123.164` | `pc/` 下的 `capture_intrinsics.py`、`check_wrist_view.py`、`dircheck.py`、`locate_board.py`、`pull_frames.py`、`which_wrist_cam.py` 的 `HOST`；机器人本机脚本用 `127.0.0.1` | 改 `HOST` 常量 |
| PC 在机器人网段的 IP | `192.168.123.22`（静态） | 无（信息） | — |
| 运动控制板 | `192.168.123.161` | 无（信息） | — |
| GPU 服务器 | `<GPU_SERVER>` | 只在文档里 | 用你自己的 SSH 配置；服务器端脚本都在服务器本机运行，不需要知道主机名 |

## 2. 机器人端

### 2.1 DDS 与控制

| 项 | 值 | 出现位置 |
|---|---|---|
| DDS 网卡 | `ChannelFactoryInitialize(0, "eth0")`（域 0） | `calib_arm_server.py`、`calib_ready_pose.py`、`peek_lowstate.py`、`check_lowcmd_free.py` |
| 话题 | `rt/lowcmd`（发布）、`rt/lowstate`（订阅），unitree_hg IDL，35 个电机 | 同上 |
| 发布频率 | 250 Hz（`CONTROL_DT = 1/250`） | `calib_arm_server.py`、`calib_ready_pose.py` |
| 电机序号 | 左臂 15–21、右臂 22–28（pitch, roll, yaw, elbow, wrist_roll, wrist_pitch, wrist_yaw），腰 yaw 12 | 同上；`examples/joint_mapping.json` |
| kp / kd | 手臂非腕关节 80 / 3，腕 40 / 1.5，腰 100 / 2，电机 4、10 为 80 / 3，其余 300 / 3；`mode_pr=0`、`mode=1` | `calib_arm_server.py` 开头常量 |
| 安全参数 | 限位余量 0.05 rad、单步 ≤ 1.6 rad、jog ≤ 0.1 rad、跟踪误差锁定 0.2 rad、断流 0.5 s、`--vmax` 默认 0.1 rad/s | `calib_arm_server.py` |
| 关节限位 | URDF 值写死在 `LIMITS` 数组 | `calib_arm_server.py` |

`rt/lowstate` 只有在遥控器进入调试模式（`L2+R2`）后才发布。10-15 曾经整天读不到状态，第二天自行恢复，原因不明（疑似运控服务卡死后被重启）。

### 2.2 相机（ZMQ）

相机由 Unitree 的系统服务 `teleimager` 通过 pyuvc 打开并以 ZMQ PUB 推 JPEG（机器人上没有 `/dev/video*`）。客户端用 SUB + `CONFLATE`，丢掉前两条消息再取图。

| 端口 | 相机 | 格式 |
|---|---|---|
| 55555 | 头部双目 | 1280×480 左右拼接，**左半 = head_left**，右半 = head_right；定焦 |
| 55557 | **左腕** | 640×480 @ 30 fps；自动对焦关不掉 |
| 55556 | **右腕** | 640×480 @ 30 fps；自动对焦关不掉 |

**左右腕端口是 10-16 实测得到的**（微动左手腕 yaw 时 55557 的画面在动），同事仓库 g1d_infra 的相机配置把它们写反了。换机器人时先用 `pc/which_wrist_cam.py` 复查。写死在：`robot/collect_robot.py`、`robot/auto_touch.py`、`robot/repeat_test.py`（`WRIST_PORT`）、`pc/capture_intrinsics.py`、`pc/pull_frames.py`、`pc/dircheck.py`（`CAMS` / `PORTS`）。

### 2.3 路径

| 路径 | 用途 | 出现位置 | 怎么改 |
|---|---|---|---|
| `/home/unitree/miniconda3/envs/tv/bin/python` | conda 环境 `tv` 的 python | `robot/*.sh` 的 `PY=` | 改每个 `.sh` 的 `PY=` |
| `~/calib_sessions/` | 脚本、日志（`queue.log`、`touch_queue.log`）、停止文件（`STOP`、`STOP_TOUCH`）、会话目录（`calib_*`、`touch_auto_*`、`repeat_*`） | robot 下所有 `.py` 的 `BASE`/`POSES`，`.sh` 的 `B=`/`cd` | 改 `BASE` 常量和 `.sh` 里的目录 |
| `~/calib_sessions/model/` | `calib_model.py` + `g1_d_upper_dex1_v4.urdf` + `camera_contract_v5.json`；`auto_touch.py` 把 `G1D_CALIB_NOMINAL` 设为这里 | `auto_touch.py`、`pc/touch_plan.py` | 同上 |
| `~/calib_sessions/intrinsics/` | 头部内参 JSON（只有 `locate_board_robot.py` 读） | `locate_board_robot.py` | 改 `HERE / "intrinsics"` |
| `~/calib_sessions/poses_20261019/` | 姿态表 + `scene_header_B.json`（腕相机内参也从这里读） | `collect_robot.py`、`auto_touch.py`、`go_home.py`、`recover.py`、`contact_point.py`、`repeat_test.py`、`repeat_analyze.py` | 保持目录名，或改 7 处 `POSES` |
| `/home/unitree/g1d_infra_calib/scripts/` | `calib_arm_server.py` 所在目录（原机器人上是同事仓库的 worktree） | `start_server.sh`、`takeover2.sh` 的 `cd`；`pc/arm_client.py` 注释 | 改两行 `cd`，例如改成 `~/calib_sessions` |
| `/tmp/g1d_calib/` | `cmd.json`、`status.json`、`init_pose.json`、`collector.lock.d/` | 服务、所有客户端 | 一般不用改（重启后自动重建） |
| `/tmp/g1d_calib_server.log`、`/tmp/g1d_calib_server_new.log` | 服务日志 | `start_server.sh`、`takeover2.sh` | — |
| `/home/unitree/g1d_infra/configs/ready_pose.json` | `calib_ready_pose.py --pose` 的默认值（同事仓库里的文件） | `robot/calib_ready_pose.py`、`extras/legacy/takeover.sh` | 用 `--pose 你的文件.json`（格式 `{"arm_q": [14 个值]}`） |

### 2.4 写死的实验参数

| 参数 | 值 | 出现位置 |
|---|---|---|
| 标定板 | `CharucoBoard((10, 7), 0.040, 0.030, DICT_4X4_50)`，板面有效区 0.40 × 0.28 m | `collect_robot.py`、`auto_touch.py`、`contact_point.py`、`repeat_*.py`、`det_test.py`、`export_meas.py`、`gen_poses.py`、`locate_board.py`、`board_timeline.py` 等 |
| 板漂移中止阈值 | 4 mm | `collect_robot.py` `BOARD_DRIFT_MAX` |
| 指尖像素 | 左腕 (309, 255)，右腕 (330, 265) | 命令行 `--tip-u/--tip-v`；`touch_queue.sh` 的 `COMMON` |
| 指尖深度初值 | 0.100 m | `touch_queue.sh`；`auto_touch.py` 默认 0.16（故意偏长） |
| 腕相机焦距系数 | 0.963（辨识得到的焦距 / 内参标定焦距） | `auto_touch.py --fx-scale` 默认值、`pc/touch_plan.py` |
| 触碰参数 | 步长 1.5 mm、快速接近停在 3 cm 前、退回 1 cm、旋转 15°、入射角 ≤ 35°、板边余量 6 cm、居中平移 ≤ 12 cm | `auto_touch.py` 开头常量 |
| 躯干护栏 | 左肩 roll：身侧 ≥ +0.05、身前（pitch < −0.4）≥ −0.10；右臂取反 | `auto_touch.py` `torso_ok` |
| 触碰队列内容 | 姿态 013/033/034/036、偏移 ±4 cm | `touch_queue.sh` |

## 3. GPU 服务器端

### 3.1 Python 环境

| 环境 | 用途 | 怎么设置 |
|---|---|---|
| `$ISAAC_ENV`（unitree_sim_env：Isaac Lab + IsaacSim 5.1，含 numpy/scipy/trimesh/coal） | 辨识、姿态表、触碰辨识、渲染 | `export ISAAC_ENV=/path/to/unitree_sim_env`；`export ISAAC_PY=$ISAAC_ENV/bin/python` |
| `/usr/bin/python3` + opencv | `export_meas.py`、`dircheck_analyze.py`、`overlay_isaaclab.py`、`compare_overlay.py`、`inspect_identify.py` | 系统 python，装 `opencv-contrib-python` |

渲染脚本还用到：`LD_PRELOAD=$ENV/lib/libstdc++.so.6`、`OMNI_KIT_ACCEPT_EULA=YES`、`TMPDIR=/dev/shm/tmp`、`CUDA_VISIBLE_DEVICES=$GPU`、`--kit_args "--/renderer/activeGpu=$GPU ..."`（见 `run_render_*.sh`）。

### 3.2 路径

| 路径 | 用途 | 出现位置 | 怎么改 |
|---|---|---|---|
| `/root/unitree_sim_isaaclab` | 服务器项目根目录 | `calib_model.py` 的 `ROOT` | 改 `ROOT`，或只用环境变量 `G1D_CALIB_NOMINAL` 指定名义资产 |
| `.../real2sim_g1d_20261015/assembled/` | 名义资产（URDF + **meshes**），`calib_model.NOMINAL` 默认值 | `calib_model.py`、`build_assembly.py`、`tools/`、`server_check_assets.sh` | `export G1D_CALIB_NOMINAL=<含 URDF/meshes/contract 的目录>` |
| `.../real2sim_calib_20261015/`（下称 `R`） | 标定包本体；`real_data/20261016/{intrinsics,poses,sessions,body_overlay}`、`real_data/20261019/{poses_v2,sessions,touch,repeat}`；渲染资产 `assembled_calib_20261016/`（含 meshes）；`scratch/urdf_variants_20261019/` | `server/tools/` 多数脚本（`ROOT`、`DAY`、`R`、`S` 常量）、`server/runs/*.sh` | 改脚本开头的常量；日期目录按你的数据改 |
| `.../real2sim_calib_20261015_realcam/` | 注入真实内参的标定包副本（`inject_real_intrinsics_patch.py` 生成） | `gen_poses.py`、`touch_identify_auto.py`、`dircheck_analyze.py`、`repeat_diff.py`、`plan_jog_signs.py`、`pose_clearance.py`、`estimate_wrist_extrinsic.py`、`eval_layout.py`、`find_dircheck_pose.py`、`zero_pose_height.py`、`dump_head_cam_T.py`、`body_overlay.py` 的 `sys.path.insert`；`server/runs/*.sh` 的 `cd` | 改 `REALCAM` / `sys.path.insert` 那一行 |
| `/dev/shm/isaac_work/` | 临时工作目录：上传的脚本、`board_pose.json`（`gen_poses.py --board-json` 默认值）、`usd_conv*/`、渲染输出 | `gen_poses.py`、`eval_layout.py`、`render_*.py`、`run_*.sh`、`server/runs/*.sh` | `/dev/shm` 重启即清空；根盘有空间时可以换成持久目录 |
| `/dev/shm/tmp` | `TMPDIR` | `run_render_*.sh` | 同上 |
| `.../codex_pour/g1d_probe/` | 另一个项目的 Isaac 流程（只读参考；`tools/` 里的资产转换脚本会 import） | `server/g1d_calib_20261015/tools/*`、渲染脚本注释 | 只在 `build_assembly.py` 流程里需要 |

### 3.3 GPU

- 渲染默认 `GPU=${GPU:-4}`（当时 4 号卡空闲）；运行前 `nvidia-smi` 选空闲卡，用 `GPU=<N>` 覆盖。
- `build_assembly.py --gpu <N>`。

### 3.4 写死的几何

- `pc/locate_board.py`、`pc/board_timeline.py`、`pc/table_edge.py` 里写死了头部左右目在躯干系的位姿（`R_HEAD`、`t`），来自 `camera_contract_v5` + URDF FK（头部和躯干之间没有关节）。头部外参变了要用 `server/tools/dump_head_cam_T.py` 重算后替换。
- `server/tools/plan_jog_signs.py` 写死了方向检查用的准备位姿 `READY` 和桌面高度。

## 4. PC 端（Windows）

| 项 | 说明 |
|---|---|
| 内参目录 | `pc/calib_data/intrinsics/`：`capture/calibrate/validate_intrinsics.py` 写，`locate_board.py`、`board_timeline.py`、`table_edge.py` 读头部内参。直接用这台机器人的结果时，把 `examples/intrinsics/*.json` 拷进去 |
| 姿态表 | `pc/touch_plan.py` 在 PC 上运行时读 `pc/frames_test/poses_v2/`（把 `examples/poses_20261019/*` 拷进去） |
| 方向检查计划 | `pc/dircheck.py` 读 `pc/frames_test/dircheck/dircheck_plan.json` |
| 标定包位置 | `pc/validate_intrinsics.py`、`pc/touch_plan.py` 按原工作区布局找 `<pc>/../g1d_calib_20261015/g1d_calib_20261015`；本包里在 `server/g1d_calib_20261015`。改 `PKG = ...` 那一行为 `Path(__file__).resolve().parent.parent / "server" / "g1d_calib_20261015"` |
| Windows 专用 | `capture_intrinsics.py`、`extras/diagnostics/show_board.py` 用了 `ctypes.windll` 和 OpenCV 窗口 |
| 中文路径 | `cv2.imwrite` / `cv2.imread` 不支持中文路径，脚本用 `cv2.imencode(...)[1].tofile(...)` 和 `np.fromfile` + `cv2.imdecode` |
| PC 直连 DDS（可选） | `pc/sub_lowstate.py` 需要 Python 3.12（cyclonedds 没有 cp314 wheel）+ `pc_tools/3rd/unitree_sdk2_python`（本包未附带，从 Unitree 官方获取）；中文网卡名"以太网 2"要写成 XML 数字字符引用 `&#20197;&#22826;&#32593; 2` |

## 5. 常见坑

1. **PowerShell 引号和 `$` 会被吞掉**：不要在 `ssh unitree "..."` 里写复杂的 bash（含 `$`、引号嵌套、heredoc）。先在本地写成 `.sh` 文件，`scp` 过去，再 `ssh unitree "bash /tmp/x.sh"`。
2. **CRLF**：Windows 上编辑过的 `.sh` 传到 Linux 前去掉 `\r`：`tr -d '\r' < x.sh > y.sh` 或 `sed -i 's/\r$//' x.sh`。本包里的文件都是 LF。
3. **pgrep 匹配到自己**：`ssh unitree "pgrep -f auto_touch.py"` 会匹配到执行这条命令的 bash 本身，永远"有进程"。写成 `pgrep -f '[a]uto_touch.py'`。
4. **SSH 连接被拒**（`kex_exchange_identification: Connection closed` / `Connection reset`）：GPU 服务器的 sshd `MaxStartups` 限制了并发未认证连接。不要并行开很多 ssh；把多条命令合成一个脚本一次执行；失败时退避重试（`pc/arm_client.py` 内置 3 次重试）。10-19 下午右臂辨识因此推迟。
5. **代理软件劫持内网**：Clash.Meta 一类的 TUN 模式（虚拟网卡 "Meta"，198.18.0.1）会接管 192.168.123.0/24，表现为 ping 不通机器人、ssh 报 `kex_exchange_identification`。关闭 TUN，或把 192.168.123.0/24 设为直连。
6. **nohup 日志为空**：后台运行 python 必须加 `-u`，否则输出被缓冲。
7. **`/dev/shm` 重启清空**：重要结果及时归档到持久盘（`real_data/<日期>/`）。
8. **Isaac 进程不退出**：`app.close()` 卡死且占 GPU，脚本用 `os._exit(0)` 结束，外层再套 `timeout`。残留进程只杀自己启动的（按命令行和工作目录确认）。
9. **IsaacSim 5.0 pip 安装**（已弃用的路线，记录备查）：RTX 50 系要 5.0.0，只有清华镜像能装（aliyun / pypi.org 会触发 sdist 构建失败），首次 import 要 `OMNI_KIT_ACCEPT_EULA=YES`。这条路线的 URDF 导入网格没出图，最终改用服务器上现成的 Isaac Lab 环境（见 `extras/README_zh.md`）。
