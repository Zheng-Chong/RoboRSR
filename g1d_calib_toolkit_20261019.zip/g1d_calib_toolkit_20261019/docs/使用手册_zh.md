# G1-D 真机→仿真标定：使用手册

本手册按实际执行顺序写出每一步的输入、输出、命令、通过标准和**这台机器人上的典型数值**。典型数值只用来判断"是不是在正常范围"，换一台机器人要重新测。

动机器人之前先读 `安全规范_zh.md`；所有写死的主机、路径、端口及修改方法见 `环境配置_zh.md`；完整的事件经过见 `项目记录_20261015-19.md`。原标定包自带的方法文档在 `server/g1d_calib_20261015/docs/00–07`，本手册在相应位置引用。

---

## 0. 准备

### 0.1 三台机器的分工

| 机器 | 本包目录 | 运行环境 | 做什么 |
|---|---|---|---|
| 机器人（G1-D 本机，`ssh unitree`） | `robot/` | conda 环境 `tv`：numpy、scipy、opencv-contrib（带 `cv2.aruco.CharucoDetector`）、pyzmq、unitree_sdk2py（DDS） | 手臂控制服务、采集队列、自动触碰、回 home / 恢复 |
| GPU 服务器 | `server/` | Isaac Lab + IsaacSim 5.1 的 conda 环境（本包记作 `$ISAAC_ENV`，即 unitree_sim_env）；`/usr/bin/python3` + cv2 | 姿态表生成、测量导出、辨识、触碰辨识、写回 URDF、IsaacSim 渲染 |
| PC（Windows） | `pc/` | ssh；可选 Python 3.12 + numpy/opencv/pyzmq | 内参采图与求解、方向检查、测板位置、通过 ssh 下发少量指令、查看结果 |

数据流：

```text
相机内参 JSON ─┐
关节映射 JSON ─┤
板位置（头部双目） → gen_poses.py → 姿态表 → 机器人采集队列 → session 目录
                                                     │
                                         export_meas.py → 测量 JSON → identify.py → 参数 JSON
                                                                                      │
          auto_touch.py → touches.jsonl → touch_identify_auto.py（独立交叉验证）  ─────┤
                                                                                      ▼
                                              apply_calibration.py / build_assembly.py → 标定 URDF / USD
                                                                                      ▼
                                                     render_compare.py + compare_overlay.py（IsaacSim 叠图）
```

### 0.2 部署到机器人

机器人上的目录约定（脚本里写死，见 `环境配置_zh.md` §2）：

```text
~/calib_sessions/                   # robot/ 下的脚本、日志、会话数据
~/calib_sessions/model/             # calib_model.py + g1_d_upper_dex1_v4.urdf + camera_contract_v5.json
~/calib_sessions/poses_20261019/    # poses_left.json、poses_right.json、scene_header_B.json
~/g1d_infra_calib/scripts/          # calib_arm_server.py（start_server.sh / takeover2.sh 里写死的位置）
/tmp/g1d_calib/                     # 服务的 cmd.json / status.json（重启后消失）
```

在 PC 上执行（PowerShell 也可以，命令里没有 `$`）：

```bash
ssh unitree "mkdir -p ~/calib_sessions/model ~/calib_sessions/poses_20261019 ~/g1d_infra_calib/scripts"
scp robot/*.py robot/*.sh unitree:~/calib_sessions/
scp robot/calib_arm_server.py unitree:~/g1d_infra_calib/scripts/
scp server/g1d_calib_20261015/calib_model.py server/g1d_calib_20261015/nominal/g1_d_upper_dex1_v4.urdf server/g1d_calib_20261015/nominal/camera_contract_v5.json unitree:~/calib_sessions/model/
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/check_env.py"
```

`check_env.py` 应打印 `aruco True CharucoDetector True`。如果脚本在 Windows 上被编辑过，先去掉 CRLF：`ssh unitree "sed -i 's/\r$//' ~/calib_sessions/*.sh"`。

> `~/g1d_infra_calib/scripts` 在原机器人上是同事仓库的一个 git worktree，我们只是把服务脚本放在那里。新机器人上可以直接建这个空目录，或把 `start_server.sh`、`takeover2.sh` 里的 `cd` 那一行改成 `~/calib_sessions`。

### 0.3 部署到 GPU 服务器

服务器端脚本假定以下目录（详见 `环境配置_zh.md` §3）：

```text
/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled/      # 名义资产（URDF + meshes），calib_model 的默认 NOMINAL
/root/unitree_sim_isaaclab/real2sim_calib_20261015/              # 标定包本体 + real_data/<日期>/... + 渲染资产
/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam/      # 注入真实内参后的标定包副本（多数服务器脚本 import 这里）
/dev/shm/isaac_work/                                             # 临时工作目录：上传脚本、在这里运行（根盘曾满）
```

1. 把 `server/g1d_calib_20261015/` 放到 `/root/unitree_sim_isaaclab/real2sim_calib_20261015/`（服务器上已有则跳过）。本包没有附带网格，名义资产目录里有。
2. 生成真实内参副本（内参 JSON 见第 1 步）：

   ```bash
   cd /dev/shm/isaac_work
   python3 inject_real_intrinsics_patch.py /root/unitree_sim_isaaclab/real2sim_calib_20261015 \
       /root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/intrinsics \
       /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
   ```

   补丁让 `board_setups.py` 在设置环境变量 `G1D_REAL_INTRINSICS=<内参目录>` 时用真实内参构造名义场景（只影响合成验证和位姿设计的默认场景；`gen_poses.py` 自己读取内参目录）。
3. 设置环境变量：`export ISAAC_ENV=<unitree_sim_env 的路径>`（`run_*.sh` 和 `server/runs/*.sh` 用），`export ISAAC_PY=$ISAAC_ENV/bin/python`（`build_assembly.py`、`make_urdf_variants.py` 用）。
4. 把要用的 `server/tools/*.py` 上传到 `/dev/shm/isaac_work/` 再运行（多数脚本用绝对路径 import 标定包，放在哪里都能跑）。
5. 单元测试：`cd .../real2sim_calib_20261015 && $ISAAC_PY test_apply_calibration.py`，应 6/6 通过。

### 0.4 机器人使能和手臂控制服务

1. 遥控器：开机等约 1 分钟进入零力矩 → `L2+B` 阻尼 → `L2+R2` 调试模式。
2. 确认状态在发布：

   ```bash
   ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/peek_lowstate.py"
   # 期望：打印 lowstate 频率（这台机器人 10-16 实测约 138 Hz）、mode_machine=5 和左右臂各 7 个关节角
   # 打印 NO_LOWSTATE 说明没进调试模式
   ```

3. 启动服务（保持当前实测位姿，不运动）：

   ```bash
   ssh unitree "bash ~/calib_sessions/start_server.sh"        # 默认 vmax 0.1 rad/s；VMAX=0.2 可提速
   ```

   输出里有 `server ready` 才算成功。已有控制程序在跑时脚本拒绝启动。
4. 指令接口：写 `/tmp/g1d_calib/cmd.json`（原子替换），`{"seq": 递增整数, "cmd": "move", "arm_q": [左 7 + 右 7], "seconds": s}`；其他指令 `jog`（单电机 ≤0.1 rad）、`stop`、`reset`、`return`。状态每 50 ms 写到 `status.json`：`state`（idle/moving/error/free）、`seq_done`、`msg`、`arm_q`、`arm_q_cmd`、`arm_tau`、`all_q`、`vmax`、`n_pub`、`pid`。PC 端客户端是 `pc/arm_client.py`（通过 `ssh unitree` 读写这两个文件，带 3 次重试）。
5. 双臂回 home（全 0 位姿，前臂水平向前）。手臂下垂时从 PC 执行：

   ```bash
   cd pc && python raise_to_zero2.py      # 先外展肩部避开底盘，再转 yaw，最后回 0
   ```

   如果手臂因为下坠停在板上方，用 `python lift_back_to_zero.py`（先抬肘，再全部回 0）。
6. 必须换服务实例时（例如改速度上限）只用 `VMAX=0.2 bash ~/calib_sessions/takeover2.sh`，见安全规范 §3。

---

## 1. 相机内参

**目的**：四路相机（头部左/右、左腕、右腕）的 K 和畸变，格式 `g1d_camera_intrinsics_v1`。方法见包文档 `01_camera_intrinsics_zh.md`。

**输入**：实时相机流（头部 ZMQ 55555，1280×480 左右拼接，左半是 head_left；左腕 55557；右腕 55556），A3 ChArUco 板（按棋盘格用，9×6 内角点）。

**命令**（PC，Windows；`capture_intrinsics.py` 有预览窗口）：

```bash
cd pc
python capture_intrinsics.py head 60          # 存到 pc/calib_data/intrinsics/head/，双目成对保存
python capture_intrinsics.py left_wrist 70
python capture_intrinsics.py right_wrist 70
python -u calibrate_intrinsics.py all         # --square-mm 默认 40；--min-board-w 默认 120 px
python validate_intrinsics.py                 # 去畸变目视、双目量板、与 calib_model.project 对拍
```

**输出**：`pc/calib_data/intrinsics/camera_intrinsics_{head_left,head_right,left_wrist,right_wrist}.json`，字段 `K`、`dist`（OpenCV 5 参数）、`intrinsics_sigma`、`rms_px`、`heldout_rms_px`、`zmq_port`、`notes`。拷到服务器 `real_data/<日期>/intrinsics/`。

**通过标准**：留出 RMS ≤ 1.3 × 训练 RMS；fx/fy/cx/cy 标准差 < 0.5 px；双目基线与设计值一致；双目三角化量板格距 40 mm 误差 < 1–2 mm。包文档的 RMS ≤ 0.3 px 在这台机器人上没有达到（软纸板弯曲 + JPEG 流 + 自动对焦），sigma 已按实际放宽。

**本机典型数值**：头部 fx ≈ 279.3 / 279.8，RMS 0.46 / 0.48 px，留出 0.35 / 0.34 px，基线 61.37 mm（stereoRMS 0.49 px）；左腕（55557）fx ≈ 315.7、右腕（55556）fx ≈ 313.0，RMS 0.44–0.51 px。

**注意**：
- **腕相机自动对焦关不掉**（相机由 Unitree 的 teleimager 服务通过 pyuvc 打开，没有对焦配置），fx 随对焦距离漂移约 2%（0.65 m 与 0.9 m 对比），正式采集时整体又处在另一个对焦状态，辨识得到 fx 约 −4%~−5%（`intrinsics:left_wrist/fx` ≈ −16 px）。对策：采集限定在 0.2–0.55 m 的工作距离，辨识时用 `--refine-intrinsics` 吸收；`auto_touch.py --fx-scale 0.963` 也来自这里。用单张图逐样本估焦距再"补偿"的做法试过，误差反而更大（`extras/abandoned/af_correct.py`），不要用。
- 头部相机定焦，fx 漂移 < 0.3%。
- 10×7 板按棋盘格检测有 180° 角点顺序歧义，`calibrate_intrinsics.py` 用对角相邻格亮度消歧；之后的所有检测都用 `cv2.aruco.CharucoDetector`，没有歧义，也能检测部分入画的板。
- `cv2.imwrite` 在 Windows 上不支持中文路径，脚本统一用 `imencode` + 写字节。

## 2. 关节映射与方向检查

**目的**：确认 14 个手臂关节的电机序号和正方向，生成 `joint_mapping.json`。方法见包文档 `04_sim_real_comparison_zh.md` §3。

**已知映射**（这台机器人已验证）：电机 15–21 = 左臂 shoulder_pitch, shoulder_roll, shoulder_yaw, elbow, wrist_roll, wrist_pitch, wrist_yaw；22–28 = 右臂同顺序；腰 yaw = 12；共 35 个电机；**sign 全部为 +1**，URDF 关节值 = 电机 q。

**做法**：在准备位姿下逐个关节微动 ±0.05 rad，方向选 FK 预测会让夹爪往上走的那个；前后各拍一张腕相机图，用 SIFT 匹配桌面/板平面的运动（RANSAC 剔除跟着相机动的手指），和 FK 预测的像素位移比较。

```bash
# 服务器：选每个关节的微动方向，检查离桌余量 → real_data/20261016/poses/dircheck_plan.json（示例见 examples/dircheck_plan.json）
# 准备位姿 READY 和桌面高度写死在脚本开头，换机器人/换桌子要改
$ISAAC_PY plan_jog_signs.py
# PC：把 plan 放到 pc/frames_test/dircheck/dircheck_plan.json，服务在运行、手臂在准备位姿
cd pc && python dircheck.py left right        # DC_JOINTS=1 DC_JOG=0.1 可只复查某个关节
# 把 frames_test/dircheck/session_*/ 传到服务器后
/usr/bin/python3 dircheck_analyze.py <session_dir>
```

**通过标准**：每个关节实测/预测位移方向余弦 > 0.9，幅度比在 0.7–1.3 之间；编码器变化只出现在被指令的那个电机上。

**本机典型数值**：14/14 通过，左臂余弦 0.973–1.000（左肩 roll 在 0.05 rad 下预测位移只有 9 px，余弦 0.82，改用 0.1 rad 复查为 0.973），右臂 0.978–0.999，幅度比 0.76–1.13。

**注意**：
- **腕相机端口是反的**：只微动左手腕 yaw 时 55557 的画面在动，所以 55557 = 左腕、55556 = 右腕；同事仓库 g1d_infra 的相机配置把它们写反了。`pc/which_wrist_cam.py` 可以在新机器人上复查。
- 桌子离得很近时，URDF 碰撞模型（夹爪和真机不同）会误判撞桌，所以方向检查在准备位姿原地做，而不是去姿态表里的参考姿态。

## 3. 场景与姿态表

**目的**：按真实桌面和板位置生成每臂约 50 个 D 最优姿态，带碰撞检查过的过渡路径。

**场景（设置 B：腕相机看桌面板）**：
- 标定板：A3 ChArUco，10×7 格（9×6 = 54 个内角点），**格长 40 mm、码边 30 mm、字典 DICT_4X4_50**（ID 0–34）。7 行为奇数，legacy pattern 设置不影响。**用胶带固定在桌面**，放在约 6 mm 厚的硬纸板上。
- 板位姿用头部双目测（PnP），两只眼取平均。

**命令**：

```bash
# PC：测板位姿（读 pc/calib_data/intrinsics/ 的头部内参）
cd pc && python locate_board.py                # → pc/frames_test/board_locate/board_pose.json
# 或在机器人本机测（不经过网络拉流；先把头部内参拷到 ~/calib_sessions/intrinsics/）
ssh unitree "cd ~/calib_sessions && ~/miniconda3/envs/tv/bin/python locate_board_robot.py"   # → ~/calib_sessions/board_locate_now/board_pose.json
# 服务器：上传 board_pose.json 到 /dev/shm/isaac_work/，生成姿态表
cd /dev/shm/isaac_work
OPENBLAS_NUM_THREADS=8 $ISAAC_PY gen_poses.py --board-json board_pose.json \
    --table-z -0.174 --table-edge-x 0.10 --idle-zero --min-clear 0.10 \
    --out /root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/<日期>/poses_v2
```

（`server/runs/gen_v2.sh` 是 10-19 实际用的版本。）`--table-z` 是桌面在躯干系的高度（板面往下约 6 mm），`--table-edge-x` 是桌子近边，`--idle-zero` 把 home 和空闲手臂设为全 0 位姿。

**输出**：`poses_left.json`、`poses_right.json`（`g1d_calib_pose_list_v1`）、`scene_header_B.json`（真实板参数 + 真实内参 + 实测板位姿，导出测量时用作表头）、`summary.json`。每个姿态带 `joints`、`move_duration_s`、`transition_actual`（`direct` / `via_home`）、`home_path_ok`、`skip`、`fk_clearance_cm`、`path_clearance_cm`、`expected_nominal`（预测可见角点）。

**筛选规则**：碰撞模型里的桌面抬高 2 cm；离桌门槛按实测板平面（倾斜约 4°）计算；**候选阶段**先过滤（FK 关键点离桌 ≥ `min_clear` + 1 cm、相机到板中心 ≤ 0.55 m）再做 D 最优选择；每个姿态的实际过渡路径（先试 direct，再试 via_home）同时通过凸包碰撞和 FK 离桌两项检查，都不通过就标 `skip`。

**通过标准**：`summary.json` 里每臂可用姿态 ≥ 40，预测零位标准差 ~0.003°，条件数 < 10；相机到板距离多数在 0.2–0.45 m（对焦范围内）。`why_skip.py`、`pose_clearance.py` 可查看被跳过的原因。

**本机典型数值**（10-19）：板中心 (0.267, −0.029, −0.168) m（躯干系），左右眼差几毫米；左臂 47、右臂 43 个可用姿态。

**部署到机器人**：把三个 JSON 拷到 `~/calib_sessions/poses_20261019/`（目录名写死在 7 个机器人脚本里，见 `环境配置_zh.md` §2.3）。

## 4. 真机采集

**目的**：按姿态表逐个到位、等稳定、记录全部编码器 + 腕相机 5 帧 + 头部双目 1 帧。会话格式见包文档 `02_data_collection_zh.md`。

**前提**：服务在运行且空闲，双臂在 home；板固定、头部相机能看到板。

**命令**（在机器人本机后台运行，不受 PC 断线影响）：

```bash
ssh unitree "setsid nohup bash ~/calib_sessions/run_queue.sh left right > /dev/null 2>&1 < /dev/null &"
ssh unitree "tail -n 20 ~/calib_sessions/queue.log"           # 监控
ssh unitree "touch ~/calib_sessions/STOP"                       # 当前这只手臂采完后停止
```

单臂调试：`~/miniconda3/envs/tv/bin/python -u ~/calib_sessions/collect_robot.py left --max 3`（`--start K` 从第 K 个姿态开始）。

**每个姿态的流程**：（`via_home` 时先回 home）→ 沿直线到位 → 等稳定（`settle`：至少 1.5 s，最近 10 次读数关节变化 < 0.001 rad 且速度 < 0.015 rad/s，超时 6 s 跳过）→ 拍照前后各读一次关节，变化 > 0.002 rad 则作废 → 检查另一只手臂/腰部没漂移 → 头部相机测板中心，偏移 > 4 mm 中止 → 存图写 `samples.jsonl`。连续 3 个姿态检测不到板也中止。结束时倒序退回到能安全回 home 的点再回 home。

**输出**：`~/calib_sessions/calib_<时间>_B_wrist_table_board_<side>/`：`session.json`（姿态表哈希、内参文件名、端口、板参数、起止关节状态、会话开始时的板中心）、`samples.jsonl`（每姿态的目标/前后关节/力矩/帧文件/板漂移）、`images/<姿态>/`。打包传到服务器：`tar czf` 后 `scp`，解到 `real_data/<日期>/sessions/`。

**通过标准**：中止原因只有 STOP；板漂移全程 ≤ 2–3 mm；绝大多数姿态 `OK corners` 接近预期值。

**本机典型数值**（10-19，vmax 0.1 rad/s）：左臂 1209 会话 25 个样本（中午被中断），1509 会话 47 个样本，板漂移 ≤ 2.5 mm（缓慢单调增长）；右臂 1533 会话 43 个样本，板漂移 ≤ 0.9 mm。左臂会话 15:09 开始，右臂 15:33 开始，即每臂 40–50 个姿态约 20–25 分钟。

**注意**：`pc/` 没有采集器；早期从 PC 驱动的版本在 `extras/legacy/collect.py`，因为连接会断已弃用。`server/tools/board_timeline.py <session_dir>` 可以事后用每个姿态的头部帧重建板位置时间线（发现板被推动时用它分段，见 `build_segments_left.py`）。

## 5. 导出测量

**目的**：ChArUco 角点检测、多帧融合、质量筛选 → `g1d_calib_measurements_v1`。规则见包文档 `03_board_detection_export_zh.md`。

**命令**（服务器，`/usr/bin/python3` + cv2）：

```bash
cd /dev/shm/isaac_work
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
/usr/bin/python3 export_meas.py --session $R/sessions/calib_20261019_1509_B_wrist_table_board_left \
    --header $R/poses_v2/scene_header_B.json --board-name table_pm --out $R/sessions/meas_B_left_1509_pm.json
```

板在会话中被推动过时，用 `--segments segments.json` 按姿态 ID 分段，每段一个板位姿（模板见 `server/tools/build_segments_left.py`）。

**筛选规则**：图像放大 2 倍检测；5 帧里清晰度 < 中位数 30% 的帧丢弃；角点要在 ≥ 60% 的帧里出现，取中位数；离图像边缘 < 8 px 或帧间抖动 > 0.5 px 的角点去掉；PnP 重投影 > 1 px 时逐个剔除最大残差角点；角点 < 12 个或视角 > 65° 的观测丢弃；`sigma_px = max(0.2, 抖动中位数)`。

**`--board-name` 的含义**：同名的板在辨识中共享一个板位姿。**两只手臂在同一块板、机器人和板都没动的情况下采集时，给它们同一个板名**（10-19 的 1509 左臂和 1533 右臂都用 `table_pm`），这样两臂通过共享板联系起来，右肩相对左肩的安装位姿才可辨识。板动过的会话用单独的板名（例如 `table_1209`）。

**输出**：`meas_*.json` + `meas_*.report.json`（每个样本保留/剔除原因）。

**本机典型数值**：47 个样本导出 43 个；单图 PnP 残差 0.23–0.94 px。

## 6. 辨识

**目的**：从测量 JSON 估计关节零位、轴扭转（rot_v）、关节平移、腕相机外参、板位姿、腕相机内参修正。误差模型见包文档 `error_model_zh.md`。

**命令**（服务器，在真实内参副本目录下运行；`server/runs/` 里有 10-19 实际用的脚本）：

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
S=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019/sessions
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
# 双臂 + 共享板（preset auto）
$ISAAC_PY identify.py $S/meas_B_left_1209.json $S/meas_B_left_1509_pm.json $S/meas_B_right_1533_pm.json \
    --preset auto --refine-intrinsics --loss soft_l1 --f-scale 1.0 --folds 5 \
    --out $S/identify_dual_1019.json --params-out $S/params_dual_1019.json
# 再加关节原点平移（3 mm 零均值先验）——后来经触碰数据验证效果最好的版本
$ISAAC_PY identify.py <同上三个文件> --preset auto --refine-intrinsics \
    --estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' \
    --loss soft_l1 --f-scale 1.0 --folds 5 --out $S/identify_dual_trans_1019.json --params-out $S/params_dual_trans_1019.json
/usr/bin/python3 inspect_identify.py <tag>      # 打印参数（度 / 毫米 / 像素）和标准差
```

**参数说明**：
- `--preset auto`：每只被观测到的手臂的 shoulder_roll..wrist_pitch 零位 + shoulder_roll..wrist_yaw 的 rot_v，每个相机外参、每块板位姿；两臂通过躯干固定的板/相机联系时，再加非参考臂（默认参考右臂）shoulder_pitch 的 zero/rot_u/rot_v。单臂时肩部安装和 wrist_yaw 零位是规范自由度，不估计。
- `--refine-intrinsics`：同时修正腕相机内参（吸收自动对焦）。
- `--loss soft_l1`：抗离群；`--folds 5`：按样本 5 折留出验证。
- `--estimate / --exclude / --fix / --prior`：按通配符增减参数、固定值、加零均值先验。

**输出**：`identify_*.json`（残差、留出验证、SVD/条件数、相关性、`flags`）和 `params_*.json`（`g1d_calib_params_v1`：`values`、`std`、`values_deg_for_reading`、测量文件哈希）。

**通过标准**（包文档的验收线）：留出残差接近像素噪声（≤ 1 px），`flags` 无 `unidentifiable`，参数 std < 0.05°。

**本机实际情况（未达标，如实记录）**：
- 左臂 65 个样本：标定后残差 RMS 4.9 / 5.0 px（p95 约 8.7 px）；留出 6.1 / 6.2 px；只修相机和板、关节用名义值时留出 5.8 / 7.2 px——修关节零位在留出数据上几乎没有改善。
- 关节零位都在 1° 以内（例如 `params_dual_trans_1019`：左肩 roll +0.23°、左腕 pitch +0.58°），腕相机外参 dx 约 +16 mm、焦距 −16/−17 px。
- 剩余残差来源没有确定，候选：自动对焦逐姿态变化、关节间隙/弹性（编码器在电机侧）、连杆尺寸误差。`repeat_test.py` + `repeat_diff.py` 是为这个问题做的重复性实验。
- 因为相机残差没有降到验收线，后来用完全独立的触碰数据（第 7 步）检验各组参数：**`params_dual_trans_1019` 把左臂触碰留出误差从 5.3 mm 降到 1.6 mm**，作为左臂运动学标定的候选结果。

## 7. 自动触碰标定（左臂已做）

**目的**：用闭合夹爪的指尖当探头去碰桌面上的板，得到不依赖腕相机内参/对焦的几何约束，用来独立检验第 6 步的参数，并估计手臂相对头部的偏差。

### 7.1 准备

1. 夹爪闭合。确定指尖角在腕相机图像里的像素：`grab_one.py <端口> out.png` 抓一张图，`crop_zoom.py` 放大带像素刻度读数（或 `pc/find_tip_pixel.py` 自动找手指楔形顶点）。**这台机器人：左腕 (309, 255)，右腕 (330, 265)**（右臂触碰还没实跑）。
2. 预览每个悬停姿态的指尖射线落在板上的哪里：`python touch_plan.py left 309 255`（机器人上或 PC 上都能跑），挑射线落在板内部、入射角小的姿态。

### 7.2 单个悬停姿态的流程（`robot/auto_touch.py`）

1. home → 悬停姿态（姿态表里检查过的路径）。
2. 腕相机 PnP 看板；指尖像素的射线必须落在板内部（离边缘 ≥ 6 cm），入射角 ≤ 35°，距离 0.08–0.6 m。`--center` 允许平移相机最多 12 cm 把落点移进板内。
3. **绕这条射线旋转 15°**（相机中心和指尖都在射线上，指尖到板的距离不变），让一个指尖角先接触。加权 IK，肩部关节代价 ×4；IK 残差 > 2 mm / 0.5° 不执行；目标过躯干护栏。
4. 快速接近到预测接触点前 3 cm，然后沿射线每步 1.5 mm 接近。
5. **接触判据**：先看到 ≥ 3 步自由运动（每步实测 > 指令的 60%），之后连续 4 步实测前进 < 指令的 35%（或 < 之前平均比例的 0.55 倍）。自由运动时实测位移本身比指令多或少约 15%，所以不能只看"不动"——摩擦停滞会被误判。接触是柔性的，压上后每步仍会再压进 0.3–0.4 mm。滞后量增长 ≥ 8 mm 时停止（不算干净接触）。
6. 记录接触时的关节角、每步历史（用于找接触起点）和 3 张接触图；用接触图里的 ArUco 码四角做单应性，把指尖像素映射到板面坐标（与焦距无关）。
7. 退 1 cm 再碰一次（重复性 / 真实接触检查）。
8. 沿射线退回 → 悬停位 → home。`--offsets 0.04:0,-0.04:0,0:0.04,0:-0.04` 会在悬停高度沿板面平移 ±4 cm 各碰一个点。

### 7.3 命令

```bash
# 单次（机器人上，前台，便于观察）
~/miniconda3/envs/tv/bin/python -u ~/calib_sessions/auto_touch.py left --tip-u 309 --tip-v 255 --tip-depth 0.100 \
    --rolls 15 --max 1 --poses B_left_013
# 批量（后台队列；队列内容写在 touch_queue.sh 里，按需修改姿态列表）
ssh unitree "setsid nohup bash ~/calib_sessions/touch_queue.sh > /dev/null 2>&1 < /dev/null &"
ssh unitree "grep -v '^     [AB] cmd' ~/calib_sessions/touch_queue.log | tail -n 20"     # 去掉逐步日志
ssh unitree "touch ~/calib_sessions/STOP_TOUCH"       # 当前一轮结束后停
ssh unitree "bash ~/calib_sessions/stop_now.sh"       # 立即停（服务冻结在当前指令点）
```

`touch_queue.sh` 每轮之间 `sleep 61`：输出目录名精确到分钟（`touch_auto_<side>_%Y%m%d_%H%M`），同一分钟内再启动会因目录已存在而失败。

**输出**：`~/calib_sessions/touch_auto_<side>_<时间>/`：`touches.jsonl`（每个点一行：姿态、旋转角、偏移、悬停/旋转后视图、每次接触的关节角/历史/板面点）、`log.txt`、接触图。样例：`examples/touch_auto_left_20261019_1757/`。

**异常处理**：任何异常都直接退出（返回码 3），手臂由服务保持在原地，**不做自动恢复**。之后按安全规范 §6 用 `go_home.py --dry` / `recover.py --dry` 判断。

### 7.4 触碰辨识与交叉验证（服务器）

模型：指尖像素射线与板面的交点在夹爪坐标系里近似是一个固定"虚拟点"（像素偏差 10 px 以内时误差 < 0.4 mm）。每次触碰提供 3 个方程（板面内 2 个 + 法向 1 个）；未知量：虚拟点 3 个、板位姿修正 6 个（头部测量先验 5 mm / 1°），可选关节零位 5 个（M1）和 rot_v（M2）。

```bash
cd /dev/shm/isaac_work
T=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
# 自由拟合 M0/M1/M2，留一点交叉验证；排除上臂贴躯干的 001 和两个坏点
$ISAAC_PY touch_identify_auto.py $T/poses_v2/board_pose_measured.json \
    $T/touch/touch_auto_left_20261019_1720/touches.jsonl $T/touch/touch_auto_left_20261019_1757/touches.jsonl \
    --exclude B_left_001,B_left_034@-0.04@0,B_left_036@0.04@0
# 关节参数固定为视觉辨识结果，只拟合指尖 + 板，比较各参数集
$ISAAC_PY touch_identify_auto.py <同上> --exclude <同上> \
    --fixed $T/sessions/params_left_1019.json --fixed $T/sessions/params_dual_1019.json --fixed $T/sessions/params_dual_trans_1019.json
```

`--exclude` 的写法：`POSE`（该姿态的所有点）或 `POSE@dx@dy`（某个偏移点）。结果写在第一个 `touches.jsonl` 旁边的 `touch_identify_auto.result.json`。

**本机典型数值**：
- 重复性：沿接近方向 0.2–0.3 mm；不滑动时板面点 0.1–0.5 mm；退回再碰发生横向滑动时 1.5–2.6 mm；同一点跨两次运行 0.1 mm。单应性板面点拟合残差约 0.6 mm（近距离 PnP 只看到一小块角点，落点偏 2–3 cm，只能用于引导）。指尖深度（相机到指尖沿射线）约 0.10 m。
- 共 14 个点，排除后 11 个点、20 次触碰。M1：拟合 1.4 / 0.44 mm，留一 5.0 / 1.1 mm；M2：拟合 0.93 / 0.36 mm，留一 3.7 / 1.8 mm。11 个点只来自 4 个悬停构型，**关节零位约束不住**（例如 M1 的腕 pitch 零位 +6° 是和指尖偏移互相抵消的结果），要可信的零位需要更多样的手臂构型。
- 交叉验证（留一，板面内 / 法向）：

  | 关节参数 | 板面内 | 法向 |
  |---|---|---|
  | 名义值 | 5.3 mm | 1.2 mm |
  | `params_left_1019` | 4.3 mm | 0.9 mm |
  | `params_dual_1019` | 4.3 mm | 0.9 mm |
  | **`params_dual_trans_1019`** | **1.6 mm** | 1.2 mm |

- **手臂–头部偏差**：把板固定为头部测量值时（`end_boardhead_fixed` 变体，模型 `Mmount_shoulder_mount_vs_head`），左肩安装需要修正为肩 pitch 零位 −1.65°、rot_u +0.53°、dz −13.9 mm、dx +1.3 mm，在触碰位置约 17 mm（约 3°），与 10-16 渲染时看到的"肩部偏约 3°"一致。仅凭触碰数据分不清是肩安装偏差还是头部相机外参偏差，需要第 8 步的叠图来判断。

## 8. 写回 URDF 与 IsaacSim 渲染对比

### 8.1 写回

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015
$ISAAC_PY apply_calibration.py <params.json> out_urdf_<tag>          # 几秒，CPU；生成 upper + full URDF
cat out_urdf_<tag>/calibration_provenance.json                       # 改了哪些关节、origin 前后
$ISAAC_PY tcp_effect.py <params.json> tcp_effect_<tag>.json            # 预估 TCP / 腕相机位移
nohup $ISAAC_PY build_assembly.py <params.json> assembled_<tag> --gpu <N> > logs/build_<tag>.log 2>&1 &   # USD + 合同，需 GPU
```

- **只改关节 `<origin>`**；关节名、类型、轴、限位不变，URDF 关节值仍然是编码器值（约定 `q_model = q_encoder + zero`），所以仿真里求出的关节轨迹可以直接发给真机。
- `camera:*` 增量写进相机合同；`intrinsics:*` 只记录；`board:*` 是夹具参数，不进资产。
- 回归检查和启用条件见包文档 `07_apply_parameters_zh.md` §3（单元测试、USD-FK < 1e-6、只有预期关节改变等）。写回前把参数文件的 `sign_verified` 改为 `true`（方向检查已通过）。
- 不要覆盖共享资产（名义资产目录、其他项目的资产目录）；标定资产放在新目录。

### 8.2 渲染对比（头部左目，多个 URDF 变体）

```bash
# 生成变体：dual_trans（视觉辨识）和 dual_trans_mount（再替换为触碰得到的左肩安装）
$ISAAC_PY make_urdf_variants.py           # → real2sim_calib_20261015/scratch/urdf_variants_20261019/
# 渲染：每隔 EVERY 个姿态取一帧，按真机记录的关节角摆放各变体，从 head_left 渲染
GPU=4 OUT=/dev/shm/isaac_work/render_cmp_left EVERY=5 bash run_render_compare.sh
# 叠图：真机头部帧去畸变后，画各变体左臂（不含夹爪）轮廓
/usr/bin/python3 compare_overlay.py /dev/shm/isaac_work/render_cmp_left <camera_intrinsics_head_left.json>
```

输出 `overlay_<姿态>.png`（每个变体一种颜色）、`crop_<姿态>.png`（手臂放大）、`compare_report.json`（各变体手臂轮廓到最近真实边缘的中位距离，单位 px；背景里的板边缘很密，只是粗略指标，以目视为准）。

> 打包时（10-19 晚）这一步还在进行中，`render_compare.py` / `compare_overlay.py` / `run_render_compare.sh` / `make_urdf_variants.py` 是当时的快照，没有最终结论。

单帧四相机验证用 `render_isaaclab.py` + `run_render_isaaclab.sh`（`GRIP_MODE=lower|upper|default`）和 `overlay_isaaclab.py`（真机｜仿真｜真机 + 绿色仿真轮廓三联图）。

### 8.3 Isaac Lab 踩坑（都已在脚本里处理）

1. `PinholeCameraCfg.from_intrinsic_matrix` 必须显式传 `focal_length=24.0`；不传时默认 1/width，渲染器忽略这组参数，退化成固定 90° 视场。
2. 主点通过 USD 光圈偏移设置：`off_h = (W/2 − cx)·hap/W`，`off_v = (cy − H/2)·vap/H`（v 的符号和直觉相反），`hap = 24·W/fx`、`vap = 24·H/fy`。`cam.data.intrinsic_matrices` 回读不含主点偏移，不能用来验证；`render_isaaclab.py` 用探针小球实测（8 个探针中 7 个误差 < 1 px）。
3. 头部相机在 URDF 头壳网格内部（真机镜头透过窗口看），渲染时隐藏 `head_link` 的 visuals。
4. 退出时 `app.close()` 会卡死并一直占用 GPU，脚本结尾用 `os._exit(0)`；外面再套 `timeout`。
5. 多个变体叠放在同一位置时关闭碰撞（`collision_enabled=False`）和自碰撞，重力设为 0。
6. URDF 转换参数：`fix_base=True, merge_fixed_joints=False, make_instanceable=False`；USD 输出目录放 `/dev/shm`（根盘满）。
7. 抓真机帧时**同时记录夹爪开度**。Dex1 手指关节 −0.02 = 张开、+0.0245 = 闭合；渲染默认把夹爪放在下限（张开）。URDF 夹爪和真机外形不同，**夹爪不作为对齐参考**。
8. 判断偏差来源：躯干外壳和头部相机之间没有关节，外壳对不上只能是相机问题；手臂中间隔着 7 个关节。10-16 的叠图里躯干在 1 px 以内、左臂约 0 px、右臂 +8~+13 px。

---

## 9. 结果汇总（这台机器人，截至 2026-10-19）

| 项 | 结果 | 状态 |
|---|---|---|
| 头部双目内参 | fx ≈ 279.3/279.8，留出 0.35/0.34 px，基线 61.37 mm | 可用（RMS 0.46 未达 0.3 目标） |
| 腕相机内参 | fx ≈ 315.7（左）/ 313.0（右），自动对焦漂移由辨识吸收 | 可用，需 `--refine-intrinsics` |
| 关节映射 | 14/14，sign 全 +1；腕相机端口左右对调 | 已验证 |
| 视觉辨识 | 残差 ~5 px，留出改善有限 | 未达 1 px 验收线 |
| 触碰交叉验证 | `params_dual_trans_1019`：5.3 → 1.6 mm | 左臂候选结果 |
| 手臂–头部偏差 | 左肩安装约 17 mm / 3° | 待 IsaacSim 叠图判断来源 |
| 右臂触碰 | 指尖像素已标 (330, 265) | 未实跑 |

## 附录 A：常用监控命令

```bash
ssh unitree "cut -c1-220 /tmp/g1d_calib/status.json; echo"           # 服务状态
ssh unitree "pgrep -af '[c]alib_arm_server.py|[c]ollect_robot.py|[a]uto_touch.py|[r]un_queue.sh|[t]ouch_queue.sh'"
ssh unitree "tail -n 30 ~/calib_sessions/queue.log"
ssh unitree "tail -n 30 /tmp/g1d_calib_server.log"
ssh unitree "ls -dt ~/calib_sessions/calib_* ~/calib_sessions/touch_auto_* | head"
```

## 附录 B：文件格式速查

| 格式 | 产生 | 主要字段 |
|---|---|---|
| `g1d_camera_intrinsics_v1` | `calibrate_intrinsics.py` | camera, resolution, model, K, dist, intrinsics_sigma, rms_px, heldout_rms_px, zmq_port |
| `g1d_joint_mapping_v1` | 手写（方向检查后） | joints.{name}.motor_index/sign/offset_rad, cameras.{name}.zmq_port |
| `g1d_calib_pose_list_v1` | `gen_poses.py` | home, settle, setups.B_wrist_table_board.poses[] |
| `g1d_calib_session_v1` | `collect_robot.py` | session.json + samples.jsonl + images/ |
| `g1d_calib_measurements_v1` | `export_meas.py` | cameras, boards, samples[].joints/observations |
| `g1d_calib_params_v1` | `identify.py` | values, std, values_deg_for_reading, measurements(哈希) |
| touches.jsonl | `auto_touch.py` | pose, roll_deg, offset_m, rolled_view, touches[].arm_q_full/history/contact.board_xy_m |
