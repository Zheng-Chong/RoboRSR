# board_timeline.py -- board position (torso frame) from the head_left half of every saved head_stereo frame
# usage: board_timeline.py <session_dir> [...]
import json
import sys
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).parent
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838], [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
t_cam = np.array([0.04812857, 0.02963228, 0.43599143])
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
doc = json.loads((HERE / "calib_data" / "intrinsics" / "camera_intrinsics_head_left.json").read_text(encoding="utf-8"))
K, dist = np.array(doc["K"]), np.array(doc["dist"])
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
cp = cv2.aruco.CharucoParameters(); cp.minMarkers = 1
det = cv2.aruco.CharucoDetector(board, cp, dp)
OBJ = board.getChessboardCorners()

for sd in map(Path, sys.argv[1:]):
    print("==", sd.name)
    for line in open(sd / "samples.jsonl"):
        r = json.loads(line)
        img = cv2.imdecode(np.fromfile(str(sd / r["frames"]["head_stereo"][0]["file"]), np.uint8), cv2.IMREAD_GRAYSCALE)
        img = img[:, : img.shape[1] // 2]
        big = cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
        cc, ci, _, _ = det.detectBoard(big)
        if ci is None or len(ci) < 8:
            print(f"  {r['id']}: board not detected in head view ({0 if ci is None else len(ci)})"); continue
        imgp = ((cc.reshape(-1, 2) + 0.5) / 3 - 0.5).astype(np.float64)
        ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()].astype(np.float64), imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
        R = cv2.Rodrigues(rv)[0]
        c_opt = R @ np.array([0.20, 0.14, 0.0]) + tv.ravel()
        c = R_HEAD @ (OPT.T @ c_opt) + t_cam
        yaw = np.degrees(np.arctan2((R_HEAD @ OPT.T @ R)[1, 0], (R_HEAD @ OPT.T @ R)[0, 0]))
        print(f"  {r['id']}: centre ({c[0]:.3f}, {c[1]:+.3f}, {c[2]:.3f}) m  yaw {yaw:6.1f} deg  corners {len(ci)}")
