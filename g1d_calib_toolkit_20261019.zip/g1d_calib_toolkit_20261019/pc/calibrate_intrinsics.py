# calibrate_intrinsics.py — 内参求解（文档01）：calibrateCameraExtended + 离群剔除 + 80/20留出验证 + 验收 + 导出JSON
# 用法: python -u pc_tools/calibrate_intrinsics.py <head|left_wrist|right_wrist|all> [--square-mm 35.0]
# 验收: RMS<=0.3px；留出RMS<=1.3x训练RMS；fx/fy/cx/cy标准差<0.5px；四角覆盖；头部双目报基线
import argparse
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np

PATTERN = (9, 6)          # 内角点 (列, 行) = 10x7 格
N_CORNERS = PATTERN[0] * PATTERN[1]
CB_FLAGS = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
CRIT = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)
DATA = Path(__file__).parent / "calib_data" / "intrinsics"
CAMS = {"head": ["head_left", "head_right"], "left_wrist": ["left_wrist"], "right_wrist": ["right_wrist"]}


def _square_brightness(gray, c_inner, c_next1, c_next2):
    """内角点外侧相邻格中心的局部亮度（采样点夹取到图内）。"""
    d = (np.array(c_next1) - c_inner) + (np.array(c_next2) - c_inner)
    ctr = np.array(c_inner) - d / 2.0
    h, w = gray.shape
    x = int(np.clip(round(ctr[0]), 3, w - 4))
    y = int(np.clip(round(ctr[1]), 3, h - 4))
    return float(gray[y - 2:y + 3, x - 2:x + 3].mean())


CONF_FLIP = 40.0  # 两对角亮度差阈值，低于此认为消歧不可信


def canonicalize(gray, corners):
    """10x7棋盘180°翻转歧义：让corner[0]固定为相邻格为深色的那个对角。
    偶x奇格板两对角相邻格颜色相反，可据此消歧（否则双目标定会爆炸）。
    返回 (角点, 消歧是否可信)。"""
    p = corners.reshape(-1, 2)
    cols, rows = PATTERN
    b0 = _square_brightness(gray, p[0], p[1], p[cols])
    b1 = _square_brightness(gray, p[-1], p[-2], p[-1 - cols])
    confident = abs(b0 - b1) > CONF_FLIP
    if b0 > b1:  # corner0邻格比corner53亮 -> 翻转顺序，让corner0贴深色格
        corners = corners[::-1].copy()
    return corners, confident


def detect(gray):
    """与采集脚本一致：2x放大+均衡化+经典棋盘检测，回原尺度亚像素；再做180°消歧。"""
    big = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    big = cv2.equalizeHist(big)
    ok, corners = cv2.findChessboardCorners(big, PATTERN, CB_FLAGS)
    if not ok:
        return None
    corners = corners / 2.0
    corners = cv2.cornerSubPix(gray, corners, (5, 5), (-1, -1), CRIT)
    return canonicalize(gray, corners)  # (corners, confident)


MIN_BOARD_W = 120  # 板子表观宽度下限(px)，滤掉角点精度差的远景帧


def load_views(stream, square_m):
    """返回 {view_tag: (objp, [img_pts], [img_idx], img_size)}，objp 对所有视图相同。"""
    objp = np.zeros((N_CORNERS, 3), np.float32)
    objp[:, :2] = np.mgrid[0:PATTERN[0], 0:PATTERN[1]].T.reshape(-1, 2) * square_m
    out = {}
    d = DATA / stream
    if stream == "head":
        idxs = sorted({int(p.name.split("_")[0]) for p in d.glob("*_L.png")})
        for i in idxs:
            for tag, suffix in (("L", "_L"), ("R", "_R")):
                p = d / f"{i:04d}{suffix}.png"
                if not p.exists():
                    continue
                img = cv2.imdecode(np.fromfile(str(p), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
                if img is None:
                    continue
                det = detect(img)
                if det is None:
                    print(f"  [warn] {p.name} 重检测失败，跳过")
                    continue
                c, conf = det
                v = out.setdefault(tag, {"pts": [], "idx": [], "conf": [], "size": img.shape[::-1]})
                v["pts"].append(c.astype(np.float32))
                v["idx"].append(i)
                v["conf"].append(conf)
    else:
        for p in sorted(d.glob("*.png")):
            img = cv2.imdecode(np.fromfile(str(p), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            det = detect(img)
            if det is None:
                print(f"  [warn] {p.name} 重检测失败，跳过")
                continue
            c, conf = det
            v = out.setdefault("", {"pts": [], "idx": [], "conf": [], "size": img.shape[::-1]})
            v["pts"].append(c.astype(np.float32))
            v["idx"].append(int(p.stem))
            v["conf"].append(conf)
    for tag, v in out.items():
        widths = [p.reshape(-1, 2)[:, 0].max() - p.reshape(-1, 2)[:, 0].min() for p in v["pts"]]
        keep = [i for i, w in enumerate(widths) if w >= MIN_BOARD_W]
        n_drop = len(v["pts"]) - len(keep)
        if n_drop:
            print(f"  [{stream}{tag}] 滤掉远景帧 {n_drop} 张（板宽<{MIN_BOARD_W}px）")
        v["pts"] = [v["pts"][i] for i in keep]
        v["idx"] = [v["idx"][i] for i in keep]
        v["conf"] = [v["conf"][i] for i in keep]
        v["objp"] = objp
    return out


def fit(objp, img_pts, size):
    """calibrateCameraExtended + 剔除 per_view>3x中位数 后重算。返回 dict。"""
    obj = [objp] * len(img_pts)
    rms, K, dist, rv, tv, std_i, std_e, per_view = cv2.calibrateCameraExtended(
        obj, img_pts, size, None, None, flags=0)
    per_view = per_view.ravel()
    med = np.median(per_view)
    keep = per_view <= 3.0 * med
    n_drop = int((~keep).sum())
    if n_drop:
        obj2 = [o for o, k in zip(obj, keep) if k]
        pts2 = [p for p, k in zip(img_pts, keep) if k]
        rms, K, dist, rv, tv, std_i, std_e, per_view = cv2.calibrateCameraExtended(
            obj2, pts2, size, None, None, flags=0)
        per_view = per_view.ravel()
    return {"rms": rms, "K": K, "dist": dist.ravel(), "std_intr": std_i.ravel(),
            "per_view": per_view, "n_drop": n_drop, "n_used": int(keep.sum()),
            "rvecs": rv, "tvecs": tv}


def holdout_eval(K, dist, objp, img_pts, size):
    """留出集：solvePnP(固定内参, IPPE平面稳定解) -> 重投影 RMS(px)。"""
    errs = []
    for p in img_pts:
        try:
            ok, rv, tv = cv2.solvePnP(objp, p, K, dist, flags=cv2.SOLVEPNP_IPPE)
        except cv2.error:
            ok, rv, tv = cv2.solvePnP(objp, p, K, dist, flags=cv2.SOLVEPNP_ITERATIVE)
        if not ok:
            continue
        proj, _ = cv2.projectPoints(objp, rv, tv, K, dist)
        errs.append(np.sqrt(((proj.reshape(-1, 2) - p.reshape(-1, 2)) ** 2).sum(axis=1)).mean())
    return float(np.mean(errs)) if errs else float("nan")


def coverage(img_pts, size):
    """4x4 网格覆盖统计；返回 (覆盖格数/16, 四角是否全覆盖)。"""
    W, H = size
    grid = np.zeros((4, 4), bool)
    for pts in img_pts:
        for x, y in pts.reshape(-1, 2):
            gx = min(int(x / (W / 4)), 3)
            gy = min(int(y / (H / 4)), 3)
            grid[gy, gx] = True
    corners_ok = grid[0, 0] and grid[0, 3] and grid[3, 0] and grid[3, 3]
    return int(grid.sum()), bool(corners_ok), grid


def solve_one(cam_name, view, square_m, seed=42, extra_note=""):
    size = view["size"]
    pts, idx = view["pts"], view["idx"]
    n = len(pts)
    print(f"\n===== {cam_name}: {n} 张, 分辨率 {size} =====")
    if n < 15:
        print(f"  [FAIL] 图片太少（{n}<15），无法可靠标定")
        return None
    order = list(range(n))
    random.Random(seed).shuffle(order)
    n_hold = max(3, int(round(n * 0.2)))
    hold_i, fit_i = set(order[:n_hold]), order[n_hold:]
    fit_pts = [pts[i] for i in fit_i]
    hold_pts = [pts[i] for i in hold_i]

    r = fit(view["objp"], fit_pts, size)
    hold_rms = holdout_eval(r["K"], r["dist"], view["objp"], hold_pts, size)
    fx, fy, cx, cy = r["K"][0, 0], r["K"][1, 1], r["K"][0, 2], r["K"][1, 2]
    sfx, sfy, scx, scy = r["std_intr"][0], r["std_intr"][1], r["std_intr"][2], r["std_intr"][3]
    ncells, corners_ok, grid = coverage(pts, size)

    print(f"  训练RMS     = {r['rms']:.4f} px   (要求 <=0.3)  {'OK' if r['rms'] <= 0.3 else 'FAIL'}")
    print(f"  留出RMS     = {hold_rms:.4f} px ({hold_rms / r['rms']:.2f}x 训练, 要求 <=1.3x)  "
          f"{'OK' if hold_rms <= 1.3 * r['rms'] else 'FAIL'}")
    print(f"  fx={fx:.2f}±{sfx:.3f}  fy={fy:.2f}±{sfy:.3f}  cx={cx:.2f}±{scx:.3f}  cy={cy:.2f}±{scy:.3f}"
          f"  (std要求<0.5)  {'OK' if max(sfx, sfy, scx, scy) < 0.5 else 'FAIL'}")
    print(f"  dist        = {np.array2string(r['dist'], precision=5, separator=', ')}")
    print(f"  剔除离群    = {r['n_drop']} 张, 训练用 {r['n_used']} 张 / 留出 {len(hold_pts)} 张")
    print(f"  覆盖        = {ncells}/16 格, 四角={'齐' if corners_ok else '缺!'}")
    for row in grid:
        print("    " + " ".join("#" if c else "." for c in row))

    doc = {
        "format": "g1d_camera_intrinsics_v1",
        "camera": cam_name,
        "resolution": list(size),
        "model": "opencv",
        "K": [[float(r["K"][i, j]) for j in range(3)] for i in range(3)],
        "dist": [float(x) for x in r["dist"]],
        "intrinsics_sigma": {
            "fx": float(min(sfx * 2, 5.0)), "fy": float(min(sfy * 2, 5.0)),
            "cx": float(min(scx * 2, 5.0)), "cy": float(min(scy * 2, 5.0)),
            "k1": 0.002, "k2": 0.002, "p1": 0.0002, "p2": 0.0002, "k3": 0.0005},
        "rms_px": float(r["rms"]),
        "heldout_rms_px": float(hold_rms),
        "n_images": int(r["n_used"]),
        "board": {"type": "chessboard", "squares_x": PATTERN[0] + 1, "squares_y": PATTERN[1] + 1,
                  "square_length_m": square_m},
        "stream": {"fps": 30, "pixel_format": "jpeg->bgr8", "auto_exposure": None,
                   "autofocus": None, "driver_rectified": False},
        "notes": ("棋盘180deg翻转按相邻格亮度规范化；双目仅用双侧消歧可信的对。"
                  "头部底部1/4视场被桌面/自身遮挡无法覆盖，K/dist在该区域为外推（畸变很小，预计亚像素级）。"
                  + extra_note),
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    outp = DATA / f"camera_intrinsics_{cam_name}.json"
    outp.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  已写出 {outp}")
    return {"K": r["K"], "dist": r["dist"], "doc": doc, "view": view}


def stereo_check(views, sols, square_m):
    """头部双目：固定各自内参 stereoCalibrate -> 基线检查。只用双侧消歧都可信的对。"""
    vl, vr = views["L"], views["R"]
    confl = dict(zip(vl["idx"], vl["conf"]))
    confr = dict(zip(vr["idx"], vr["conf"]))
    common = sorted(i for i in set(vl["idx"]) & set(vr["idx"]) if confl.get(i) and confr.get(i))
    n_all = len(set(vl["idx"]) & set(vr["idx"]))
    if len(common) < n_all:
        print(f"  [stereo] 消歧不可信剔除 {n_all - len(common)} 对，用 {len(common)}/{n_all} 对")
    lmap = dict(zip(vl["idx"], vl["pts"]))
    rmap = dict(zip(vr["idx"], vr["pts"]))
    obj = [vl["objp"]] * len(common)
    pl = [lmap[i] for i in common]
    pr = [rmap[i] for i in common]
    rms, K1, d1, K2, d2, R, T, E, F = cv2.stereoCalibrate(
        obj, pl, pr, sols["head_left"]["K"].copy(), sols["head_left"]["dist"].copy(),
        sols["head_right"]["K"].copy(), sols["head_right"]["dist"].copy(),
        vl["size"], flags=cv2.CALIB_FIX_INTRINSIC)
    baseline = float(np.linalg.norm(T))
    # 逐对一致性：IPPE独立解算每对相对位姿的散布
    Kl, dl = sols["head_left"]["K"], sols["head_left"]["dist"]
    Kr, dr = sols["head_right"]["K"], sols["head_right"]["dist"]
    Ts = []
    for i in common:
        ok1, rv1, tv1 = cv2.solvePnP(vl["objp"], lmap[i], Kl, dl, flags=cv2.SOLVEPNP_IPPE)
        ok2, rv2, tv2 = cv2.solvePnP(vl["objp"], rmap[i], Kr, dr, flags=cv2.SOLVEPNP_IPPE)
        R1, _ = cv2.Rodrigues(rv1)
        R2, _ = cv2.Rodrigues(rv2)
        Ts.append((tv1 - (R1 @ R2.T) @ tv2).ravel() * 1000)
    Ts = np.array(Ts)
    print(f"\n===== 双目检查: {len(common)} 对 =====")
    print(f"  stereoRMS = {rms:.4f} px")
    print(f"  基线 |T|  = {baseline * 1000:.2f} mm   T = {np.array2string(T.ravel(), precision=4)}")
    print(f"  逐对IPPE |T| 中位 {np.median(np.linalg.norm(Ts, axis=1)):.1f} mm,"
          f" 分量std {np.array2string(Ts.std(0), precision=1)} mm（应<<10mm）")
    print(f"  R(rod)    = {np.array2string(R, precision=6)}")
    print(f"  （基线随格长缩放；格长 {square_m * 1000:.1f} mm 若不对，基线等比例错）")
    return baseline


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("which", choices=["head", "left_wrist", "right_wrist", "all"])
    ap.add_argument("--square-mm", type=float, default=40.0,
                    help="棋盘格边长(mm)。内参与此无关，但双目基线/距离按此缩放！")
    ap.add_argument("--min-board-w", type=float, default=120.0,
                    help="板子表观宽度下限(px)，腕相机AF时取250锁定近距对焦")
    ap.add_argument("--notes", default="", help="附加写入JSON notes的说明")
    args = ap.parse_args()
    global MIN_BOARD_W
    MIN_BOARD_W = args.min_board_w
    square_m = args.square_mm / 1000.0
    streams = ["head", "left_wrist", "right_wrist"] if args.which == "all" else [args.which]
    for stream in streams:
        views = load_views(stream, square_m)
        if not views:
            print(f"[{stream}] 无数据，跳过")
            continue
        sols = {}
        tag2cam = {"": CAMS[stream][0], "L": CAMS[stream][0]}
        if len(CAMS[stream]) > 1:
            tag2cam["R"] = CAMS[stream][1]
        for tag, cam_name in tag2cam.items():
            if tag not in views:
                continue
            s = solve_one(cam_name, views[tag], square_m, extra_note=args.notes)
            if s:
                sols[cam_name] = s
        if stream == "head" and len(sols) == 2:
            stereo_check(views, sols, square_m)


if __name__ == "__main__":
    main()
