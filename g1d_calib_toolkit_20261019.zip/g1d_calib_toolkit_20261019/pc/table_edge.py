# table_edge.py -- locate the table near edge in the torso frame (ray / table-plane intersection, head_left)
import json
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).parent
img = cv2.imdecode(np.fromfile(str(HERE / "frames_test" / "board_locate" / "head_left.png"), np.uint8), cv2.IMREAD_COLOR)
doc = json.loads((HERE / "calib_data" / "intrinsics" / "camera_intrinsics_head_left.json").read_text(encoding="utf-8"))
K, dist = np.array(doc["K"]), np.array(doc["dist"])
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838], [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
t_cam = np.array([0.04812857, 0.02963228, 0.43599143])
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
board = json.load(open(HERE / "frames_test" / "board_locate" / "board_pose.json"))
z_table = board["head_left"]["board_center_torso_m"][2] - 0.006   # board sits on ~6 mm cardboard

# near-edge pixels: strongest dark->bright transition scanning upward below the table, per column
g = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32), (0, 0), 1.2)
gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
pts = []
for u in list(range(110, 230, 10)) + list(range(450, 580, 10)):   # skip the cardboard/board columns
    col = -gy[180:260, u]                                          # bright table above dark floor -> negative gy
    v = 180 + int(np.argmax(col))
    pts.append((u, v))
vis = img.copy()
xs = []
for (u, v) in pts:
    d = cv2.undistortPoints(np.array([[[u, v]]], np.float64), K, dist).ravel()
    ray_opt = np.array([d[0], d[1], 1.0])
    ray_t = R_HEAD @ (OPT.T @ ray_opt)
    s = (z_table - t_cam[2]) / ray_t[2]
    p = t_cam + s * ray_t
    xs.append(p)
    cv2.circle(vis, (u, v), 3, (0, 0, 255), -1)
xs = np.array(xs)
print("table plane z (torso frame): %.3f m" % z_table)
print("near-edge points x (fwd) per column:", np.round(xs[:, 0], 3).tolist())
print("near-edge points y (left) per column:", np.round(xs[:, 1], 3).tolist())
print("near-edge x median: %.3f m" % np.median(xs[:, 0]))
cv2.imencode(".png", cv2.resize(vis, None, fx=2, fy=2))[1].tofile(str(HERE / "frames_test" / "board_locate" / "table_edge.png"))
