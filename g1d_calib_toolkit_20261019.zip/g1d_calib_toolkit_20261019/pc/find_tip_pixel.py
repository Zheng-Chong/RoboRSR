# find_tip_pixel.py -- locate the apex of the closed gripper fingers in a wrist image (dark wedge on bright background)
import sys
from pathlib import Path

import cv2
import numpy as np

p = Path(sys.argv[1])
img = cv2.imdecode(np.fromfile(str(p), np.uint8), cv2.IMREAD_GRAYSCALE)
dark = (img < 70).astype(np.uint8)
dark = cv2.morphologyEx(dark, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
n, lab, st, cen = cv2.connectedComponentsWithStats(dark)
# the finger wedge: the largest dark blob touching the bottom edge near the image centre
cands = [i for i in range(1, n) if st[i, cv2.CC_STAT_TOP] + st[i, cv2.CC_STAT_HEIGHT] >= img.shape[0] - 2
         and abs(cen[i][0] - img.shape[1] / 2) < 120]
k = max(cands, key=lambda i: st[i, cv2.CC_STAT_AREA])
ys, xs = np.nonzero(lab == k)
ytop = ys.min()
top = xs[ys <= ytop + 2]
print(f"finger wedge apex: u={top.mean():.1f}, v={ytop:.1f}  (blob area {st[k, cv2.CC_STAT_AREA]})")
row = ytop + 4
xs_row = xs[ys == row]
print(f"fingertip edge at v={row}: left end u={xs_row.min()}, right end u={xs_row.max()}, width {xs_row.max() - xs_row.min()} px")
vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
cv2.circle(vis, (int(top.mean()), int(ytop)), 6, (0, 0, 255), 2)
cv2.circle(vis, (int(xs_row.min()), int(row)), 5, (0, 255, 0), 2)
cv2.imencode(".png", vis)[1].tofile(str(p.with_name(p.stem + "_tip.png")))
