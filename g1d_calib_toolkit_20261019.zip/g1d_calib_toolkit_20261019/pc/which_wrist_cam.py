# which_wrist_cam.py -- which ZMQ port is the camera on the LEFT arm? jog left wrist_yaw, see which image moves
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

import arm_client as arm

HOST = "192.168.123.164"
PORTS = {55556: "port55556(named left_wrist)", 55557: "port55557(named right_wrist)"}
OUT = Path(__file__).parent / "frames_test" / "dircheck"
ctx = zmq.Context.instance()


def grab(port):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")
    for _ in range(6):
        data = s.recv()
    s.close(0)
    return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_GRAYSCALE).astype(np.float32)


time.sleep(1.0)
before = {p: grab(p) for p in PORTS}
arm.jog(21, 0.05)          # left wrist_yaw (motor 21)
time.sleep(1.5)
after = {p: grab(p) for p in PORTS}
arm.jog(21, -0.05)
for p, name in PORTS.items():
    d = np.abs(after[p] - before[p])
    print(f"{name}: mean |diff| = {d.mean():.2f}, pixels changed >25: {100 * (d > 25).mean():.1f}%")
    cv2.imencode(".png", np.hstack([before[p], after[p]]).astype(np.uint8))[1].tofile(str(OUT / f"which_{p}.png"))
