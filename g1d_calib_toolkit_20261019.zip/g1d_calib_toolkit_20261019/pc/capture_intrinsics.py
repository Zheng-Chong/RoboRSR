# capture_intrinsics.py — 内参标定采集：订阅相机流，检测棋盘格(9x6内角点)，合格帧自动存盘
# 用法: python capture_intrinsics.py <head|left_wrist|right_wrist> [最多存N组]
# 预览窗口绿色=角点；左上角 saved/角点/清晰度。q 退出。
import ctypes
import json
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

ctypes.windll.user32.SetProcessDPIAware()

HOST = "192.168.123.164"
CAMS = {"head": (55555, True), "left_wrist": (55557, False), "right_wrist": (55556, False)}  # 55557 = LEFT arm (verified 10-16)

PATTERN = (9, 6)          # 内角点 (列, 行) = 10x7 格
N_CORNERS = PATTERN[0] * PATTERN[1]
MIN_SHARP = 40.0          # Laplacian 方差下限（防运动模糊）
MIN_DISP = 14.0           # 与上一组已存帧的角点平均位移(px)，保证位姿多样
MAX_RATE = 0.6            # 每秒最多存几组
CB_FLAGS = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
CRIT = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)


def imwrite_unicode(path: Path, img) -> None:
    ok, buf = cv2.imencode(".png", img)
    if not ok:
        raise RuntimeError(f"imencode failed: {path}")
    path.write_bytes(buf.tobytes())


def detect(gray):
    """2x放大+均衡化检测棋盘格，回原尺度亚像素细化。返回 (是否全检出, 平均角点, 清晰度, 可视化)"""
    big = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    big = cv2.equalizeHist(big)
    ok, corners = cv2.findChessboardCorners(big, PATTERN, CB_FLAGS)
    vis = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    sharp = cv2.Laplacian(gray, cv2.CV_64F).var()
    if not ok:
        return False, None, sharp, vis, None
    corners = corners / 2.0
    corners = cv2.cornerSubPix(gray, corners, (5, 5), (-1, -1), CRIT)
    cv2.drawChessboardCorners(vis, PATTERN, corners, True)
    mean = corners[:, 0].mean(axis=0)
    return True, mean, sharp, vis, corners


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "head"
    max_save = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    port, bino = CAMS[name]
    outdir = Path(__file__).parent / "calib_data" / "intrinsics" / name
    outdir.mkdir(parents=True, exist_ok=True)
    lockfile = Path(__file__).parent / "calib_data" / f".capture_{name}.lock"
    if lockfile.exists():
        print(f"已有 {name} 采集在跑（锁文件存在），退出", flush=True)
        sys.exit(1)
    lockfile.write_text(str(os.getpid()))
    log = open(outdir / "timestamps.jsonl", "a", encoding="utf-8")

    ctx = zmq.Context.instance()
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1)
    s.setsockopt(zmq.RCVTIMEO, 3000)
    s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")

    saved = len([f for f in outdir.glob("*.png")]) // (2 if bino else 1)
    start_i = saved
    last_save_t = 0.0
    last_mean = {}
    print(f"[{name}] 开始采集，已有 {start_i} 组，目标共 {max_save} 组，存到 {outdir}", flush=True)
    while saved < max_save:
        try:
            data = s.recv()
        except zmq.Again:
            print("流超时"); break
        frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if frame is None:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        views = [("L", gray[:, : gray.shape[1] // 2]), ("R", gray[:, gray.shape[1] // 2:])] if bino else [("", gray)]

        stats, vis_all = {}, []
        for tag, g in views:
            ok, mean, sharp, vis, _ = detect(g)
            stats[tag] = (ok, mean, sharp)
            vis_all.append(vis)
        vis_show = np.hstack(vis_all) if len(vis_all) > 1 else vis_all[0]

        ok_all = all(st[0] and st[2] >= MIN_SHARP for st in stats.values())
        disp = min(
            (np.linalg.norm(st[1] - last_mean[t]) for t, st in stats.items()
             if st[1] is not None and t in last_mean),
            default=1e9)
        now = time.time()
        if ok_all and disp >= MIN_DISP and now - last_save_t >= 1.0 / MAX_RATE:
            ts = time.time()
            for tag, g in views:
                fn = f"{saved:04d}{('_' + tag) if tag else ''}.png"
                imwrite_unicode(outdir / fn, g)
            rec = {"i": saved, "t": ts,
                   **{f"sharp{t}": round(st[2], 1) for t, st in stats.items()}}
            log.write(json.dumps(rec) + "\n"); log.flush()
            last_mean = {t: st[1] for t, st in stats.items() if st[1] is not None}
            last_save_t = now
            saved += 1

        info = f"saved {saved}/{max_save}"
        for t, st in stats.items():
            info += f" | {t or 'mono'}: {'OK' if st[0] else '--'} sharp={st[2]:.0f}"
        cv2.putText(vis_show, info, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    (0, 255, 0) if ok_all else (0, 0, 255), 2)
        # 目标区域提示：底部1/4画红带，角点需要进这里
        hh, ww = vis_show.shape[:2]
        overlay = vis_show.copy()
        n_view = 2 if bino else 1
        for vi in range(n_view):
            x0 = vi * ww // n_view
            cv2.rectangle(overlay, (x0, hh * 3 // 4), (x0 + ww // n_view, hh), (0, 0, 255), -1)
        cv2.addWeighted(overlay, 0.25, vis_show, 0.75, 0, vis_show)
        cv2.putText(vis_show, "TARGET: corners into red band (board LOW, 0.5-0.7m, fully visible)",
                    (10, hh - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 140, 255), 1)
        pw = 900
        ph = int(vis_show.shape[0] * pw / vis_show.shape[1])
        preview = cv2.resize(vis_show, (pw, ph))
        cv2.namedWindow("capture", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("capture", pw, ph)
        cv2.moveWindow("capture", 30, 30)
        cv2.imshow("capture", preview)
        if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
            break
    print(f"完成，存了 {saved} 组", flush=True)
    s.close(0); log.close(); cv2.destroyAllWindows()
    lockfile.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
