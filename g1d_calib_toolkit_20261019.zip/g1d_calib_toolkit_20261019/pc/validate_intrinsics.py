# validate_intrinsics.py — 内参效果三层验证：
# A. 去畸变目视图（直线是否变直）
# B. 双目三角化量板：格距应=40mm、板应平面、跨距离一致（真机3D证据）
# C. 标定包 calib_model.project（仿真侧投影）vs cv2.projectPoints 对拍（数学等价性）
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from calibrate_intrinsics import load_views, detect, CAMS

PKG = Path(__file__).parent.parent / "g1d_calib_20261015" / "g1d_calib_20261015"
sys.path.insert(0, str(PKG))
from calib_model import project as sim_project, intrinsics_dict

DATA = Path(__file__).parent / "calib_data" / "intrinsics"
SQUARE = 0.04
OUT = Path(__file__).parent / "frames_test"


def load_json(cam):
    return json.loads((DATA / f"camera_intrinsics_{cam}.json").read_text(encoding="utf-8"))


def K_of(doc):
    return np.array(doc["K"]), np.array(doc["dist"])


def test_A_undistort():
    print("\n===== A. 去畸变目视 =====")
    for cam, img_path in [("head_left", DATA / "head" / "0170_L.png"),
                          ("left_wrist", DATA / "left_wrist" / "0050.png")]:
        if not img_path.exists():
            continue
        doc = load_json(cam)
        K, dist = K_of(doc)
        img = cv2.imdecode(np.fromfile(str(img_path), dtype=np.uint8), cv2.IMREAD_COLOR)
        und = cv2.undistort(img, K, dist)
        both = np.hstack([img, und])
        cv2.putText(both, "raw", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        cv2.putText(both, "undistorted", (img.shape[1] + 10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        out = OUT / f"validate_undistort_{cam}.png"
        cv2.imencode(".png", both)[1].tofile(str(out))
        print(f"  {cam}: {out}")


def stereo_params(views, docl, docr):
    """重算双目标定（与求解器同输入 -> 同结果），返回 R,T 和可信对。"""
    vl, vr = views["L"], views["R"]
    confl = dict(zip(vl["idx"], vl["conf"]))
    confr = dict(zip(vr["idx"], vr["conf"]))
    common = sorted(i for i in set(vl["idx"]) & set(vr["idx"]) if confl.get(i) and confr.get(i))
    lmap = dict(zip(vl["idx"], vl["pts"]))
    rmap = dict(zip(vr["idx"], vr["pts"]))
    K1, d1 = K_of(docl)
    K2, d2 = K_of(docr)
    obj = [vl["objp"]] * len(common)
    rms, *_ , R, T, E, F = cv2.stereoCalibrate(
        obj, [lmap[i] for i in common], [rmap[i] for i in common],
        K1.copy(), d1.copy(), K2.copy(), d2.copy(), vl["size"], flags=cv2.CALIB_FIX_INTRINSIC)
    return R, T, common, lmap, rmap, rms


def test_B_triangulate():
    print("\n===== B. 双目三角化量板（40mm格 / 板应平面）=====")
    views = load_views("head", SQUARE)
    docl, docr = load_json("head_left"), load_json("head_right")
    K1, d1 = K_of(docl)
    K2, d2 = K_of(docr)
    R, T, common, lmap, rmap, rms = stereo_params(views, docl, docr)
    print(f"  基线 {np.linalg.norm(T) * 1000:.2f} mm (stereoRMS {rms:.3f}px)，测 {len(common)} 对")
    P1 = K1 @ np.hstack([np.eye(3), np.zeros((3, 1))])
    P2 = K2 @ np.hstack([R, T])
    spacings, planarities, dists, widths, heights = [], [], [], [], []
    step = max(1, len(common) // 15)
    for i in common[::step]:
        pl = cv2.undistortPoints(lmap[i], K1, d1, P=K1).reshape(-1, 2).T
        pr = cv2.undistortPoints(rmap[i], K2, d2, P=K2).reshape(-1, 2).T
        X = cv2.triangulatePoints(P1, P2, pl, pr)
        X = (X[:3] / X[3]).T  # (54,3) L相机系
        p2d = X.reshape(6, 9, 3)
        # 相邻格距
        ds = np.linalg.norm(np.diff(p2d, axis=1), axis=2).ravel()
        ds = np.concatenate([ds, np.linalg.norm(np.diff(p2d, axis=0), axis=2).ravel()])
        spacings.append(ds.mean() * 1000)
        # 板尺寸: 角点跨度 (0,0)->(8,0)=320mm, (0,0)->(0,5)=200mm
        widths.append(np.linalg.norm(p2d[0, 8] - p2d[0, 0]) * 1000)
        heights.append(np.linalg.norm(p2d[5, 0] - p2d[0, 0]) * 1000)
        # 平面度
        c = X.mean(0)
        _, _, vt = np.linalg.svd(X - c)
        planarities.append(np.abs((X - c) @ vt[2]).std() * 1000)
        dists.append(np.linalg.norm(c))
    print(f"  格距     = {np.mean(spacings):.2f} ± {np.std(spacings):.2f} mm  (真值 40.00)")
    print(f"  板宽向   = {np.mean(widths):.1f} mm / 板高向 = {np.mean(heights):.1f} mm  (真值 320 / 200)")
    print(f"  平面度std= {np.mean(planarities):.2f} ± {np.std(planarities):.2f} mm")
    print(f"  测量距离范围 {min(dists):.2f}–{max(dists):.2f} m")


def test_C_sim_model():
    print("\n===== C. 仿真投影模型 calib_model.project vs cv2.projectPoints =====")
    rng = np.random.default_rng(0)
    for cam in ["head_left", "head_right", "left_wrist", "right_wrist"]:
        doc = load_json(cam)
        K, dist = K_of(doc)
        intr = intrinsics_dict({"K": doc["K"], "dist": doc["dist"], "model": doc["model"]})
        # 在有效视场内采样像素 -> 反投影成射线 -> 取深度成3D点
        W, H = doc["resolution"]
        uv = rng.uniform([20, 20], [W - 20, H - 20], (500, 2)).astype(np.float64)
        rays = cv2.undistortPoints(uv.reshape(-1, 1, 2), K, dist).reshape(-1, 2)
        z = rng.uniform(0.2, 2.0, 500)
        P = np.stack([rays[:, 0] * z, rays[:, 1] * z, z], -1)
        px_cv = cv2.projectPoints(P, np.zeros(3), np.zeros(3), K, dist)[0].reshape(-1, 2)
        px_sim = sim_project("opencv", intr, P)
        err = np.abs(px_cv - px_sim).max()
        print(f"  {cam}: 500随机点最大差异 {err:.2e} px  {'OK' if err < 1e-6 else 'FAIL'}")


if __name__ == "__main__":
    test_A_undistort()
    test_B_triangulate()
    test_C_sim_model()
