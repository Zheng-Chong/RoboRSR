# dircheck.py -- joint direction / mapping check (doc 04 section 3), PC side
# For each arm: raise (validated joints only) -> per joint: capture, jog +0.05 rad, capture, jog back -> ready.
# Images + measured joint states go to frames_test/dircheck/<session>/ ; analysis runs on the server.
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

import arm_client as arm

HERE = Path(__file__).parent
PLAN = json.loads((HERE / "frames_test" / "dircheck" / "dircheck_plan.json").read_text(encoding="utf-8"))
SESSION = HERE / "frames_test" / "dircheck" / time.strftime("session_%Y%m%d_%H%M%S")
SESSION.mkdir(parents=True)
HOST = "192.168.123.164"
PORTS = {"left": 55557, "right": 55556}   # verified: 55557 is on the LEFT arm (g1d_infra names are swapped)
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
import os
JOG = float(os.environ.get("DC_JOG", "0.05"))
ONLY = [int(x) for x in os.environ.get("DC_JOINTS", "").split(",") if x != ""]   # arm joint indices 0..6
SETTLE = 1.5
sides = sys.argv[1:] or ["left", "right"]

ctx = zmq.Context.instance()


def grab(side, n=4):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{PORTS[side]}")
    for _ in range(n):
        data = s.recv()
    s.close(0)
    return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)


def capture(side, tag):
    time.sleep(SETTLE)
    st = arm.status()
    img = grab(side)
    cv2.imencode(".png", img)[1].tofile(str(SESSION / f"{tag}.png"))
    return {"arm_q": st["arm_q"], "arm_dq": st["arm_dq"], "t": st["t"], "image": f"{tag}.png"}


meta = {"jog_rad": JOG, "plan": PLAN, "records": []}
st = arm.status()
ready = np.array(PLAN["ready_arm_q"])
dev = np.abs(np.array(st["arm_q"]) - ready).max()
print(f"server state={st['state']} vmax={st['vmax']} | max deviation from ready pose {dev:.3f} rad")
if st["state"] != "idle" or dev > 0.08:
    sys.exit("abort: server not idle or arms not at the ready pose")

for side in sides:
    if PLAN.get(side) is None:
        print(f"[{side}] no raise pose in plan, skip"); continue
    off = 0 if side == "left" else 7
    tgt = np.array(arm.status()["arm_q_cmd"])
    tgt[off:off + 7] = [PLAN[side]["joints"][f"{side}_{j}_joint"] for j in ARM]
    if np.abs(tgt - np.array(arm.status()["arm_q_cmd"])).max() > 1e-3:
        print(f"[{side}] moving to check pose: {PLAN[side]['delta_from_ready']}")
        arm.move(tgt, seconds=4.0, timeout=120)
    signs = PLAN[side]["jog_sign"]
    for j, name in enumerate(ARM):
        if ONLY and j not in ONLY:
            continue
        motor = 15 + off + j
        d = signs[j] * JOG                       # sign chosen so the gripper moves up (FK)
        rec = {"side": side, "joint": f"{side}_{name}_joint", "motor": motor, "jog_cmd_rad": d}
        rec["before"] = capture(side, f"{side}_{j}_{name}_before")
        arm.jog(motor, d)
        rec["after"] = capture(side, f"{side}_{j}_{name}_after")
        arm.jog(motor, -d)
        dq_meas = np.array(rec["after"]["arm_q"]) - np.array(rec["before"]["arm_q"])
        k = int(np.argmax(np.abs(dq_meas)))
        rec["measured_largest_change"] = {"arm_index": k, "rad": round(float(dq_meas[k]), 4)}
        print(f"  {name:15s} motor {motor}: encoder change {dq_meas[off + j]:+.4f} rad "
              f"(largest change at arm index {k}, expected {off + j})")
        meta["records"].append(rec)
        (SESSION / "meta.json").write_text(json.dumps(meta, indent=1))
    back = np.array(arm.status()["arm_q_cmd"])
    back[off:off + 7] = ready[off:off + 7]
    if np.abs(back - np.array(arm.status()["arm_q_cmd"])).max() > 1e-3:
        print(f"[{side}] back to ready pose")
        arm.move(back, seconds=4.0, timeout=120)

(SESSION / "meta.json").write_text(json.dumps(meta, indent=1))
print("DONE", SESSION)
