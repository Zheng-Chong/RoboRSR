# lift_back_to_zero.py -- recover from the sag: elbows to 0 first (hands go up, off the board), then everything to 0
import numpy as np

import arm_client as arm

q = np.array(arm.status()["arm_q_cmd"])
print("start:", np.round(q, 3).tolist())
a = q.copy(); a[3] = 0.0; a[10] = 0.0
s = arm.move(a, seconds=3.0, timeout=90)
print("elbows up :", np.round(s["arm_q"], 3).tolist())
s = arm.move(np.zeros(14), seconds=3.0, timeout=90)
print("all zero  :", np.round(s["arm_q"], 3).tolist(), "max |q|", round(float(np.abs(s["arm_q"]).max()), 3))
