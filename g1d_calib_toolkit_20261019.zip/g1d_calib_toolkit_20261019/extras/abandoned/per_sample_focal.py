# per_sample_focal.py -- autofocus check: estimate the focal length from each single tilted board view
# (principal point + distortion fixed to the calibrated values, fx = fy) and relate it to the board distance.
# server, /usr/bin/python3.  usage: per_sample_focal.py <meas.json>
import json
import sys

import cv2
import numpy as np

m = json.load(open(sys.argv[1]))
rows = []
for s in m["samples"]:
    for o in s["observations"]:
        c = m["cameras"][o["camera"]]
        b = m["boards"][o["board"]]
        P = {int(p[0]): p[1:] for p in b["points_m"]}
        obj = np.array([P[i] for i in o["corner_ids"]], np.float32)
        img = np.array(o["pixels"], np.float32)
        K0, d0 = np.array(c["K"], np.float64), np.array(c["dist"], np.float64)
        flags = (cv2.CALIB_USE_INTRINSIC_GUESS | cv2.CALIB_FIX_PRINCIPAL_POINT | cv2.CALIB_FIX_ASPECT_RATIO |
                 cv2.CALIB_FIX_K1 | cv2.CALIB_FIX_K2 | cv2.CALIB_FIX_K3 | cv2.CALIB_ZERO_TANGENT_DIST * 0 |
                 cv2.CALIB_FIX_TANGENT_DIST)
        K = K0.copy()
        rms, K, d, rv, tv = cv2.calibrateCamera([obj], [img], tuple(c["resolution"]), K, d0.copy(), flags=flags)
        R = cv2.Rodrigues(rv[0])[0]
        centre = R @ obj.mean(0) + tv[0].ravel()
        ang = np.degrees(np.arccos(abs(R[:, 2] @ centre) / np.linalg.norm(centre)))
        rows.append((s["id"], len(obj), float(np.linalg.norm(centre)), float(K[0, 0]), float(ang), float(rms)))
rows.sort(key=lambda r: r[2])
print(f"calibrated fx = {m['cameras'][list(m['cameras'])[0]]['K'][0][0]:.1f}")
print("id            n   dist[m]  fx_single  view_deg  rms")
for r in rows:
    print(f"{r[0]:12s} {r[1]:3d}  {r[2]:6.3f}   {r[3]:7.1f}    {r[4]:5.1f}   {r[5]:.2f}")
d = np.array([r[2] for r in rows]); f = np.array([r[3] for r in rows]); w = np.array([r[4] for r in rows])
ok = w > 25           # focal length is only observable from tilted views
if ok.sum() >= 4:
    A = np.vstack([d[ok], np.ones(ok.sum())]).T
    k, b0 = np.linalg.lstsq(A, f[ok], rcond=None)[0]
    print(f"tilted views: fx vs distance slope {k:.1f} px/m, fx at 0.3 m {k * 0.3 + b0:.1f}, "
          f"spread (std) {f[ok].std():.1f} px, corr {np.corrcoef(d[ok], f[ok])[0, 1]:+.2f}")
