# analyze_misalign.py -- is the head-camera misalignment caused by camera calibration
# or by arm joint zero offsets?  (server: /usr/bin/python3 analyze_misalign.py)
#
# Model-based edge matching on the head stereo pair:
#   * silhouette per link group from the Isaac Lab render (mask) + numpy FK point labels
#   * each contour sample searches along its normal for the strongest real-image edge
#   * dex1 gripper links are EXCLUDED (URDF gripper geometry differs from the real one)
#   * torso shell is rigid to the head cameras -> its offset can only come from the camera
#   * arm links (shoulder/elbow/wrist motors) depend on 7 joints -> residual = joint zeros
# Hypotheses fitted on the same matches: none / camera-only / joints-only / both.
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import trimesh
import xml.etree.ElementTree as ET
from scipy.ndimage import distance_transform_edt
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints, inv  # noqa: E402

ROOT = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015")
ASSET = ROOT / "assembled_calib_20261016"
URDF = ASSET / "g1_d_upper_dex1_v4.urdf"
DATA = ROOT / "real_data/20261016/body_overlay/frames"
INTR = ROOT / "real_data/20261016/intrinsics"
SIM = Path("/dev/shm/isaac_work/render_lab_lower")
OUT = ROOT / "real_data/20261016/misalign_analysis"
OUT.mkdir(parents=True, exist_ok=True)

EYES = {"head_left": "body_head_L.png", "head_right": "body_head_R.png"}
GRIP_Q = -0.02          # gripper open, same as the render
SEARCH = 15.0           # px, normal search half-range
DEG = np.pi / 180.0


def group_of(link):
    if "dex1" in link:
        return ("L_grip" if link.startswith("left") else "R_grip")
    if link.startswith("left"):
        return "L_arm"
    if link.startswith("right"):
        return "R_arm"
    return "torso"


def region_of(link):
    g = group_of(link)
    if g not in ("L_arm", "R_arm"):
        return g
    side = g[0]
    if "shoulder" in link or "elbow" in link:
        return f"{side}_elbow"
    if "wrist_roll" in link:
        return f"{side}_forearm"
    return f"{side}_wristmotor"


# ---------------- robot + nominal state ----------------
robot = Robot(URDF)
qraw = json.loads((DATA / "q.json").read_text())
ARM_J = arm_joints("left") + arm_joints("right")
q0 = {}
for side in ["left", "right"]:
    for n, v in zip(arm_joints(side), qraw[side]):
        q0[n] = float(v)
for side in ["left", "right"]:
    for k in (1, 2):
        q0[f"{side}_dex1_finger_joint_{k}"] = GRIP_Q


def fk_all(links, dq=None):
    q = {k: np.array([v]) for k, v in q0.items()}
    if dq is not None:
        for j, d in zip(ARM_J, dq):
            q[j] = np.array([q0[j] + d])
    return {ln: robot.fk(ln, q, {}, None, 1)[0] for ln in links}


contract = {v["name"]: v for v in json.loads((ASSET / "camera_contract_v5.json").read_text())["views"]}

# ---------------- dense surface points per link (local frames) ----------------
def urdf_visuals():
    out = {}
    for link in ET.parse(URDF).getroot().iter("link"):
        for vis in link.iter("visual"):
            mesh = vis.find("geometry/mesh")
            if mesh is None:
                continue
            o = vis.find("origin")
            xyz = [float(x) for x in (o.get("xyz", "0 0 0") if o is not None else "0 0 0").split()]
            rpy = [float(x) for x in (o.get("rpy", "0 0 0") if o is not None else "0 0 0").split()]
            out.setdefault(link.get("name"), []).append((mesh.get("filename").replace("package://", ""), xyz, rpy))
    return out


rng = np.random.default_rng(0)
links, local_pts, link_id = [], [], []
for ln, vl in sorted(urdf_visuals().items()):
    if ln == "head_link":
        continue  # head cameras sit inside the head shell (hidden in the render too)
    for fn, xyz, rpy in vl:
        m = trimesh.load(str(ASSET / fn), force="mesh")
        m.apply_transform(np.block([[Rotation.from_euler("xyz", rpy).as_matrix(), np.array(xyz)[:, None]],
                                    [np.zeros((1, 3)), np.ones((1, 1))]]))
        n = int(np.clip(m.area * 6e5, 4000, 200000))
        p, _ = trimesh.sample.sample_surface(m, n, seed=0)
        if ln not in links:
            links.append(ln)
        local_pts.append(p)
        link_id.append(np.full(len(p), links.index(ln)))
local_pts = np.concatenate(local_pts)
link_id = np.concatenate(link_id)
print(f"[cloud] {len(local_pts)} points on {len(links)} links", flush=True)


def world_points(T_links):
    P = np.empty_like(local_pts)
    for i, ln in enumerate(links):
        sel = link_id == i
        T = T_links[ln]
        P[sel] = local_pts[sel] @ T[:3, :3].T + T[:3, 3]
    return P


# ---------------- camera model ----------------
Ks = {}
for eye in EYES:
    doc = json.loads((INTR / f"camera_intrinsics_{eye}.json").read_text())
    Ks[eye] = (np.array(doc["K"]), np.array(doc["dist"]), tuple(int(x) for x in doc["resolution"]))


def cam_poses(T_links, cam_param=None):
    """T_world_camworld for both eyes; cam_param = [rotvec(3), t(3)] applied in the
    left-eye camworld frame, rigidly moving the whole stereo head."""
    T_head = T_links["head_link"] if "head_link" in T_links else fk_all(["head_link"])["head_link"]
    TL = T_head @ np.array(contract["head_left"]["T_parent_camera_world_convention"])
    TR = T_head @ np.array(contract["head_right"]["T_parent_camera_world_convention"])
    if cam_param is not None:
        d = np.eye(4)
        d[:3, :3] = Rotation.from_rotvec(cam_param[:3]).as_matrix()
        d[:3, 3] = cam_param[3:6]
        TL2 = TL @ d
        TR = TL2 @ inv(TL) @ TR
        TL = TL2
    return {"head_left": TL, "head_right": TR}


def project(eye, T_cam, P):
    K = Ks[eye][0]
    Ti = inv(T_cam)
    Pc = P @ Ti[:3, :3].T + Ti[:3, 3]
    Po = Pc @ OPTICAL_FROM_CAMERA.T
    z = Po[:, 2]
    uv = (Po[:, :2] / z[:, None]) * np.array([K[0, 0], K[1, 1]]) + np.array([K[0, 2], K[1, 2]])
    return uv, z


# ---------------- build edge observations ----------------
T_nom = fk_all(links + ["head_link"])
P_nom = world_points(T_nom)
C_nom = cam_poses(T_nom)
obs = []          # dicts: eye, pidx, n, s, region
vis_store = {}

for eye, fn in EYES.items():
    K, dist, (W, H) = Ks[eye]
    real = cv2.undistort(cv2.imread(str(DATA / fn)), K, dist)
    simmask = cv2.imread(str(SIM / f"mask_{eye}.png"), cv2.IMREAD_GRAYSCALE) > 127

    # z-buffer of nearest point per pixel
    uv, z = project(eye, C_nom[eye], P_nom)
    ok = (z > 0.02) & (uv[:, 0] >= 0) & (uv[:, 0] < W - 0.5) & (uv[:, 1] >= 0) & (uv[:, 1] < H - 0.5)
    idx_ok = np.nonzero(ok)[0]
    pix = np.round(uv[ok]).astype(int)
    lin = pix[:, 1] * W + pix[:, 0]
    order = np.argsort(-z[ok])
    pidx_img = np.full(H * W, -1, np.int64)
    pidx_img[lin[order]] = idx_ok[order]
    pidx_img = pidx_img.reshape(H, W)
    # fill holes inside the rendered silhouette from nearest valid pixel
    invalid = pidx_img < 0
    _, (iy, ix) = distance_transform_edt(invalid, return_indices=True)
    pidx_full = pidx_img[iy, ix]
    zimg = np.where(simmask, z[pidx_full], np.inf)
    gid = {"torso": 0, "L_arm": 1, "R_arm": 2, "L_grip": 3, "R_grip": 4}
    gimg = np.vectorize(lambda i: gid[group_of(links[link_id[i]])])(pidx_full)
    gimg[~simmask] = -1

    # real-image directional gradients (Lab, blurred)
    lab = cv2.cvtColor(real, cv2.COLOR_BGR2LAB).astype(np.float32)
    lab = cv2.GaussianBlur(lab, (0, 0), 1.0)
    gx = [cv2.Sobel(lab[..., c], cv2.CV_32F, 1, 0, ksize=3) for c in range(3)]
    gy = [cv2.Sobel(lab[..., c], cv2.CV_32F, 0, 1, ksize=3) for c in range(3)]
    black = cv2.dilate((real.max(axis=2) < 8).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0

    samples = []
    for gname in ("torso", "L_arm", "R_arm"):
        mg = (gimg == gid[gname]).astype(np.uint8)
        if mg.sum() < 50:
            continue
        blur = cv2.GaussianBlur(mg.astype(np.float32), (0, 0), 2.0)
        bx = cv2.Sobel(blur, cv2.CV_32F, 1, 0, ksize=3)
        by = cv2.Sobel(blur, cv2.CV_32F, 0, 1, ksize=3)
        cnts, _ = cv2.findContours(mg, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        for c in cnts:
            for (x, y) in c[::2, 0, :]:
                if x < 6 or y < 6 or x > W - 7 or y > H - 7 or black[y, x]:
                    continue
                nvec = -np.array([bx[y, x], by[y, x]], np.float64)
                if np.linalg.norm(nvec) < 1e-4:
                    continue
                nvec /= np.linalg.norm(nvec)
                ox, oy = int(round(x + 4 * nvec[0])), int(round(y + 4 * nvec[1]))
                if not (0 <= ox < W and 0 <= oy < H):
                    continue
                # keep only occluding edges: outside is background or a farther group
                if simmask[oy, ox] and not (gimg[oy, ox] != gid[gname] and zimg[oy, ox] > zimg[y, x] + 0.03):
                    continue
                samples.append((x, y, nvec, gname))

    # normal search
    ss = np.arange(-SEARCH, SEARCH + 0.01, 0.5)
    for (x, y, nvec, gname) in samples:
        px = (x + ss * nvec[0]).astype(np.float32)[None, :]
        py = (y + ss * nvec[1]).astype(np.float32)[None, :]
        D = np.zeros(len(ss), np.float32)
        for c in range(3):
            sx = cv2.remap(gx[c], px, py, cv2.INTER_LINEAR)[0]
            sy = cv2.remap(gy[c], px, py, cv2.INTER_LINEAR)[0]
            D += np.abs(sx * nvec[0] + sy * nvec[1])
        k = int(np.argmax(D))
        if D[k] < 60 or k in (0, len(ss) - 1):
            continue
        far = np.abs(ss - ss[k]) > 3
        if far.any() and D[far].max() > 0.85 * D[k]:
            continue  # ambiguous (texture)
        pidx = int(pidx_full[y, x])
        obs.append({"eye": eye, "x": x, "y": y, "n": nvec, "s": float(ss[k]), "pidx": pidx,
                    "region": region_of(links[link_id[pidx]])})
    vis_store[eye] = (real, simmask)
    print(f"[obs] {eye}: {sum(o['eye'] == eye for o in obs)} edge matches from {len(samples)} samples", flush=True)

# ---------------- per-region 2D shift (robust) ----------------
def robust_shift(rows):
    N = np.array([r["n"] for r in rows])
    s = np.array([r["s"] for r in rows])
    w = np.ones(len(s))
    t = np.zeros(2)
    for _ in range(20):
        A = N * w[:, None]
        t = np.linalg.lstsq(A, s * w, rcond=None)[0]
        r = N @ t - s
        w = 1.0 / np.maximum(1.0, np.abs(r) / 1.5)
    r = N @ t - s
    return t, float(np.median(np.abs(r))), float(np.median(np.abs(s)))

region_table = {}
for eye in EYES:
    for reg in sorted({o["region"] for o in obs if o["eye"] == eye}):
        rows = [o for o in obs if o["eye"] == eye and o["region"] == reg]
        if len(rows) < 8:
            continue
        t, res_after, raw = robust_shift(rows)
        region_table[f"{eye}/{reg}"] = {"n": len(rows), "shift_px": t.round(2).tolist(),
                                       "shift_norm_px": round(float(np.linalg.norm(t)), 2),
                                       "median_abs_offset_px": round(raw, 2),
                                       "median_abs_after_shift_px": round(res_after, 2)}
        print(f"[shift] {eye:10s} {reg:14s} n={len(rows):4d} shift=({t[0]:+6.2f},{t[1]:+6.2f})px "
              f"|med|={raw:4.2f} -> {res_after:4.2f}", flush=True)

# ---------------- 3D hypothesis fits ----------------
use = [o for o in obs if o["region"] in ("torso",) or o["region"][2:] in ("elbow", "forearm", "wristmotor")]
eye_of = np.array([o["eye"] for o in use])
Nn = np.array([o["n"] for o in use])
S = np.array([o["s"] for o in use])
PI = np.array([o["pidx"] for o in use])
REG = np.array([o["region"] for o in use])
need_links = sorted({links[link_id[i]] for i in PI}) + ["head_link"]
obs_link = np.array([links[link_id[i]] for i in PI])
link_sel = {ln: np.nonzero(obs_link == ln)[0] for ln in set(obs_link)}
LP = local_pts[PI]

def predict(cam_p, dq):
    T = fk_all(need_links, dq)
    C = cam_poses(T, cam_p)
    P = np.empty((len(PI), 3))
    for ln, sel in link_sel.items():
        Tl = T[ln]
        P[sel] = LP[sel] @ Tl[:3, :3].T + Tl[:3, 3]
    uv = np.empty((len(PI), 2))
    for eye in EYES:
        sel = eye_of == eye
        uv[sel] = project(eye, C[eye], P[sel])[0]
    return uv

UV0 = predict(None, None)

def residuals(x, mode):
    cam_p = x[:6] if mode in ("cam", "both") else None
    dq = (x[6:] if mode == "both" else x) if mode in ("joint", "both") else None
    d = np.sum((predict(cam_p, dq) - UV0) * Nn, axis=1) - S
    prior = []
    if cam_p is not None:
        prior += list(cam_p[:3] / (5 * DEG)) + list(cam_p[3:6] / 0.02)
    if dq is not None:
        prior += list(np.asarray(dq) / (5 * DEG))
    return np.concatenate([d, 0.3 * np.array(prior)])

def summarize(d):
    out = {}
    for reg in sorted(set(REG)):
        sel = REG == reg
        out[reg] = round(float(np.median(np.abs(d[sel]))), 2)
    return out

fits = {}
fits["H0_none"] = {"x": [], "median_abs_px": summarize(-S)}
for mode, n in (("cam", 6), ("joint", 14), ("both", 20)):
    r = least_squares(residuals, np.zeros(n), args=(mode,), loss="soft_l1", f_scale=1.5,
                      diff_step=1e-4, max_nfev=200)
    d = residuals(r.x, mode)[:len(S)]
    entry = {"median_abs_px": summarize(d)}
    if mode in ("cam", "both"):
        c = r.x[:6]
        entry["camera"] = {"roll_x_deg": round(c[0] / DEG, 3), "pitch_y_deg": round(c[1] / DEG, 3),
                           "yaw_z_deg": round(c[2] / DEG, 3),
                           "t_mm": (np.array(c[3:6]) * 1000).round(1).tolist()}
    if mode in ("joint", "both"):
        dq = r.x[6:] if mode == "both" else r.x
        entry["joint_offsets_deg"] = {j: round(float(v) / DEG, 2) for j, v in zip(ARM_J, dq)}
    fits[{"cam": "H1_camera_only", "joint": "H2_joints_only", "both": "H3_camera_and_joints"}[mode]] = entry
    print(f"[fit] {mode:5s} {entry}", flush=True)

# camera-only fitted on torso alone: what does it predict for the arms?
torso_sel = REG == "torso"
def res_torso(x):
    d = np.sum((predict(x, None) - UV0) * Nn, axis=1) - S
    return np.concatenate([d[torso_sel], 0.3 * np.concatenate([x[:3] / (5 * DEG), x[3:] / 0.02])])
rt = least_squares(res_torso, np.zeros(6), loss="soft_l1", f_scale=1.5, diff_step=1e-4, max_nfev=200)
d_rt = np.sum((predict(rt.x, None) - UV0) * Nn, axis=1) - S
fits["H1b_camera_fit_on_torso_only"] = {
    "median_abs_px": summarize(d_rt),
    "camera": {"roll_x_deg": round(rt.x[0] / DEG, 3), "pitch_y_deg": round(rt.x[1] / DEG, 3),
               "yaw_z_deg": round(rt.x[2] / DEG, 3), "t_mm": (rt.x[3:] * 1000).round(1).tolist()}}
print(f"[fit] torso-only camera {fits['H1b_camera_fit_on_torso_only']}", flush=True)

json.dump({"region_shifts": region_table, "fits": fits,
           "notes": ["dex1 gripper links excluded (URDF gripper differs from the real one)",
                     "head_link excluded (cameras inside the head shell)",
                     "single frame / single arm pose: joint offsets are indicative only"]},
          open(OUT / "misalign_report.json", "w"), indent=1, ensure_ascii=False)

# ---------------- visualisation ----------------
COL = {"torso": (255, 200, 0), "L_elbow": (0, 0, 255), "L_forearm": (0, 128, 255), "L_wristmotor": (0, 255, 255),
       "R_elbow": (255, 0, 255), "R_forearm": (255, 0, 128), "R_wristmotor": (200, 100, 255)}
for eye, (real, simmask) in vis_store.items():
    vis = real.copy()
    cnts, _ = cv2.findContours(simmask.astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(vis, cnts, -1, (0, 255, 0), 1)
    for o in obs:
        if o["eye"] != eye:
            continue
        p0 = (int(o["x"]), int(o["y"]))
        p1 = (int(round(o["x"] + o["n"][0] * o["s"])), int(round(o["y"] + o["n"][1] * o["s"])))
        cv2.line(vis, p0, p1, COL.get(o["region"], (255, 255, 255)), 1)
        cv2.circle(vis, p1, 1, COL.get(o["region"], (255, 255, 255)), -1)
    big = cv2.resize(vis, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    cv2.imwrite(str(OUT / f"edge_matches_{eye}.jpg"), big, [cv2.IMWRITE_JPEG_QUALITY, 92])
print("[done]", OUT, flush=True)
