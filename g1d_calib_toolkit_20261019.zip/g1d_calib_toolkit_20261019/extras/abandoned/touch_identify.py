# touch_identify.py -- identify joint zeros + probe-tip offset + board pose from hand-guided touches.
# constraint per touch:  T_torso_dex1base(q + params) @ tip  ==  T_torso_board @ corner(corner_id)
# models: M0 = tip + board only (nominal joints);  M1 = + 5 joint zeros;  M2 = + zeros + rot_v (preset-auto set)
# usage (server, unitree_sim_env python):  touch_identify.py <touch.jsonl> <board_pose_measured.json> [out.json]
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

recs = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
bp = json.loads(Path(sys.argv[2]).read_text())
out_p = Path(sys.argv[3]) if len(sys.argv) > 3 else Path(sys.argv[1]).with_suffix(".result.json")
side = recs[0]["side"]
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
ALLJ = arm_joints("left") + arm_joints("right")
J = arm_joints(side)
base = f"{side}_dex1_base_link"
T_b0 = 0.5 * (np.array(bp["head_left"]["T_torso_board"]) + np.array(bp["head_right"]["T_torso_board"]))
U, _, Vt = np.linalg.svd(T_b0[:3, :3]); T_b0[:3, :3] = U @ Vt
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
OBJ = board.getChessboardCorners().astype(float)
Q = np.array([r["arm_q"] for r in recs]); CID = np.array([r["corner_id"] for r in recs])

ZERO = [f"{j}/zero" for j in J[1:6]]                       # shoulder_roll .. wrist_pitch (preset auto)
ROTV = [f"{j}/rot_v" for j in J[1:7]]                       # shoulder_roll .. wrist_yaw


def tip_world(qrow, p, tip):
    qa = {n: np.array([v]) for n, v in zip(ALLJ, qrow)}
    T = robot.fk(base, qa, p, None, 1)[0]
    return T[:3, :3] @ tip + T[:3, 3]


def board_pt(cid, bpar):
    R = Rotation.from_rotvec(bpar[:3]).as_matrix()
    T = T_b0.copy(); T[:3, :3] = T_b0[:3, :3] @ R; T[:3, 3] = T_b0[:3, 3] + bpar[3:6]
    return T[:3, :3] @ OBJ[cid] + T[:3, 3]


def residuals(x, names, idx):
    tip, bpar, jp = x[:3], x[3:9], x[9:]
    p = dict(zip(names, jp))
    return np.concatenate([tip_world(Q[i], p, tip) - board_pt(CID[i], bpar) for i in idx])


def tip_guess():
    # rough: mean over touches of (inverse base transform of the touched board point), nominal joints
    v = []
    for i in range(len(recs)):
        qa = {n: np.array([val]) for n, val in zip(ALLJ, Q[i])}
        T = robot.fk(base, qa, {}, None, 1)[0]
        v.append(T[:3, :3].T @ (board_pt(CID[i], np.zeros(6)) - T[:3, 3]))
    return np.mean(v, axis=0)


def fit(names, idx):
    x0 = np.concatenate([tip_guess(), np.zeros(6), np.zeros(len(names))])
    r = least_squares(residuals, x0, args=(names, idx), loss="soft_l1", f_scale=0.002, x_scale="jac")
    return r.x


def rms_mm(e):
    return float(np.sqrt(np.mean(np.sum(e.reshape(-1, 3) ** 2, axis=1))) * 1000)


allidx = np.arange(len(recs))
report = {"side": side, "n_touches": len(recs), "models": {}}
print(f"{side} arm: {len(recs)} touches on corners {sorted(set(CID.tolist()))}")
for label, names in (("M0_tip_board_only", []), ("M1_plus_zeros", ZERO), ("M2_plus_zeros_rotv", ZERO + ROTV)):
    x = fit(names, allidx)
    e_fit = residuals(x, names, allidx)
    loo = []
    for i in allidx:                                         # leave-one-out
        xi = fit(names, np.setdiff1d(allidx, [i]))
        loo.append(residuals(xi, names, [i]))
    e_loo = np.concatenate(loo)
    per = np.linalg.norm(e_fit.reshape(-1, 3), axis=1) * 1000
    report["models"][label] = {
        "fit_rms_mm": rms_mm(e_fit), "loo_rms_mm": rms_mm(e_loo), "max_fit_mm": float(per.max()),
        "tip_offset_mm": (x[:3] * 1000).round(2).tolist(), "board_correction": {"rot_deg": np.degrees(x[3:6]).round(2).tolist(),
                                                                                 "t_mm": (x[6:9] * 1000).round(1).tolist()},
        "joint_params_deg": {n: round(float(np.degrees(v)), 3) for n, v in zip(names, x[9:])}}
    print(f"\n[{label}] fit RMS {rms_mm(e_fit):.2f} mm (max {per.max():.2f}), leave-one-out RMS {rms_mm(e_loo):.2f} mm")
    print(f"   tip offset in {base} (mm): {np.round(x[:3] * 1000, 1).tolist()}; board corr rot(deg) "
          f"{np.round(np.degrees(x[3:6]), 2).tolist()} t(mm) {np.round(x[6:9] * 1000, 1).tolist()}")
    for n, v in zip(names, x[9:]):
        print(f"   {n:40s} {np.degrees(v):+7.3f} deg")
out_p.write_text(json.dumps(report, indent=1))
print("\nwritten", out_p)
