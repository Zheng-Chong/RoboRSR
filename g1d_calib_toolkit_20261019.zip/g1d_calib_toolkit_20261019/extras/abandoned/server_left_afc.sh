#!/bin/bash
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
S=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019/sessions
/usr/bin/python3 /dev/shm/isaac_work/af_correct.py $S/meas_B_left_1209.json $S/meas_B_left_1509.json
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== identify left, AF-compensated"
$PY identify.py $S/meas_B_left_1209_afc.json $S/meas_B_left_1509_afc.json --preset auto --refine-intrinsics --loss soft_l1 \
  --f-scale 1.0 --folds 5 --out $S/identify_left_1019_afc.json --params-out $S/params_left_1019_afc.json 2>&1 | grep -v realcam | tail -40
