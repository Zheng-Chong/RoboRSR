#!/bin/bash
# 在 /dev/shm 上建 IsaacSim 5.0 环境（根盘已满，全部走内存盘）
set -x
export HOME=/dev/shm/isaac_home
export TMPDIR=/dev/shm/tmp
export UV_CACHE_DIR=/dev/shm/uv_cache
export XDG_CACHE_HOME=/dev/shm/isaac_home/.cache
mkdir -p $HOME $TMPDIR $UV_CACHE_HOME /dev/shm/isaac_work
cd /dev/shm/isaac_work

# 1) python 3.11 venv（uv 自带 python 下载；失败则用镜像）
uv venv --python 3.11 /dev/shm/isaac_work/venv311 2>&1 | tail -5
if [ ! -f /dev/shm/isaac_work/venv311/bin/python ]; then
  export UV_PYTHON_INSTALL_MIRROR=https://mirror.nju.edu.cn/github-release/astral-sh/python-build-standalone
  uv venv --python 3.11 /dev/shm/isaac_work/venv311 2>&1 | tail -5
fi
/dev/shm/isaac_work/venv311/bin/python --version || exit 1

# 2) 装 isaacsim 5.0（先阿里云镜像，缺包再退回 pypi 官方）
VENV_PIP="uv pip install --python /dev/shm/isaac_work/venv311/bin/python"
$VENV_PIP --index-url https://mirrors.aliyun.com/pypi/simple/ "isaacsim[all,extscache]==5.0.0" 2>&1 | tail -15
if ! /dev/shm/isaac_work/venv311/bin/python -c "import isaacsim" 2>/dev/null; then
  echo "=== aliyun failed, retry pypi.org ==="
  $VENV_PIP --index-url https://pypi.org/simple "isaacsim[all,extscache]==5.0.0" 2>&1 | tail -15
fi
/dev/shm/isaac_work/venv311/bin/python -c "import isaacsim; print('ISAACSIM OK', isaacsim.__file__)" || exit 1
echo "=== ENV READY ==="
