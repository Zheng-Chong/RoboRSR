# extras：已弃用、旧版和诊断用脚本

这里的脚本**不属于正式流程**，保留下来是为了说明"试过什么、为什么不这样做"，或者在排查问题时偶尔有用。运行前先看文件开头的注释，很多脚本带有当时的绝对路径。

## abandoned/（已弃用，不要在正式流程里用）

| 文件 | 原来做什么 | 为什么弃用 |
|---|---|---|
| `af_lock_server.py`（机器人） | 替代 Unitree 的 teleimager 服务，自己打开三路相机并锁定腕相机对焦 | 需要停掉系统服务，**用户明确拒绝**；不要在没有机器人负责人许可的情况下运行 |
| `touch_teach.py`（机器人） | 人手拖动手臂（服务的 `free` 模式）把探针放到板角上记录编码器 | 手动示教方案被否决，改为全自动的 `robot/auto_touch.py` |
| `touch_identify.py` | 手动示教数据的辨识（指定板角点 ID） | 随示教方案一起弃用；自动版本是 `server/tools/touch_identify_auto.py` |
| `touch_targets_image.py` | 在头部相机图上标出示教目标点 A..H | 同上 |
| `af_correct.py`、`per_sample_focal.py`、`server_left_afc.sh` | 用单张图估计每个样本的焦距，在辨识前"补偿"自动对焦 | 补偿后残差反而从 ~5 px 升到 8–10 px：单图焦距估计的误差远大于 OpenCV 报告的不确定度，既不能证明也不能补偿自动对焦。改用 `identify.py --refine-intrinsics` |
| `render_sim.py`、`setup_isaac_env.sh` | 在 `/dev/shm` 自装 IsaacSim 5.0（pip，清华镜像），`URDFParseAndImportFile` 导入 URDF 后渲染 | **结论是错的**：导入后网格放在游离的 `/visuals` 组里，相机画面里机器人从未出图，当时误把叠图面板里的真机照片当成了重合。改用服务器上现成的 Isaac Lab 环境（`server/tools/render_isaaclab.py`） |
| `analyze_misalign.py` | 自动边缘匹配判断叠图错位来自相机还是关节 | 受底盘白板和地毯纹理干扰，结果不可靠，最终用人工 4 倍放大读数 |

## legacy/（被新版本取代）

| 文件 | 被什么取代 | 说明 |
|---|---|---|
| `collect.py`（PC） | `robot/collect_robot.py` + `run_queue.sh` | 从 PC 经 ssh 驱动采集，连接一断就中止；新版在机器人本机后台运行，并加了板漂移监控 |
| `go_home.py`（PC） | `robot/go_home.py` | 旧版只认"恰好停在某个姿态上"；新版支持 `--via`、`--near`、`--dry` |
| `takeover.sh`（机器人） | `robot/takeover2.sh` | 从 `calib_ready_pose.py` 首次接管用的；**没有确认新实例存活就结束旧进程**，正是 10-19 12:05 失控事故的那类做法。只作记录，不要再用 |
| `add_home_ok.py` | `server/tools/gen_poses.py` | 给旧姿态表补 `home_path_ok`；新版生成时直接算 |
| `swap_wrist_intrinsics.py` | — | 10-16 发现腕相机端口左右对调后，一次性交换内参文件名；`examples/intrinsics/` 已经是交换后的结果 |
| `raise_to_zero.py`（PC） | `pc/raise_to_zero2.py` | 新版多一步先解开肩 yaw 的扭转 |

## diagnostics/（只读诊断，偶尔有用）

| 文件 | 在哪跑 | 做什么 |
|---|---|---|
| `inspect_teleimager.sh`、`inspect_teleimager2.sh`、`grep_teleimager.sh` | 机器人 | 只读查看 teleimager 服务怎么启动、怎么打开相机、有没有对焦/曝光设置（`inspect_teleimager2.sh` 会运行 `sudo -n true` 检查是否需要密码，不会提权） |
| `list_cams.sh`、`usb_perm.sh` | 机器人 | 列出视频设备/USB 相机和权限 |
| `read_arm_q.py` | 机器人 | 读一次手臂关节角（`robot/peek_lowstate.py` 功能相同） |
| `residual_vs_torque.py` | 服务器 | 每个样本的标定残差和采集时关节力矩的相关性（结论：相关性弱，|r| ≤ 0.3） |
| `check_charuco_legacy.py`、`detect_charuco_dict.py` | PC | 判断打印的板用的是哪个 ArUco 字典、legacy 设置（结论：DICT_4X4_50，legacy 无影响）。需要 `PC_TOOLS_DIR` 指向含 `calib_data/` 的目录 |
| `compare_motors.py` | PC | 35 个电机的当前位置和之前会话开始时对比（腰/升降/非手臂关节是否漂移） |
| `show_board.py`、`test_detect_once.py` | PC | 没有打印条件时用屏幕全屏显示 ChArUco 板并测试检测（最早期用） |
