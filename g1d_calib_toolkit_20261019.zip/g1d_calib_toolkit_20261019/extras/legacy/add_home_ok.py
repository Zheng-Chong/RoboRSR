# add_home_ok.py -- annotate each pose with "home_path_ok": direct pose -> home (all-zero) segment passes the hull
# model (pd.segment_ok) and FK key-point clearance >= 4 cm.   server, unitree_sim_env python
import json
import sys
from pathlib import Path

import numpy as np

REALCAM = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
sys.path.insert(0, str(REALCAM))
import board_setups as bs  # noqa: E402
import pose_design as pd  # noqa: E402
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/poses")
TABLE_Z = float(sys.argv[1]) if len(sys.argv) > 1 else -0.094
MIN_CLEAR = float(sys.argv[2]) if len(sys.argv) > 2 else 0.04
EDGE = float(sys.argv[3]) if len(sys.argv) > 3 else 0.18
MARGIN, RADIUS = 0.02, 0.03
hdr = json.loads((DAY / "scene_header_B.json").read_text())
bs.TABLE_Z, bs.TABLE_EDGE_X = TABLE_Z + MARGIN, EDGE
zero = lambda side: {n: 0.0 for n in arm_joints(side)}  # noqa: E731
bs.idle_arm = zero; pd.idle_arm = zero
scene = bs.nominal_scene()
scene["cameras"] = hdr["cameras"]; scene["boards"]["table"] = hdr["boards"]["table"]
geo = bs.Geometry(scene)
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")


def fk_clear(side, q7):
    qa = {n: np.array([v]) for n, v in zip(arm_joints(side), q7)}
    for k in (1, 2):
        qa[f"{side}_dex1_finger_joint_{k}"] = np.array([-0.02])
    links = [f"{side}_elbow_link", f"{side}_wrist_roll_link", f"{side}_wrist_pitch_link", f"{side}_wrist_yaw_link",
             f"{side}_dex1_base_link", f"{side}_dex1_finger_link_1_tip", f"{side}_dex1_finger_link_2_tip"]
    return min(robot.fk(l, qa, {}, None, 1)[0][2, 3] for l in links) - RADIUS - TABLE_Z


for side in ("left", "right"):
    f = DAY / f"poses_{side}.json"
    doc = json.loads(f.read_text())
    home = np.zeros(7)
    other = zero("right" if side == "left" else "left")
    n_ok = 0
    for p in doc["setups"]["B_wrist_table_board"]["poses"]:
        q = np.array([p["joints"][n] for n in arm_joints(side)])
        c = min(fk_clear(side, q + t * (home - q)) for t in np.linspace(0, 1, 21))
        ok = bool(c >= MIN_CLEAR and pd.segment_ok(geo, side, None, q, home, other))
        p["home_path_ok"] = ok
        n_ok += ok
    f.write_text(json.dumps(doc, indent=1))
    print(f"[{side}] home_path_ok: {n_ok} of {len(doc['setups']['B_wrist_table_board']['poses'])}")
