# raise_to_zero.py -- hanging arms -> all-zero pose without scraping the chassis:
# 1) abduct shoulders (roll L +0.25 / R -0.25) so the hands clear the chassis/lift column
# 2) everything else to 0 while abducted (forearms swing up to horizontal)
# 3) roll back to 0
import numpy as np

import arm_client as arm

ROLL = 0.25
st = arm.status()
q = np.array(st["arm_q_cmd"])
print("start  :", np.round(q, 3).tolist())

step1 = q.copy(); step1[1] = ROLL; step1[8] = -ROLL
s = arm.move(step1, seconds=3.0, timeout=60)
print("step 1 (abduct) :", np.round(s["arm_q"], 3).tolist())

step2 = np.zeros(14); step2[1] = ROLL; step2[8] = -ROLL
s = arm.move(step2, seconds=5.0, timeout=120)
print("step 2 (forearms up):", np.round(s["arm_q"], 3).tolist())

s = arm.move(np.zeros(14), seconds=3.0, timeout=60)
print("step 3 (roll back) :", np.round(s["arm_q"], 3).tolist())
print("max |q| =", round(float(np.abs(s["arm_q"]).max()), 3))
