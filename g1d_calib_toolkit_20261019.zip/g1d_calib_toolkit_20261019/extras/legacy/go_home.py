# go_home.py -- bring one arm home ONLY if its commanded position matches a pose whose direct path home was checked
# usage: go_home.py <left|right>
import json
import sys
from pathlib import Path

import numpy as np

import arm_client as arm

side = sys.argv[1]
off = 0 if side == "left" else 7
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
doc = json.loads((Path(__file__).parent / "frames_test" / "poses" / f"poses_{side}.json").read_text(encoding="utf-8"))
st = arm.status()
cmd = np.array(st["arm_q_cmd"])
cur = cmd[off:off + 7]
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])
if np.abs(cur - home).max() < 0.01:
    sys.exit("already at home")
match = None
for p in doc["setups"]["B_wrist_table_board"]["poses"]:
    q = np.array([p["joints"][f"{side}_{j}_joint"] for j in ARM])
    if np.abs(q - cur).max() < 0.01:
        match = p
        break
if match is None or not match.get("home_path_ok"):
    sys.exit(f"refuse: commanded pose is {'unknown' if match is None else match['id'] + ' (home path not checked)'}")
print(f"{side} arm at {match['id']} (home path checked) -> home")
goal = cmd.copy(); goal[off:off + 7] = home
n = max(1, int(np.ceil(np.abs(goal - cmd).max() / 1.5)))
for k in range(1, n + 1):
    s = arm.move(cmd + (goal - cmd) * k / n, seconds=3.0, timeout=120)
print("home reached:", [round(v, 3) for v in s["arm_q"][off:off + 7]])
