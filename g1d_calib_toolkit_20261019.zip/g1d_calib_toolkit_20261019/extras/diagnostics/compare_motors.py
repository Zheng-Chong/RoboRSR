# compare_motors.py -- all 35 motor positions now vs Friday's session start (waist / lift / non-arm drift)
import json
from pathlib import Path

import numpy as np

import arm_client as arm

HERE = Path(__file__).parent
fri = json.loads((HERE / "sessions" / "calib_20261016_1950_B_wrist_table_board_left" / "session.json").read_text())
q_fri = np.array(fri["joint_state_start"]["all_motor_q"])
q_now = np.array(arm.status()["all_q"])
print("motor  friday    now     delta(deg)")
for i in range(35):
    if 15 <= i <= 28:
        continue
    d = np.degrees(q_now[i] - q_fri[i])
    flag = "  <==" if abs(d) > 2 else ""
    print(f"{i:5d} {q_fri[i]:8.3f} {q_now[i]:8.3f} {d:9.2f}{flag}")
