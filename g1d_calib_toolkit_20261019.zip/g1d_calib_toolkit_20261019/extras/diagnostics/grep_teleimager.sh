#!/bin/bash
# read-only: does teleimager expose focus / exposure control?
P=$(/home/unitree/miniconda3/envs/tv/bin/python -c 'import teleimager,os;print(os.path.dirname(teleimager.__file__))' 2>/dev/null)
echo "pkg=$P"
grep -rniE 'focus|exposure|set_ctrl|uvc\.|ctrl' "$P" --include=*.py 2>/dev/null | head -25
echo "--- server config files"
ls "$P"/*.yaml "$P"/config* 2>/dev/null
find / -xdev -name 'cam_config_server*.yaml' 2>/dev/null | head -3
