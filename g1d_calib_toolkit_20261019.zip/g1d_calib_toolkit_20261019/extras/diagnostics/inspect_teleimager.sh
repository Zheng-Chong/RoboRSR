#!/bin/bash
# read-only: how is teleimager launched / managed, and how does it open the cameras?
echo "--- processes"
ps -o pid,ppid,user,lstart,args -p $(pgrep -d, -f 'teleimager-server') 2>/dev/null | cut -c1-200
for p in $(pgrep -f 'teleimager-server'); do echo "pid $p parent: $(ps -o args= -p $(ps -o ppid= -p $p) | cut -c1-150)"; done
echo "--- systemd units mentioning teleimager / image"
systemctl list-units --all --no-pager 2>/dev/null | grep -iE 'teleimager|image|camera|eai' | head
grep -rlis teleimager /etc/systemd /lib/systemd /usr/lib/systemd /etc/supervisor* /unitree/module/*/etc 2>/dev/null | head
echo "--- server config"
C=/unitree/module/unitree_eai/unitree_eai_environment/service/teleimager/cam_config_server.yaml
cat "$C" 2>/dev/null | head -60
echo "--- image_server.py: uvc usage"
F=/home/unitree/unitree_eai_environment/service/teleimager/src/teleimager/image_server.py
grep -nE 'uvc\.|controls|frame_mode|avaible_modes|available_modes|zmq|bind|jpeg|imencode|port' "$F" | head -40
