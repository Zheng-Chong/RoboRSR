# detect_charuco_dict.py -- find which ArUco dictionary / layout the A3 ChArUco board uses
import glob
import os

import cv2
import numpy as np

D = os.environ.get("PC_TOOLS_DIR", ".")
cands = [os.path.join(D, "frames_test", "a3_board.png")]
cands += sorted(glob.glob(os.path.join(D, "calib_data", "**", "*.png"), recursive=True))[:40]

DICTS = [n for n in dir(cv2.aruco) if n.startswith("DICT_")]
best = {}
for p in cands:
    img = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_GRAYSCALE)
    if img is None:
        continue
    img = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    for dn in DICTS:
        det = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, dn)),
                                      cv2.aruco.DetectorParameters())
        corners, ids, _ = det.detectMarkers(img)
        n = 0 if ids is None else len(ids)
        if n:
            b = best.setdefault(dn, [0, set()])
            b[0] = max(b[0], n)
            b[1].update(int(i) for i in ids.ravel())
for dn, (n, ids) in sorted(best.items(), key=lambda kv: -kv[1][0])[:6]:
    print(f"{dn:22s} max_markers_in_one_image={n:3d} id_range={min(ids)}..{max(ids)} unique_ids={len(ids)}")
print("images scanned:", len(cands))
