# G1-D 真机→仿真标定工具包（2026-10-19 版）

这个工具包用来标定 Unitree G1-D 机器人，让 IsaacSim 里用的 URDF 和真机一致：仿真里求出的关节轨迹原样发给真机，得到同样的位姿。

**机器人**：G1-D = 轮式底盘 + 升降柱 + 两条 7 自由度手臂 + Dex1 夹爪 + 头部双目相机 + 左右腕相机。

**标定内容**：
- 四路相机内参（头部左/右目、左腕、右腕）
- 关节映射与正方向检查
- 手臂运动学：关节零位、轴扭转、关节原点平移、腕相机外参、双臂共享标定板时的肩部安装位姿
- 用闭合夹爪指尖自动触碰标定板，独立检验运动学结果、估计手臂相对头部的偏差
- 把结果写回 URDF（只改关节 `<origin>`，关节值仍是编码器值），在 IsaacSim 里和真机照片叠图对比

**这台机器人目前的结果**（2026-10-19）：视觉辨识残差约 5 px，没达到 1 px 验收线；用触碰数据独立检验，参数集 `params_dual_trans_1019` 把左臂误差从 5.3 mm 降到 1.6 mm，作为左臂运动学的候选结果；左肩相对头部还有约 17 mm（约 3°）的偏差，是肩部安装还是头部相机外参造成的，正在用 IsaacSim 叠图判断。详见 `docs/使用手册_zh.md` §9。

> 先读 `docs/安全规范_zh.md` 再动机器人。`examples/` 里的数据只适用于原来那台机器人。

## 目录

```text
README_zh.md              本文件
MANIFEST.md               每个文件的用途、运行位置、状态
SHA256SUMS.txt            所有文件的 SHA-256
docs/
  使用手册_zh.md           端到端流程：每步的输入、输出、命令、通过标准、典型数值
  安全规范_zh.md           从真机事故中总结的安全规则
  环境配置_zh.md           所有写死的主机/路径/端口及修改方法、常见坑
  项目记录_20261015-19.md  原始工作记录（脱敏副本），按时间记录进展和事故
robot/                    机器人上运行：手臂控制服务、采集队列、自动触碰、回 home/恢复
server/
  g1d_calib_20261015/     标定包本体：误差模型、辨识、位姿设计、写回 URDF、方法文档 docs/00–07
  tools/                  服务器端工具：姿态表、测量导出、触碰辨识、IsaacSim 渲染与叠图
  runs/                   10-19 实际使用的服务器运行脚本（作为模板）
pc/                       Windows PC 上运行：内参采集/求解、方向检查、测板位置、ssh 客户端
skills/g1d-robot-calibration/   Cursor Agent Skill（SKILL.md + reference.md）
examples/                 这台机器人的小数据样例（内参、关节映射、姿态表、参数、触碰记录）
extras/                   已弃用 / 旧版 / 诊断用脚本，附说明
```

## 三台机器

| 机器 | 目录 | 需要的环境 |
|---|---|---|
| 机器人（`ssh unitree`） | `robot/` | conda 环境 `tv`：numpy、scipy、opencv-contrib-python（≥ 4.7，要有 `cv2.aruco.CharucoDetector`）、pyzmq、unitree_sdk2py（DDS，`rt/lowcmd` / `rt/lowstate`） |
| GPU 服务器 | `server/` | Isaac Lab + IsaacSim 5.1 的 conda 环境（unitree_sim_env，记作 `$ISAAC_ENV`），含 numpy、scipy、trimesh、coal；`/usr/bin/python3` + opencv-contrib；名义资产（URDF + 网格） |
| PC（Windows） | `pc/` | ssh（配置好 `Host unitree`）；内参采集等需要 Python 3 + numpy、opencv-contrib-python、pyzmq；直连 DDS 还需要 Python 3.12 + cyclonedds + unitree_sdk2_python（可选） |

## 快速开始

1. **配置**：按 `docs/环境配置_zh.md` 设置 `ISAAC_ENV` / `ISAAC_PY`，检查机器人和服务器路径；在 PC 上配好 `ssh unitree`。
2. **部署**：把 `robot/`、模型文件和姿态表拷到机器人（`docs/使用手册_zh.md` §0.2）；把 `server/` 放到 GPU 服务器并生成真实内参副本（§0.3）。
3. **使能**：遥控器 `L2+B` → `L2+R2` 进调试模式；`peek_lowstate.py` 确认有状态；`start_server.sh` 启动手臂控制服务；双臂回 home（§0.4）。
4. **按手册第 1–8 步执行**：内参 → 方向检查 → 测板 + 姿态表 → 后台采集 → 导出 → 辨识 → 自动触碰 + 交叉验证 → 写回 URDF + 叠图。

最短的"看看能不能跑"路径（不动手臂）：

```bash
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/check_env.py"
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/peek_lowstate.py"
cd pc && python pull_frames.py            # 三路相机各抓一帧（需要 PC 端 Python 环境）
```

## 让 AI Agent 操作

`skills/g1d-robot-calibration/` 是一个 Cursor Agent Skill。把整个目录拷到 `~/.cursor/skills/`（个人）或项目的 `.cursor/skills/`（项目共享），Agent 在涉及 G1-D 标定、移动手臂、监控队列时会自动读取。Skill 里写了安全铁律、工作流清单、后台队列监控和出错恢复的方法；它要求 Agent 在任何会让手臂运动的操作前先征得用户许可。

## 没有包含的内容

- 名义资产的网格（`nominal/meshes/`，约 17 MB STL）：在 GPU 服务器的名义资产目录里。
- 图像会话、内参采集图、渲染图等大数据。
- 第三方 SDK（unitree_sdk2_python）和同事的仓库 g1d_infra。
- 任何 SSH 密钥、SSH 配置、密码。

完整的排除清单和原因见 `MANIFEST.md` 末尾。
