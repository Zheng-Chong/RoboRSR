#!/bin/bash
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
mkdir -p $R/repeat && cd $R/repeat && tar -xzf /dev/shm/isaac_work/repeat1609.tgz
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python /dev/shm/isaac_work/repeat_diff.py \
  $R/repeat/repeat_20261019_1609_left $R/poses_v2/scene_header_B.json $R/sessions/params_left_1019.json 2>&1 | grep -v realcam
echo DIFF_DONE
