# dircheck_analyze.py -- compare real vs predicted image motion of the table/board plane in the wrist camera
# for each +0.05 rad joint jog (server, /usr/bin/python3).  usage: dircheck_analyze.py <session_dir>
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, OPTICAL_FROM_CAMERA, Robot, arm_joints, inv  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
sess = Path(sys.argv[1])
meta = json.loads((sess / "meta.json").read_text())
hdr = json.loads((DAY / "poses" / "scene_header_B.json").read_text())
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
T_b = np.array(hdr["boards"]["table"]["T_parent_board"])
n_plane, p_plane = T_b[:3, 2], T_b[:3, 3]
ALLJ = arm_joints("left") + arm_joints("right")
sift = cv2.SIFT_create(3000)
bf = cv2.BFMatcher()


def cam_pose(side, arm_q):
    q = {n: np.array([v]) for n, v in zip(ALLJ, arm_q)}
    c = hdr["cameras"][f"{side}_wrist"]
    return robot.fk(c["parent"], q, {}, None, 1)[0] @ np.array(c["T_parent_camera"])


def backproject(side, T_cam, uv):
    c = hdr["cameras"][f"{side}_wrist"]
    K, dist = np.array(c["K"]), np.array(c["dist"])
    d = cv2.undistortPoints(uv.reshape(-1, 1, 2).astype(np.float64), K, dist).reshape(-1, 2)
    rays_opt = np.hstack([d, np.ones((len(d), 1))])
    rays = (T_cam[:3, :3] @ (OPTICAL_FROM_CAMERA.T @ rays_opt.T)).T
    o = T_cam[:3, 3]
    s = ((p_plane - o) @ n_plane) / (rays @ n_plane)
    return o + s[:, None] * rays, s


def project(side, T_cam, P):
    c = hdr["cameras"][f"{side}_wrist"]
    K, dist = np.array(c["K"]), np.array(c["dist"])
    Ti = inv(T_cam)
    Po = (P @ Ti[:3, :3].T + Ti[:3, 3]) @ OPTICAL_FROM_CAMERA.T
    uv, _ = cv2.projectPoints(Po, np.zeros(3), np.zeros(3), K, dist)
    return uv.reshape(-1, 2)


rows = []
for r in meta["records"]:
    side = r["side"]
    a = cv2.imread(str(sess / r["before"]["image"]), cv2.IMREAD_GRAYSCALE)
    b = cv2.imread(str(sess / r["after"]["image"]), cv2.IMREAD_GRAYSCALE)
    ka, da = sift.detectAndCompute(a, None)
    kb, db = sift.detectAndCompute(b, None)
    m = [x for x, y in bf.knnMatch(da, db, k=2) if x.distance < 0.75 * y.distance]
    ua = np.array([ka[x.queryIdx].pt for x in m]); ub = np.array([kb[x.trainIdx].pt for x in m])
    Ta, Tb_ = cam_pose(side, r["before"]["arm_q"]), cam_pose(side, r["after"]["arm_q"])
    P, s = backproject(side, Ta, ua)
    on_table = (s > 0.05) & (s < 1.2) & (P[:, 0] > 0.15) & (P[:, 0] < 0.80) & (np.abs(P[:, 1]) < 0.65)
    ua, ub, P = ua[on_table], ub[on_table], P[on_table]
    moving = np.linalg.norm(ub - ua, axis=1) > 1.0          # fingers move with the camera -> ~0 px
    ua, ub, P = ua[moving], ub[moving], P[moving]
    if len(ua) >= 8:
        H, inl = cv2.findHomography(ua, ub, cv2.RANSAC, 3.0)
        inl = inl.ravel().astype(bool)
        ua, ub, P = ua[inl], ub[inl], P[inl]
    if len(ua) < 6:
        rows.append({"joint": r["joint"], "motor": r["motor"], "n": int(len(ua)), "cos": None}); continue
    d_real = ub - ua
    d_pred = project(side, Tb_, P) - ua
    cos = float(np.sum(d_real * d_pred) / (np.linalg.norm(d_real) * np.linalg.norm(d_pred) + 1e-9))
    ratio = float(np.median(np.linalg.norm(d_real, axis=1)) / (np.median(np.linalg.norm(d_pred, axis=1)) + 1e-9))
    enc = np.array(r["after"]["arm_q"]) - np.array(r["before"]["arm_q"])
    k_expect = ALLJ.index(r["joint"])
    verdict = "OK" if cos > 0.9 else ("SIGN FLIPPED" if cos < -0.9 else "CHECK MAPPING")
    rows.append({"joint": r["joint"], "motor": r["motor"], "n": int(len(ua)), "cos": round(cos, 3),
                 "mag_ratio_real_over_pred": round(ratio, 2), "encoder_change_rad": round(float(enc[k_expect]), 4),
                 "mean_real_px": np.round(d_real.mean(0), 1).tolist(), "mean_pred_px": np.round(d_pred.mean(0), 1).tolist(),
                 "verdict": verdict})
    print(f"{r['joint']:28s} motor {r['motor']} n={len(ua):4d} cos={cos:+.3f} |real|/|pred|={ratio:.2f} "
          f"real={np.round(d_real.mean(0), 1).tolist()} pred={np.round(d_pred.mean(0), 1).tolist()} -> {verdict}")

(sess / "dircheck_result.json").write_text(json.dumps(rows, indent=1))
