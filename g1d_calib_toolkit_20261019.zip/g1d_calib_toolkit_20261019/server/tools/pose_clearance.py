# pose_clearance.py -- FK key-point clearance above the real table for every pose in the B pose tables
# (independent of the URDF collision hulls).   server, unitree_sim_env python
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
TABLE_Z = float(sys.argv[1]) if len(sys.argv) > 1 else -0.022
RADIUS = 0.03


def clearance(side, joints):
    qa = {n: np.array([v]) for n, v in joints.items()}
    for k in (1, 2):
        qa[f"{side}_dex1_finger_joint_{k}"] = np.array([-0.02])
    links = [f"{side}_elbow_link", f"{side}_wrist_roll_link", f"{side}_wrist_pitch_link", f"{side}_wrist_yaw_link",
             f"{side}_dex1_base_link", f"{side}_dex1_finger_link_1_tip", f"{side}_dex1_finger_link_2_tip"]
    return min(robot.fk(l, qa, {}, None, 1)[0][2, 3] for l in links) - RADIUS - TABLE_Z


for side in ("left", "right"):
    doc = json.loads((DAY / "poses" / f"poses_{side}.json").read_text())
    c = np.array([clearance(side, p["joints"]) for p in doc["setups"]["B_wrist_table_board"]["poses"]])
    print(f"[{side}] table_z={TABLE_Z}: clearance min {c.min() * 100:.1f} cm, median {np.median(c) * 100:.1f} cm | "
          f"< 2 cm: {np.sum(c < 0.02)}  2-4 cm: {np.sum((c >= 0.02) & (c < 0.04))}  >= 4 cm: {np.sum(c >= 0.04)}  (of {len(c)})")
