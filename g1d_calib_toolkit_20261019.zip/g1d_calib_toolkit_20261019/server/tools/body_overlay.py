# body_overlay.py — 服务器上运行：URDF网格表面点云按真实关节角+标定内参投影，与真机去畸变照片叠图
# 用法: python3 body_overlay.py --data <frames+q目录> --intrinsics <内参JSON目录> --out <输出目录>
import argparse
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
import trimesh

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import (NOMINAL, OPTICAL_FROM_CAMERA, Robot, arm_joints, inv,
                         intrinsics_dict, load_camera_contract, project, transform)

PALETTE = [(255, 80, 80), (80, 255, 80), (80, 130, 255), (255, 200, 60), (255, 80, 255),
           (80, 255, 255), (255, 160, 160), (160, 255, 160), (160, 160, 255), (200, 200, 80)]


def urdf_visuals(urdf_path):
    """link -> [(mesh_path, xyz, rpy, scale)]（URDF visual 元素）"""
    out = {}
    root = ET.parse(urdf_path).getroot()
    for link in root.iter("link"):
        for vis in link.iter("visual"):
            geo = vis.find("geometry")
            mesh = geo.find("mesh") if geo is not None else None
            if mesh is None:
                continue
            fn = mesh.get("filename")
            sc = mesh.get("scale")
            scale = float(sc.split()[0]) if sc else 1.0
            o = vis.find("origin")
            xyz = [float(x) for x in o.get("xyz", "0 0 0").split()] if o is not None and o.get("xyz") else [0, 0, 0]
            rpy = [float(x) for x in o.get("rpy", "0 0 0").split()] if o is not None and o.get("rpy") else [0, 0, 0]
            out.setdefault(link.get("name"), []).append((fn, xyz, rpy, scale))
    return out


def resolve_mesh(fn):
    p = fn.replace("package://", "")
    for cand in [NOMINAL / p, NOMINAL / "meshes" / Path(p).name, NOMINAL / p.split("meshes/")[-1],
                 NOMINAL / "meshes" / p.split("meshes/")[-1]]:
        if cand.exists():
            return cand
    return None


def rpy_to_R(rpy):
    from scipy.spatial.transform import Rotation
    return Rotation.from_euler("xyz", rpy).as_matrix()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--intrinsics", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--per-link-points", type=int, default=40000)
    a = ap.parse_args()
    data, intr_dir, outd = Path(a.data), Path(a.intrinsics), Path(a.out)
    outd.mkdir(parents=True, exist_ok=True)

    urdf = NOMINAL / "g1_d_upper_dex1_v4.urdf"
    robot = Robot(urdf)
    qraw = json.loads((data / "q.json").read_text())
    q = {}
    for side in ["left", "right"]:
        for n, v in zip(arm_joints(side), qraw[side]):
            q[n] = np.array([v])
    for wj in ["waist_yaw_joint", "waist_joint"]:
        if wj in robot.joints:
            q[wj] = np.array([qraw.get("waist", 0.0)])
            print(f"waist -> {wj} = {qraw.get('waist', 0.0):.4f}")

    visuals = urdf_visuals(urdf)
    print(f"{len(visuals)} links with visual meshes")
    contract = load_camera_contract(NOMINAL / "camera_contract_v5.json")

    # FK + 表面采样（root系）
    cloud_root, cloud_color = [], []
    n_mesh_fail = 0
    for li, (link, vlist) in enumerate(sorted(visuals.items())):
        T_link = robot.fk(link, q, {}, None, 1)[0]
        for fn, xyz, rpy, scale in vlist:
            mp = resolve_mesh(fn)
            if mp is None:
                n_mesh_fail += 1
                continue
            m = trimesh.load(str(mp), force="mesh")
            if isinstance(m, trimesh.Scene):
                m = trimesh.util.concatenate(tuple(m.geometry.values()))
            if scale != 1.0:
                m.apply_scale(scale)
            m.apply_transform(transform(rpy_to_R(rpy), np.array(xyz)))
            n = max(5000, min(a.per_link_points, int(m.area * 2e5)))
            pts = m.sample(n) if m.area > 0 else np.asarray(m.vertices)
            pts = (T_link[:3, :3] @ pts.T).T + T_link[:3, 3]
            cloud_root.append(pts)
            cloud_color.append(np.tile(PALETTE[li % len(PALETTE)], (len(pts), 1)))
    if n_mesh_fail:
        print(f"[warn] {n_mesh_fail} 个mesh未找到")
    P = np.concatenate(cloud_root)
    C = np.concatenate(cloud_color).astype(np.uint8)
    print(f"total surface points: {len(P)}")

    cams = {"head_left": "body_head_L.png", "head_right": "body_head_R.png",
            "left_wrist": "body_left_wrist.png", "right_wrist": "body_right_wrist.png"}
    for cam, img_fn in cams.items():
        doc = json.loads((intr_dir / f"camera_intrinsics_{cam}.json").read_text())
        K = np.array(doc["K"])
        dist = np.array(doc["dist"])
        intr = intrinsics_dict({"K": doc["K"], "dist": doc["dist"], "model": doc["model"]})
        spec = contract[cam]
        T_parent = robot.fk(spec["parent"], q, {}, None, 1)[0]
        T_cam = T_parent @ np.array(spec["T_parent_camera_world_convention"])
        Pc = (inv(T_cam)[:3, :3] @ P.T).T + inv(T_cam)[:3, 3]
        Po = Pc @ OPTICAL_FROM_CAMERA.T
        front = Po[:, 2] > 0.03
        uv = project("opencv", intr, Po[front])
        z = Po[front, 2]
        cols = C[front]
        W, H = doc["resolution"]
        ok = (uv[:, 0] >= 0) & (uv[:, 0] < W) & (uv[:, 1] >= 0) & (uv[:, 1] < H)
        uv, z, cols = uv[ok], z[ok], cols[ok]
        order = np.argsort(-z)  # 远->近，近的后画覆盖
        uv, cols = uv[order], cols[order]
        render = np.full((H, W, 3), 255, np.uint8)
        for (x, y), c in zip(uv.astype(int), cols):
            render[y, x] = c
        render = cv2.dilate(render, np.ones((3, 3), np.uint8))  # 点变斑块便于看
        img_path = data / img_fn
        real = cv2.imdecode(np.fromfile(str(img_path), dtype=np.uint8), cv2.IMREAD_COLOR)
        und = cv2.undistort(real, K, dist)
        blend = cv2.addWeighted(und, 0.55, render, 0.45, 0)
        side = np.hstack([und, render, blend])
        cv2.putText(side, "real(undist)", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(side, "sim render", (W + 10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(side, "blend", (2 * W + 10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        out = outd / f"overlay_{cam}.png"
        cv2.imencode(".png", side)[1].tofile(str(out))
        print(f"{cam}: 投影像素覆盖 {len(uv)} 点 -> {out}")


if __name__ == "__main__":
    main()
