# zero_pose_height.py -- lowest arm/gripper key point at the all-zero pose vs the table height (torso frame)
import sys
import numpy as np
sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot  # noqa: E402

robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
q = {}
for s in ("left", "right"):
    for k in (1, 2):
        q[f"{s}_dex1_finger_joint_{k}"] = np.array([0.0])
TABLE_Z_OLD = -0.022
for s in ("left", "right"):
    pts = {}
    for l in [f"{s}_elbow_link", f"{s}_wrist_roll_link", f"{s}_wrist_pitch_link", f"{s}_wrist_yaw_link",
              f"{s}_dex1_base_link", f"{s}_dex1_finger_link_1_tip", f"{s}_dex1_finger_link_2_tip"]:
        pts[l] = robot.fk(l, q, {}, None, 1)[0][:3, 3]
    low = min(pts, key=lambda k: pts[k][2])
    front = max(pts, key=lambda k: pts[k][0])
    print(f"[{s}] lowest key point {low}: z = {pts[low][2]:.3f} m (torso frame); "
          f"furthest forward {front}: x = {pts[front][0]:.3f} m")
print(f"old table top z = {TABLE_Z_OLD} m -> lowest point minus 3 cm radius vs table: see above")
