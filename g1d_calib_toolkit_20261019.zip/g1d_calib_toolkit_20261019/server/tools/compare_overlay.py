# compare_overlay.py -- head_left real frame (undistorted) vs rendered URDF variants (left arm, no gripper)
# outputs: overlay_<pid>.png (full frame, one contour colour per variant), crop_<pid>.png (zoom on the arm),
#          compare_report.json (median distance from each variant's arm contour to the nearest real image edge, px;
#          rough indicator only -- the board behind the arm has dense edges)
# usage: compare_overlay.py <render_out_dir> <camera_intrinsics_head_left.json>
import json
import sys
from pathlib import Path

import cv2
import numpy as np

OUT = Path(sys.argv[1])
intr = json.load(open(sys.argv[2]))
K, dist = np.array(intr["K"], float), np.array(intr["dist"], float)
rep = json.load(open(OUT / "render_report.json"))
tags = list(rep["variants"])
COL = {"nominal": (0, 0, 255), "dual_trans": (0, 220, 0), "dual_trans_mount": (255, 140, 0)}
NAME = {"nominal": "nominal", "dual_trans": "calibrated", "dual_trans_mount": "calibrated + shoulder mount"}

table = {t: [] for t in tags}
rows = []
for p in rep["poses"]:
    pid = p["pose"]
    und = cv2.undistort(cv2.imread(str(OUT / f"real_{pid}.png")), K, dist, None, K)
    g = cv2.GaussianBlur(cv2.cvtColor(und, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    dt = cv2.distanceTransform(255 - cv2.Canny(g, 40, 100), cv2.DIST_L2, 5)
    over = und.copy()
    h, w = g.shape
    box = None
    row = {"pose": pid}
    for t in tags:
        m = (cv2.imread(str(OUT / f"mask_{t}_arm_{pid}.png"), 0) > 127).astype(np.uint8)
        if m.sum() < 300:
            row[t] = None
            continue
        cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        pts = np.concatenate([c.reshape(-1, 2) for c in cs])
        pts = pts[(pts[:, 0] > 3) & (pts[:, 0] < w - 4) & (pts[:, 1] > 3) & (pts[:, 1] < h - 4)]
        d = float(np.median(dt[pts[:, 1], pts[:, 0]])) if len(pts) else None
        row[t] = d
        if d is not None:
            table[t].append(d)
        cv2.drawContours(over, cs, -1, COL.get(t, (255, 255, 255)), 1)
        x, y, bw, bh = cv2.boundingRect(m)
        box = (x, y, x + bw, y + bh) if box is None else (min(box[0], x), min(box[1], y), max(box[2], x + bw),
                                                           max(box[3], y + bh))
    for k, t in enumerate(tags):
        txt = f"{NAME.get(t, t)}: {row[t]:.1f}px" if row.get(t) is not None else f"{NAME.get(t, t)}: -"
        cv2.putText(over, txt, (8, 18 + 18 * k), cv2.FONT_HERSHEY_SIMPLEX, 0.5, COL.get(t, (255, 255, 255)), 1)
    cv2.putText(over, pid, (8, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.imwrite(str(OUT / f"overlay_{pid}.png"), over)
    if box is not None:
        x0, y0 = max(0, box[0] - 30), max(0, box[1] - 30)
        x1, y1 = min(w, box[2] + 30), min(h, box[3] + 30)
        crop = over[y0:y1, x0:x1]
        z = max(1, int(min(3, 600 / max(1, crop.shape[1]))))
        cv2.imwrite(str(OUT / f"crop_{pid}.png"), cv2.resize(crop, None, fx=z, fy=z, interpolation=cv2.INTER_NEAREST))
    rows.append(row)
    print(pid, {t: (None if row[t] is None else round(row[t], 2)) for t in tags})

summary = {t: (float(np.median(v)) if v else None) for t, v in table.items()}
print("median over poses (px):", {t: (None if v is None else round(v, 2)) for t, v in summary.items()})
json.dump({"per_pose": rows, "median_px": summary, "colours_bgr": COL}, open(OUT / "compare_report.json", "w"),
          indent=1)
