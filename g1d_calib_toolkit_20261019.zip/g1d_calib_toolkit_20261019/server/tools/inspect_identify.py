# inspect_identify.py -- print identified parameters + per-sample residuals (server, /usr/bin/python3)
import json
import sys

D = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/sessions"
tag = sys.argv[1] if len(sys.argv) > 1 else "preview_left_1950"
p = json.load(open(f"{D}/params_{tag}.json"))
r = json.load(open(f"{D}/identify_{tag}.json"))
print("== identified (deg / mm / px), std")
for k, v in p["values"].items():
    s = p["std"].get(k)
    unit = "mm" if k.split("/")[-1] in ("dx", "dy", "dz") else ("px" if k.startswith("intrinsics") else "deg")
    val = v * 1000 if unit == "mm" else (v if unit == "px" else p["values_deg_for_reading"].get(k, v))
    sd = (s * 1000 if unit == "mm" else (s if unit == "px" else s * 57.2958)) if s is not None else float("nan")
    print(f"  {k:45s} {val:9.3f} {unit}  (std {sd:.3f})")
print("== report keys:", list(r.keys()))
for key in ("per_sample", "per_sample_rms", "samples"):
    if key in r:
        print("== per sample:", key)
        items = r[key].items() if isinstance(r[key], dict) else enumerate(r[key])
        for k, v in items:
            print("  ", k, v if not isinstance(v, dict) else {kk: (round(vv, 2) if isinstance(vv, float) else vv) for kk, vv in v.items()})
