#!/bin/bash
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
cd /dev/shm/isaac_work
export OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
$PY eval_layout.py --shift 0.0  --out /dev/shm/isaac_work/layout_now    > layout_now.log 2>&1 &
$PY eval_layout.py --shift 0.25 --out /dev/shm/isaac_work/layout_close  > layout_close.log 2>&1 &
wait
echo LAYOUT_DONE > /dev/shm/isaac_work/layout.done
