# overlay_isaaclab.py -- real undistorted photo vs Isaac Lab render
# run on server: /usr/bin/python3 overlay_isaaclab.py
# outputs per camera (all 640x480 panels):
#   cmp_<cam>.jpg : [REAL photo | SIM render | REAL + green SIM outline]
import json
import os
import sys

import cv2
import numpy as np

ROOT = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016"
DATA = f"{ROOT}/body_overlay/frames"
INTR = f"{ROOT}/intrinsics"
SIM = sys.argv[1] if len(sys.argv) > 1 else "/dev/shm/isaac_work/render_lab"
OUT = sys.argv[2] if len(sys.argv) > 2 else f"{ROOT}/body_overlay_isaaclab"
os.makedirs(OUT, exist_ok=True)

REAL = {"head_left": "body_head_L.png", "head_right": "body_head_R.png",
        "left_wrist": "body_left_wrist.png", "right_wrist": "body_right_wrist.png"}
TITLE = {"head_left": "HEAD LEFT EYE", "head_right": "HEAD RIGHT EYE",
         "left_wrist": "LEFT WRIST CAM", "right_wrist": "RIGHT WRIST CAM"}

def label(img, text, color=(0, 255, 255)):
    cv2.rectangle(img, (0, 0), (img.shape[1], 30), (0, 0, 0), -1)
    cv2.putText(img, text, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)

for cam, fn in REAL.items():
    doc = json.load(open(f"{INTR}/camera_intrinsics_{cam}.json"))
    K = np.array(doc["K"]); dist = np.array(doc["dist"])
    real = cv2.imread(f"{DATA}/{fn}")
    und = cv2.undistort(real, K, dist)
    sim = cv2.imread(f"{SIM}/sim_raw_{cam}.png")
    mask = cv2.imread(f"{SIM}/mask_{cam}.png", cv2.IMREAD_GRAYSCALE)
    if sim is None or mask is None:
        print("[skip]", cam); continue

    outline = und.copy()
    cnts, _ = cv2.findContours((mask > 127).astype(np.uint8), cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(outline, cnts, -1, (0, 255, 0), 2)

    p1, p2, p3 = und.copy(), sim.copy(), outline
    label(p1, f"{TITLE[cam]}: REAL photo")
    label(p2, f"{TITLE[cam]}: ISAAC SIM render")
    label(p3, "REAL + green = SIM robot outline", (0, 255, 0))
    sep = np.full((und.shape[0], 4, 3), 255, np.uint8)
    cmp_img = np.hstack([p1, sep, p2, sep, p3])
    cv2.imwrite(f"{OUT}/cmp_{cam}.jpg", cmp_img, [cv2.IMWRITE_JPEG_QUALITY, 92])
    cv2.imwrite(f"{OUT}/outline_{cam}.jpg", outline, [cv2.IMWRITE_JPEG_QUALITY, 95])
    cv2.imwrite(f"{OUT}/sim_{cam}.jpg", sim, [cv2.IMWRITE_JPEG_QUALITY, 95])
    cv2.imwrite(f"{OUT}/real_{cam}.jpg", und, [cv2.IMWRITE_JPEG_QUALITY, 95])
    print("[ok]", cam, f"robot_px={100.0 * (mask > 127).mean():.1f}%")
