#!/bin/bash
# server_check_assets.sh -- nominal vs render asset identity, mesh references, 1509 session format
cd /root/unitree_sim_isaaclab
for f in real2sim_g1d_20261015/assembled/g1_d_upper_dex1_v4.urdf \
         real2sim_calib_20261015/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf \
         real2sim_g1d_20261015/assembled/camera_contract_v5.json \
         real2sim_calib_20261015/assembled_calib_20261016/camera_contract_v5.json; do
    echo "$(sha256sum $f | cut -c1-16)  $f"
done
echo "--- mesh refs"
grep -m3 -o 'filename="[^"]*"' real2sim_g1d_20261015/assembled/g1_d_upper_dex1_v4.urdf
ls -la real2sim_calib_20261015/assembled_calib_20261016/meshes | head -3
S1=real2sim_calib_20261015/real_data/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left
echo "--- session.json"
head -c 800 $S1/session.json; echo
echo "--- first sample"
head -n 1 $S1/samples.jsonl | head -c 1500; echo
echo "--- images"
ls $S1/images | head -8
ls $S1/images | wc -l
echo "--- contract diff (head views)"
diff <(python3 -m json.tool real2sim_g1d_20261015/assembled/camera_contract_v5.json) \
     <(python3 -m json.tool real2sim_calib_20261015/assembled_calib_20261016/camera_contract_v5.json) | head -30
