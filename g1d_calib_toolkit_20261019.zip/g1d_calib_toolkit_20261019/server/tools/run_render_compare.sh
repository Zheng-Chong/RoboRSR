#!/bin/bash
# run render_compare.py with the unitree_sim_env (same env/flags as run_render_isaaclab.sh)
# usage: GPU=4 OUT=/dev/shm/isaac_work/render_cmp_left bash run_render_compare.sh
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
GPU=${GPU:-4}
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
OUT=${OUT:-/dev/shm/isaac_work/render_cmp_left}
SESSION=${SESSION:-$R/real_data/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left}
V=$R/scratch/urdf_variants_20261019
VARIANTS="nominal=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf,dual_trans=$V/dual_trans/g1_d_upper_dex1_v4.urdf,dual_trans_mount=$V/dual_trans_mount/g1_d_upper_dex1_v4.urdf"
rm -rf "$OUT"
mkdir -p "$OUT" /dev/shm/tmp
export CUDA_VISIBLE_DEVICES=$GPU
export OMNI_KIT_ACCEPT_EULA=YES
export PYTHONUNBUFFERED=1
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6
export TMPDIR=/dev/shm/tmp
cd /dev/shm/isaac_work
timeout --signal=TERM --kill-after=20s 1500s $ENV/bin/python -u render_compare.py \
  --out "$OUT" --session "$SESSION" --variants "$VARIANTS" --every ${EVERY:-5} --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$GPU --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" \
  > "$OUT.log" 2>&1
echo "EXIT=$?" >> "$OUT.log"
echo RUN_FINISHED >> "$OUT.log"
