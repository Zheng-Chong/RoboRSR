# build_segments_left.py -- board segments for session calib_20261016_1950 (left arm pushed the board at poses 028-033)
# head-camera timeline: 000-027 centre y=-0.038 (stable), 028-032 moving, 033-049 y=-0.010 (stable)
import json
from pathlib import Path

import numpy as np

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
bp = json.loads((DAY / "poses" / "board_pose_measured_v2.json").read_text())
T1 = np.array(bp["head_left"]["T_torso_board"])
T1[:3, 3] = 0.5 * (np.array(bp["head_left"]["T_torso_board"])[:3, 3] + np.array(bp["head_right"]["T_torso_board"])[:3, 3])
T2 = T1.copy()
T2[:3, 3] += np.array([0.001, 0.028, 0.0])
s1 = [f"B_left_{i:03d}" for i in range(0, 28)]
s2 = [f"B_left_{i:03d}" for i in range(33, 50)]
seg = {"table_s1": {"ids": s1, "T_parent_board": T1.tolist()},
       "table_s2": {"ids": s2, "T_parent_board": T2.tolist()}}
(DAY / "sessions" / "segments_left_1950.json").write_text(json.dumps(seg, indent=1))
print("written", DAY / "sessions" / "segments_left_1950.json")
