# repeat_diff.py -- is the image change between repeated visits explained by the ENCODER change?
# For each capture vs the pose's A1/t0 reference: d_obs = observed corner shift, d_pred = shift predicted by the
# (identified) kinematic model from the measured encoders.  err = d_obs - d_pred.
# small err -> encoders + model are self-consistent;  large err -> unmeasured joint play (backlash) / AF.
# server, unitree_sim_env python.  usage: repeat_diff.py <repeat_dir> <scene_header.json> <params.json>
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from board_setups import visible_corners  # noqa: E402
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

d, hdr_p, par_p = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
rep = json.loads((d / "repeat.json").read_text())
side = rep["side"]
hdr = json.loads(Path(hdr_p).read_text())
params = json.loads(Path(par_p).read_text())["values"]
scene = {"root_link": "torso_link", "cameras": hdr["cameras"], "boards": hdr["boards"]}
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
ALLJ = arm_joints("left") + arm_joints("right")
cam = f"{side}_wrist"
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)


def observed(files):
    per = []
    for fn in files:
        g = cv2.imread(str(d / fn), cv2.IMREAD_GRAYSCALE)
        cc, ci, _, _ = det.detectBoard(cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC))
        if ci is not None:
            per.append({int(i): (p + 0.5) / 2 - 0.5 for i, p in zip(ci.ravel(), cc.reshape(-1, 2))})
    ids = [i for i in set().union(*[set(p) for p in per]) if sum(i in p for p in per) >= 3] if per else []
    return {i: np.median([p[i] for p in per if i in p], axis=0) for i in ids}


def predicted(q14, p):
    qa = {n: np.array([v]) for n, v in zip(ALLJ, q14)}
    links = {scene["cameras"][cam]["parent"], scene["boards"]["table"]["parent"]}
    frames = {l: robot.fk(l, qa, p, "torso_link", 1) for l in links}
    uv, mask, *_ = visible_corners(scene, frames, cam, "table", p=p)
    return uv[0]


groups = {}
for r in rep["records"]:
    groups.setdefault(r["pose"], []).append(r)
for label, p in (("identified", params), ("nominal", {})):
    errs, obs_mag, pred_mag = [], [], []
    print(f"\n=== model: {label}")
    print(f"{'pose':11s} {'visit':5s} {'ph':3s} {'n':>3s} {'|d_obs|':>8s} {'|d_pred|':>8s} {'err_rms':>8s}  mean err (du,dv)")
    for pose, rs in groups.items():
        o_ref = observed(rs[0]["files"]); u_ref = predicted(rs[0]["q_before"], p)
        for r in rs[1:]:
            o = observed(r["files"]); u = predicted(r["q_before"], p)
            ids = sorted(set(o) & set(o_ref))
            if len(ids) < 8:
                continue
            dobs = np.array([o[i] - o_ref[i] for i in ids])
            dpred = np.array([u[i] - u_ref[i] for i in ids])
            e = dobs - dpred
            rms = lambda x: float(np.sqrt(np.mean(np.sum(x ** 2, 1))))  # noqa: E731
            errs.append(rms(e)); obs_mag.append(rms(dobs)); pred_mag.append(rms(dpred))
            print(f"{pose:11s} {r['visit']:5s} {r['phase']:3s} {len(ids):3d} {rms(dobs):8.2f} {rms(dpred):8.2f} {rms(e):8.2f}  "
                  f"{np.round(e.mean(0), 2).tolist()}")
    big = [i for i, m in enumerate(obs_mag) if m > 2.0]
    print(f"summary ({label}): captures with |d_obs|>2px: err_rms median {np.median([errs[i] for i in big]):.2f} px, "
          f"max {max(errs[i] for i in big):.2f} px; |d_obs| median {np.median([obs_mag[i] for i in big]):.2f} px")
