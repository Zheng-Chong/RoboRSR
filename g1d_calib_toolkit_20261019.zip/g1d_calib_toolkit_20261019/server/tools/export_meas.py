# export_meas.py -- doc 03: ChArUco detection, multi-frame fusion, quality filters -> g1d_calib_measurements_v1
# usage: export_meas.py --session <dir> --out <meas.json> [--segments <segments.json>]
#   segments.json: {"table_s1": {"ids": [...], "T_parent_board": 4x4}, ...}  (board moved during a session)
# server, /usr/bin/python3
import argparse
import json
from pathlib import Path

import cv2
import numpy as np

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
ap = argparse.ArgumentParser()
ap.add_argument("--session", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--segments")
ap.add_argument("--header", default=str(DAY / "poses" / "scene_header_B.json"))
ap.add_argument("--min-corners", type=int, default=12)
ap.add_argument("--board-name", default="table", help="board name for this session (no segments)")
a = ap.parse_args()
sess = Path(a.session)
hdr = json.loads(Path(a.header).read_text())
info = json.loads((sess / "session.json").read_text())

board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.minMarkerPerimeterRate = 0.01
dp.adaptiveThreshWinSizeMin, dp.adaptiveThreshWinSizeMax, dp.adaptiveThreshWinSizeStep = 3, 53, 4
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners()
UP = 2

segments = json.loads(Path(a.segments).read_text()) if a.segments else None
seg_of = {}
if segments:
    for bname, s in segments.items():
        for i in s["ids"]:
            seg_of[i] = bname


def detect(img):
    big = cv2.resize(img, None, fx=UP, fy=UP, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(big)
    if ci is None:
        return {}
    uv = (cc.reshape(-1, 2) + 0.5) / UP - 0.5
    return {int(i): p for i, p in zip(ci.ravel(), uv)}


samples, report = [], []
for line in open(sess / "samples.jsonl"):
    r = json.loads(line)
    sid = r["id"]
    bname = seg_of.get(sid, a.board_name) if segments else a.board_name
    if segments and sid not in seg_of:
        report.append({"id": sid, "reject": "not in any board segment (board moving)"}); continue
    q = {k: 0.5 * (r["joints_before"]["q"][k] + r["joints_after"]["q"][k]) for k in r["joints_before"]["q"]}
    obs = []
    for cam, frames in r["frames"].items():
        if not cam.endswith("wrist"):
            continue
        c = hdr["cameras"][cam]
        K, dist = np.array(c["K"]), np.array(c["dist"])
        W, H = c["resolution"]
        imgs = [cv2.imdecode(np.fromfile(str(sess / f["file"]), np.uint8), cv2.IMREAD_GRAYSCALE) for f in frames]
        sharp = np.array([cv2.Laplacian(im, cv2.CV_64F).var() for im in imgs])
        keep = sharp >= 0.3 * np.median(sharp)
        dets = [detect(im) for im, k in zip(imgs, keep) if k]
        nf = len(dets)
        ids = sorted({i for d in dets for i in d})
        ids = [i for i in ids if sum(i in d for d in dets) >= 0.6 * nf]
        why = {}
        uv, jit = {}, {}
        for i in ids:
            pts = np.array([d[i] for d in dets if i in d])
            uv[i] = np.median(pts, axis=0)
            jit[i] = float(np.linalg.norm(pts.std(axis=0))) if len(pts) > 1 else 0.0
        for i in list(uv):
            u, v = uv[i]
            if u < 8 or v < 8 or u > W - 9 or v > H - 9:
                uv.pop(i); why["edge"] = why.get("edge", 0) + 1
            elif jit[i] > 0.5:
                uv.pop(i); why["jitter"] = why.get("jitter", 0) + 1
        rms = None
        while len(uv) >= max(6, a.min_corners):
            idl = sorted(uv)
            objp = OBJ[idl].astype(np.float64)
            imgp = np.array([uv[i] for i in idl], np.float64)
            ok, rv, tv = cv2.solvePnP(objp, imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
            ok, rv, tv = cv2.solvePnP(objp, imgp, K, dist, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
            proj, _ = cv2.projectPoints(objp, rv, tv, K, dist)
            res = np.linalg.norm(proj.reshape(-1, 2) - imgp, axis=1)
            rms = float(np.sqrt(np.mean(res ** 2)))
            if rms <= 1.0:
                break
            uv.pop(idl[int(np.argmax(res))]); why["pnp_outlier"] = why.get("pnp_outlier", 0) + 1
        if len(uv) < a.min_corners:
            report.append({"id": sid, "camera": cam, "reject": f"too few corners ({len(uv)})", "removed": why}); continue
        R = cv2.Rodrigues(rv)[0]
        centre = R @ OBJ.mean(0) + tv.ravel()
        ang = np.degrees(np.arccos(abs(R[:, 2] @ centre) / np.linalg.norm(centre)))
        if ang > 65:
            report.append({"id": sid, "camera": cam, "reject": f"view angle {ang:.0f} deg"}); continue
        idl = sorted(uv)
        sigma = max(0.2, float(np.median([jit[i] for i in idl])))
        obs.append({"type": "board_pixels", "camera": cam, "board": bname, "corner_ids": idl,
                    "pixels": [[round(float(uv[i][0]), 3), round(float(uv[i][1]), 3)] for i in idl], "sigma_px": round(sigma, 3)})
        report.append({"id": sid, "camera": cam, "board": bname, "n": len(idl), "pnp_rms": round(rms, 3),
                       "view_angle_deg": round(float(ang), 1), "sigma_px": round(sigma, 3), "frames_used": nf, "removed": why})
    if obs:
        samples.append({"id": sid, "joints": q, "observations": obs,
                        "image_files": {cam: r["frames"][cam][0]["file"] for cam in r["frames"] if cam.endswith("wrist")}})

cams_used = sorted({o["camera"] for s in samples for o in s["observations"]})
boards_used = sorted({o["board"] for s in samples for o in s["observations"]})
pts = [[i, float(p[0]), float(p[1]), float(p[2])] for i, p in enumerate(OBJ)]
tb = hdr["boards"]["table"]
boards = {}
for b in boards_used:
    spec = {k: v for k, v in tb.items() if k not in ("points_m", "T_parent_board", "measured_by")}
    spec["points_m"] = pts
    spec["T_parent_board"] = segments[b]["T_parent_board"] if (segments and b in segments) else tb["T_parent_board"]
    boards[b] = spec
out = {"format": "g1d_calib_measurements_v1", "root_link": "torso_link", "source_sessions": [sess.name],
       "cameras": {c: hdr["cameras"][c] for c in cams_used}, "boards": boards, "samples": samples}
Path(a.out).write_text(json.dumps(out, indent=1))
Path(a.out).with_suffix(".report.json").write_text(json.dumps(report, indent=1))
n_obs = sum(len(s["observations"]) for s in samples)
n_rej = sum(1 for x in report if "reject" in x)
print(f"{sess.name}: {len(samples)} samples / {n_obs} observations exported, {n_rej} rejected")
for x in report:
    print("  ", x)
