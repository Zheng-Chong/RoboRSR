# render_isaaclab.py -- unitree_sim_isaaclab stack (Isaac Lab + IsaacSim 5.1):
# real G1-D URDF -> USD -> Articulation posed at real joint angles,
# 4 cameras mounted per camera_contract_v5 with our calibrated K, render rgb+depth.
import argparse
import json
import os

import numpy as np
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--out", default="/dev/shm/isaac_work/render_lab")
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.enable_cameras = True
args.headless = True
app = AppLauncher(args).app

import cv2
import torch
from pxr import UsdLux
from scipy.spatial.transform import Rotation

import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import Articulation, ArticulationCfg
from isaaclab.sensors import Camera, CameraCfg
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg

ROOT = "/root/unitree_sim_isaaclab/real2sim_calib_20261015"
ASSET = f"{ROOT}/assembled_calib_20261016"
URDF = f"{ASSET}/g1_d_upper_dex1_v4.urdf"
CONTRACT = f"{ASSET}/camera_contract_v5.json"
DATA = f"{ROOT}/real_data/20261016/body_overlay/frames"
INTR = f"{ROOT}/real_data/20261016/intrinsics"
USD_DIR = "/dev/shm/isaac_work/usd_conv"   # root disk is full
os.makedirs(args.out, exist_ok=True)
os.makedirs(USD_DIR, exist_ok=True)

CAMS = ["head_left", "head_right", "left_wrist", "right_wrist"]
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
       "wrist_roll", "wrist_pitch", "wrist_yaw"]

# ---- 1) URDF -> USD (same converter settings as codex_pour/g1d_probe) ----
conv = UrdfConverter(UrdfConverterCfg(
    asset_path=URDF, usd_dir=USD_DIR, usd_file_name="g1d_calib.usd",
    fix_base=True, merge_fixed_joints=False, force_usd_conversion=True,
    make_instanceable=False,
    joint_drive=UrdfConverterCfg.JointDriveCfg(
        gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
print("[usd]", conv.usd_path, flush=True)

# ---- 2) sim + robot + light + cameras ----
dt = 1.0 / 120.0
sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(
    dt=dt, device=args.device, use_fabric=False, gravity=(0.0, 0.0, 0.0)))
stage = sim.stage

qraw = json.load(open(f"{DATA}/q.json"))
q_dict = {}
for side in ["left", "right"]:
    for jn, v in zip(ARM, qraw[side]):
        q_dict[f"{side}_{jn}_joint"] = float(v)

robot = Articulation(ArticulationCfg(
    prim_path="/World/Robot",
    spawn=sim_utils.UsdFileCfg(
        usd_path=conv.usd_path,
        rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(enabled_self_collisions=False)),
    init_state=ArticulationCfg.InitialStateCfg(pos=(0.0, 0.0, 0.0), joint_pos=q_dict),
    actuators={"all": ImplicitActuatorCfg(joint_names_expr=[".*"], stiffness=2000., damping=100.)}))

dome = UsdLux.DomeLight.Define(stage, "/World/Light")
dome.CreateIntensityAttr(750.0)

contract = json.load(open(CONTRACT))
mounts = {v["name"]: v for v in contract["views"]}
cams, Ks = {}, {}
for name in CAMS:
    doc = json.load(open(f"{INTR}/camera_intrinsics_{name}.json"))
    K = np.array(doc["K"], dtype=float)
    W, H = [int(x) for x in doc["resolution"]]
    Ks[name] = (K, W, H)
    cams[name] = Camera(CameraCfg(
        prim_path=f"/World/Cam_{name}", width=W, height=H,
        data_types=["rgb", "distance_to_image_plane"],
        update_latest_camera_pose=True,
        spawn=sim_utils.PinholeCameraCfg.from_intrinsic_matrix(
            intrinsic_matrix=K.flatten().tolist(), width=W, height=H,
            focal_length=24.0,  # default 1/width is so tiny the renderer ignores it (fixed 90deg FOV)
            clipping_range=(0.01, 20.0))))

sim.reset()

# ---- 3) pose robot at real joint angles ----
q = robot.data.default_joint_pos.clone()
missing = [n for n in q_dict if n not in robot.joint_names]
assert not missing, f"joints not found: {missing}"
for n, v in q_dict.items():
    q[0, robot.joint_names.index(n)] = v
# gripper opening was not logged with the frame; GRIP_MODE picks a limit (open/closed)
lims = robot.data.soft_joint_pos_limits[0].cpu().numpy()
grip_mode = os.environ.get("GRIP_MODE", "default")
for i, jn in enumerate(robot.joint_names):
    if jn in q_dict:
        continue
    lo, hi = float(lims[i, 0]), float(lims[i, 1])
    if grip_mode == "upper":
        q[0, i] = hi
    elif grip_mode == "lower":
        q[0, i] = lo
    print(f"[gripper joint] {jn} limits=({lo:.4f},{hi:.4f}) set={q[0, i].item():.4f}", flush=True)
robot.write_joint_state_to_sim(q, torch.zeros_like(q))

def pose_T(s):
    s = s.detach().cpu().numpy()
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix()
    T[:3, 3] = s[:3]
    return T

def mount_cameras():
    for name, cam in cams.items():
        m = mounts[name]
        parent = pose_T(robot.data.body_link_state_w[0, robot.body_names.index(m["parent"]), :7])
        T = parent @ np.array(m["T_parent_camera_world_convention"], dtype=float)
        xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
        cam.set_world_poses(torch.tensor([T[:3, 3].tolist()], device=args.device),
                            torch.tensor([xyzw[[3, 0, 1, 2]].tolist()], device=args.device),
                            convention="world")

def run_frames(n):
    for _ in range(n):
        robot.set_joint_position_target(q)
        robot.write_data_to_sim()
        sim.step(render=True)
        robot.update(dt)
        mount_cameras()
        for cam in cams.values():
            cam.update(dt)

run_frames(40)
qerr = (robot.data.joint_pos[0] - q[0]).abs().max().item()
print(f"[q err max] {qerr:.2e} rad", flush=True)

# head cameras sit inside the closed head_link shell mesh (real lens looks
# through a window) -> hide head_link visuals; head cams cannot see the head.
from pxr import Gf, Usd, UsdGeom
n_hidden = 0
for p in Usd.PrimRange(stage.GetPrimAtPath("/World/Robot")):
    if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link":
        UsdGeom.Imageable(p).MakeInvisible()
        n_hidden += 1
print(f"[head shell] hidden visuals prims: {n_hidden}", flush=True)

# principal point: write USD aperture offsets explicitly, then verify with probes
def set_offsets(name, use_pp):
    K, W, H = Ks[name]
    prim = stage.GetPrimAtPath(f"/World/Cam_{name}")
    f0 = 24.0
    prim.GetAttribute("focalLength").Set(f0)
    hap = f0 * W / K[0, 0]
    vap = f0 * H / K[1, 1]
    prim.GetAttribute("horizontalAperture").Set(float(hap))
    prim.GetAttribute("verticalAperture").Set(float(vap))
    off_h = (W / 2.0 - K[0, 2]) * hap / W if use_pp else 0.0
    off_v = (K[1, 2] - H / 2.0) * vap / H if use_pp else 0.0
    prim.GetAttribute("horizontalApertureOffset").Set(float(off_h))
    prim.GetAttribute("verticalApertureOffset").Set(float(off_v))

PROBE_C = [np.array([1.0, 0.0, 0.0]), np.array([1.0, -0.25, 0.25])]  # camworld (+X fwd, +Y left, +Z up)
probe_prims = []
for name in CAMS:
    m = mounts[name]
    parent = pose_T(robot.data.body_link_state_w[0, robot.body_names.index(m["parent"]), :7])
    T = parent @ np.array(m["T_parent_camera_world_convention"], dtype=float)
    for j, pc in enumerate(PROBE_C):
        pw = T[:3, :3] @ pc + T[:3, 3]
        sp = UsdGeom.Sphere.Define(stage, f"/World/Probe_{name}_{j}")
        sp.GetRadiusAttr().Set(0.012)
        UsdGeom.XformCommonAPI(sp.GetPrim()).SetTranslate(Gf.Vec3d(*[float(v) for v in pw]))
        probe_prims.append(sp.GetPrim())

def show_probes(flag):
    for p in probe_prims:
        (UsdGeom.Imageable(p).MakeVisible if flag else UsdGeom.Imageable(p).MakeInvisible)()

def grab(name):
    return cams[name].data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.int16)

def expected_px(name, use_pp):
    K, W, H = Ks[name]
    cx, cy = (K[0, 2], K[1, 2]) if use_pp else (W / 2.0, H / 2.0)
    out = []
    for pc in PROBE_C:
        out.append((cx - K[0, 0] * pc[1] / pc[0], cy - K[1, 1] * pc[2] / pc[0]))
    return out

def measure(use_pp):
    for name in CAMS:
        set_offsets(name, use_pp)
    show_probes(False); run_frames(15)
    base = {n: grab(n) for n in CAMS}
    show_probes(True); run_frames(15)
    res = {}
    for name in CAMS:
        d = np.abs(grab(name) - base[name]).max(axis=2) > 25
        nlab, lab, stats, cents = cv2.connectedComponentsWithStats(d.astype(np.uint8))
        found = [cents[i] for i in range(1, nlab) if stats[i, cv2.CC_STAT_AREA] >= 6]
        errs = []
        for ex in expected_px(name, use_pp):
            if not found:
                errs.append(None); continue
            dd = [np.hypot(f[0] - ex[0], f[1] - ex[1]) for f in found]
            k = int(np.argmin(dd))
            errs.append({"expected": [round(ex[0], 1), round(ex[1], 1)],
                         "measured": [round(float(found[k][0]), 1), round(float(found[k][1]), 1)],
                         "err_px": round(float(dd[k]), 2)})
        res[name] = errs
        print(f"[probe pp={use_pp}] {name:12s} {errs}", flush=True)
    show_probes(False)
    return res

probe_zero = measure(False)
probe_pp = measure(True)
run_frames(20)

# ---- 4) checks: link poses (compare to calib_model FK) + camera intrinsics/poses ----
report = {"q_err_max_rad": qerr, "links": {}, "cameras": {},
          "probe_offsets_zero": probe_zero, "probe_offsets_pp": probe_pp}
for ln in ["torso_link", "head_link", "left_elbow_link", "left_dex1_base_link", "right_dex1_base_link"]:
    if ln in robot.body_names:
        T = pose_T(robot.data.body_link_state_w[0, robot.body_names.index(ln), :7])
        report["links"][ln] = {"t": T[:3, 3].round(5).tolist(), "R": T[:3, :3].round(5).tolist()}
        print(f"[link] {ln:22s} t={np.round(T[:3, 3], 4).tolist()}", flush=True)

for name, cam in cams.items():
    K, W, H = Ks[name]
    Kr = cam.data.intrinsic_matrices[0].cpu().numpy()
    rgb = cam.data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
    dep = cam.data.output["distance_to_image_plane"][0].cpu().numpy().squeeze()
    mask = np.isfinite(dep) & (dep > 0) & (dep < 5.0)
    sim_bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    cv2.imwrite(f"{args.out}/sim_raw_{name}.png", sim_bgr)
    sim_bgr[~mask] = 0
    cv2.imwrite(f"{args.out}/sim_{name}.png", sim_bgr)
    cv2.imwrite(f"{args.out}/mask_{name}.png", (mask * 255).astype(np.uint8))
    report["cameras"][name] = {
        "K_target": K.round(3).tolist(), "K_rendered": Kr.round(3).tolist(),
        "pos_w": cam.data.pos_w[0].cpu().numpy().round(5).tolist(),
        "robot_pixel_pct": float(100.0 * mask.mean())}
    print(f"[cam] {name:12s} robot%={100.0 * mask.mean():5.1f}  "
          f"K_r fx={Kr[0, 0]:.1f} fy={Kr[1, 1]:.1f} cx={Kr[0, 2]:.1f} cy={Kr[1, 2]:.1f}  "
          f"(target {K[0, 0]:.1f} {K[1, 1]:.1f} {K[0, 2]:.1f} {K[1, 2]:.1f})", flush=True)

json.dump(report, open(f"{args.out}/render_report.json", "w"), indent=1)
print("[done]", flush=True)
os._exit(0)  # app.close() hangs on shutdown in this env and keeps the GPU busy
