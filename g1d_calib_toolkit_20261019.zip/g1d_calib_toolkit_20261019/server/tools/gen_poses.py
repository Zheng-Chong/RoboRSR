# gen_poses.py -- formal pose tables for the REAL setup (server, unitree_sim_env python)
# board pose measured by head stereo PnP; table collision model raised by a safety margin because the
# URDF gripper differs from the real one.
import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

REALCAM = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
sys.path.insert(0, str(REALCAM))
import board_setups as bs  # noqa: E402
import pose_design as pd  # noqa: E402
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
INTR = DAY / "intrinsics"

ap = argparse.ArgumentParser()
ap.add_argument("--board-json", default="/dev/shm/isaac_work/board_pose.json")
ap.add_argument("--table-edge-x", type=float, default=0.15)
ap.add_argument("--table-z", type=float, default=-0.022)
ap.add_argument("--table-margin", type=float, default=0.02, help="virtual table raise (m)")
ap.add_argument("--n", type=int, default=50)
ap.add_argument("--pool", type=int, default=600)
ap.add_argument("--out", default=str(DAY / "poses"))
ap.add_argument("--idle-zero", action="store_true", help="home / idle arm = all-zero pose (forearms forward)")
ap.add_argument("--min-clear", type=float, default=0.04, help="FK key-point clearance above the table (m)")
a = ap.parse_args()

if a.idle_zero:
    def _idle_zero(side):
        return {n: 0.0 for n in arm_joints(side)}
    bs.idle_arm = _idle_zero
    pd.idle_arm = _idle_zero
out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

bp = json.loads(Path(a.board_json).read_text())
T_l, T_r = np.array(bp["head_left"]["T_torso_board"]), np.array(bp["head_right"]["T_torso_board"])
T_board = T_l.copy(); T_board[:3, 3] = (T_l[:3, 3] + T_r[:3, 3]) / 2     # average both eyes

bs.TABLE_Z = a.table_z + a.table_margin
bs.TABLE_EDGE_X = a.table_edge_x

cb = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
pts = [[i, float(p[0]), float(p[1]), float(p[2])] for i, p in enumerate(cb.getChessboardCorners())]

scene = bs.nominal_scene()
scene["boards"]["table"] = dict(type="charuco", squares_x=10, squares_y=7, square_length_m=0.040,
                                marker_length_m=0.030, dictionary="DICT_4X4_50", legacy_pattern=False,
                                parent="torso_link", T_parent_board=T_board.round(6).tolist(), points_m=pts,
                                measured_by="head stereo PnP 2026-10-16 (L/R eye centre agree 4.3 mm)")
for cam in list(scene["cameras"]):
    f = INTR / f"camera_intrinsics_{cam}.json"
    d = json.loads(f.read_text())
    scene["cameras"][cam].update(K=d["K"], dist=d["dist"], resolution=d["resolution"], model=d.get("model", "opencv"))
    if "intrinsics_sigma" in d:
        scene["cameras"][cam]["intrinsics_sigma"] = d["intrinsics_sigma"]

header = {"format": "g1d_calib_measurements_v1", "root_link": "torso_link",
          "cameras": scene["cameras"], "boards": {"table": scene["boards"]["table"]},
          "notes": [f"table plane z={a.table_z} m (torso), near edge x~{a.table_edge_x} m; collision model raised "
                    f"{a.table_margin} m (real gripper differs from URDF)"]}
(out / "scene_header_B.json").write_text(json.dumps(header, indent=1))

pd.HERE = out
geo = bs.Geometry(scene)
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
rng = np.random.default_rng(7)
summary = {}
center = T_board[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_board[:3, 3]
con = {v["name"]: v for v in json.load(open(NOMINAL / "camera_contract_v5.json"))["views"]}
RADIUS = 0.03
# table plane from the MEASURED board plane (handles any board/torso tilt); board sits on ~6 mm cardboard
N_UP = -T_board[:3, 2] / np.linalg.norm(T_board[:3, 2])
P_TABLE = T_board[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_board[:3, 3] - 0.006 * N_UP


def fk_clear(side, q7):
    qa = {n: np.array([v]) for n, v in zip(arm_joints(side), q7)}
    for k in (1, 2):
        qa[f"{side}_dex1_finger_joint_{k}"] = np.array([-0.02])
    links = [f"{side}_elbow_link", f"{side}_wrist_roll_link", f"{side}_wrist_pitch_link", f"{side}_wrist_yaw_link",
             f"{side}_dex1_base_link", f"{side}_dex1_finger_link_1_tip", f"{side}_dex1_finger_link_2_tip"]
    return min(float((robot.fk(l, qa, {}, None, 1)[0][:3, 3] - P_TABLE) @ N_UP) for l in links) - RADIUS


def seg_clear(side, qa_, qb_, steps=20):
    return min(fk_clear(side, qa_ + t * (qb_ - qa_)) for t in np.linspace(0, 1, steps + 1))


# filter candidates BEFORE the D-optimal selection: pose clearance and camera-board distance
_orig_candidates = pd.candidates
CENTRE = T_board[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_board[:3, 3]


def _filtered_candidates(geo_, scene_, setup, side, n, rng_):
    if not str(setup).startswith("B"):
        return _orig_candidates(geo_, scene_, setup, side, n, rng_)
    cam = scene_["cameras"][f"{side}_wrist"]
    Tpc = np.array(cam["T_parent_camera"])
    kq, ko, stats = [], [], {}
    for _ in range(6):
        qs, origin, stats = _orig_candidates(geo_, scene_, setup, side, n, rng_)
        for qv, o in zip(qs, origin):
            q7 = np.array([qv[j] for j in arm_joints(side)]) if isinstance(qv, dict) else np.ravel(qv)
            if fk_clear(side, q7) < a.min_clear + 0.01:
                continue
            qd = {j: np.array([v]) for j, v in zip(arm_joints(side), q7)}
            Tc = robot.fk(cam["parent"], qd, {}, None, 1)[0] @ Tpc
            if np.linalg.norm(CENTRE - Tc[:3, 3]) > 0.55:
                continue
            kq.append(qv); ko.append(o)
        if len(kq) >= n:
            break
    print(f"[candidates] {side}: {len(kq)} kept after clearance/distance filter", flush=True)
    return kq[:n], ko[:n], stats


pd.candidates = _filtered_candidates


for side in ["left", "right"]:
    doc, summary[side] = pd.design(geo, robot, scene, side, a.n, a.pool, rng)
    # FK clearance gate on every pose and on the path actually taken (direct / via home)
    home_q = np.array([doc["home"][n] for n in arm_joints(side)])
    other = pd.idle_arm("right" if side == "left" else "left")

    def path_ok(segs):
        """all segments: hull model collision-free AND FK clearance >= min_clear; returns (ok, clearance)"""
        c = min(seg_clear(side, x, y) for x, y in segs)
        if c < a.min_clear:
            return False, c
        return all(pd.segment_ok(geo, side, None, x, y, other) for x, y in segs), c

    prev, n_skip = home_q, 0
    for p in doc["setups"]["B_wrist_table_board"]["poses"]:
        q = np.array([p["joints"][n] for n in arm_joints(side)])
        actual, c = None, None
        for name, segs in (("direct", [(prev, q)]), ("via_home", [(prev, home_q), (home_q, q)])):
            ok, cc = path_ok(segs)
            if ok:
                actual, c = name, cc
                break
        p["fk_clearance_cm"] = round(float(fk_clear(side, q)) * 100, 1)
        p["path_clearance_cm"] = round(float(c) * 100, 1) if c is not None else None
        p["transition_actual"] = actual
        p["skip"] = actual is None
        p["home_path_ok"] = bool(path_ok([(q, home_q)])[0])
        if p["skip"]:
            n_skip += 1          # robot stays at prev; next pose is planned from prev
        else:
            prev = q
    summary[side]["fk_gate"] = {"min_clear_m": a.min_clear, "skipped": n_skip}
    print(f"[{side}] FK gate: {n_skip} of {len(doc['setups']['B_wrist_table_board']['poses'])} poses skipped "
          f"(unverified transition or path clearance < {a.min_clear * 100:.0f} cm)", flush=True)
    (out / f"poses_{side}.json").write_text(json.dumps(doc, indent=1))
    cam = f"{side}_wrist"
    d = []
    for p in doc["setups"]["B_wrist_table_board"]["poses"]:
        q = {k: np.array([v]) for k, v in p["joints"].items()}
        T = robot.fk(con[cam]["parent"], q, {}, None, 1)[0] @ np.array(con[cam]["T_parent_camera_world_convention"])
        d.append(np.linalg.norm(center - T[:3, 3]))
    d = np.array(d)
    s = summary[side]["B_wrist_table_board"]
    print(f"[{side}] B poses={s['selected']} joint_std={s['d_optimal']['predicted_std_joint_rms_deg']:.4f}deg "
          f"cond={s['d_optimal']['joint_block_condition']:.1f} time={s['estimated_duration_min']}min "
          f"transitions={s['transitions']} | cam->board min/median/max = {d.min():.2f}/{np.median(d):.2f}/{d.max():.2f} m, "
          f"in 0.20-0.45 m: {np.mean((d > 0.2) & (d < 0.45)) * 100:.0f}%", flush=True)
summary["layout"] = {"board_center_torso_m": center.round(4).tolist(), "table_z": a.table_z,
                     "table_edge_x": a.table_edge_x, "table_margin": a.table_margin}
(out / "summary.json").write_text(json.dumps(summary, indent=1, default=str))
print("[done]", out, flush=True)
