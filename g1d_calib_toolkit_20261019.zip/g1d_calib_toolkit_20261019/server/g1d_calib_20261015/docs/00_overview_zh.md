# 00 总览：G1-D 真机—仿真运动学标定流程

## 目标

让仿真中求解的关节轨迹在真机上原样执行时，得到相同的物理位姿。做法：保持关节名与关节值语义等于真机编码器，把真机与标准 URDF 的差异吸收进 URDF 关节 `<origin>`（零位 = 绕本关节轴旋转；小安装旋转/平移），再据此重建 USD、物理合同与相机合同。误差模型与可辨识性见 `error_model_zh.md`。

已知的左肩约 2.6° roll 偏差等数值只是占位，全部以后重新实测；`params_test_left_shoulder_roll_2p6.json` 只用于打通流程。

唯一测量设备：标定板（ChArUco 或 AprilTag/AprilGrid），配合机器人自带的头部双目与左右腕相机。

## 流程

| 步骤 | 内容 | 在哪运行 | 文档 |
|---|---|---|---|
| 0 | 确认真机接口、关节映射、相机流、安全参数（全部"待实测"项） | 真机 PC | 本文 §4 |
| 1 | 每个相机的内参/畸变标定 | 真机 PC 采图，检测/求解可在任一端 | `01` |
| 2 | 几何标定数据采集：按位姿表运动、稳定、记录全部编码器 + 同步图像 | 真机 PC | `02` |
| 3 | 板角点检测、质量筛选、导出测量 JSON | 任一端（OpenCV） | `03` |
| 4 | 快速 sim-vs-real 对比（符号、方向、粗估） | 服务器 `compare_sim_real.py` | `04` |
| 5 | 完整辨识 `identify.py` → 参数 JSON | 服务器 | `03` §6、`error_model_zh.md` |
| 6 | 写回 URDF → 重建 USD / 物理 / 相机合同 → 回归检查 | 服务器 | `07` |
| 7 | 动态/跟踪匹配：阶跃/扫频、负载、延迟、重力下垂 → 拟合仿真驱动参数 | 真机采集，服务器拟合 | `05` |
| 8 | 真机回放验证：仿真验证过的 E009/E036 轨迹原样下发（先空载后带水） | 真机 PC + 服务器对比 | `06` |

推荐顺序：1 → 2（先做 B：腕相机看桌面板，每臂 50 位姿；再做双臂 A：头部双目看夹爪板）→ 3 → 4 → 5 → 6 → 8（空载）→ 7 → 8（带水）。第 4 步在第 2 步之前可以先用 5–10 个位姿做一次，提前发现符号和映射问题。

## 服务器端已有工具（`/root/unitree_sim_isaaclab/real2sim_calib_20261015/`）

| 文件 | 作用 |
|---|---|
| `calib_model.py` | URDF 解析、带参数 FK、投影模型、板角点、残差问题 |
| `identify.py` | 读取测量 JSON，估计参数，输出残差、可辨识性、k 折留出验证和参数 JSON |
| `compare_sim_real.py` | sim-vs-real 角点残差（名义 / 标定），单参数快速估计，叠加图 |
| `pose_design.py` → `poses_left.json` / `poses_right.json` | D 最优位姿表（含稳定参数、过渡方式、预测可见角点）|
| `apply_calibration.py` | 参数 JSON → 标定后 URDF（upper + full）|
| `build_assembly.py` + `tools/` | 标定后 URDF → USD / 物理合同 / 相机合同 / USD-FK 校验 |
| `tcp_effect.py` | 参数集对 TCP 和腕相机位姿的影响（E036 抓取位形）|
| `export_replay.py` | 从仿真运行 `trace.jsonl` 导出回放轨迹文件 |
| `synthetic_validation.py`、`board_setups.py` | 合成数据验证、可行位姿采样、碰撞/遮挡检查 |

## 真机 PC 端待实现的工具（由用户实现）

所有工具都基于一个抽象机器人接口（真实控制接口待实测，见 §4）：

```text
get_joint_state() -> {t: 秒, joints: {URDF 关节名: {q: rad, dq: rad/s, tau: Nm 或 null}}}
send_joint_targets(q: {URDF 关节名: rad}, duration: 秒)     # 同步插值到目标，返回时已开始执行
get_camera_frame(name) -> (image: HxWx3 uint8, t: 秒)        # name ∈ head_left, head_right, left_wrist, right_wrist
get_gripper_state(side) / send_gripper_target(side, value)  # 单位待实测
stop()                                                       # 软急停：保持当前位置
robot_ok() -> bool                                           # 模式/故障/温度检查
```

| 工具 | 输入 | 输出 | 文档 |
|---|---|---|---|
| `joint_mapping.json`（配置，不是程序） | 电机序号/方向/零点与 URDF 关节对应关系 | 见 `02` §3 | `02` |
| 相机采图 + 内参标定 | 实时相机流 | `camera_intrinsics_<相机>.json`（`g1d_camera_intrinsics_v1`）| `01` |
| 标定数据采集器 | `poses_<side>.json`、`joint_mapping.json` | 会话目录：`session.json`、`samples.jsonl`、`images/` | `02` |
| 角点检测导出器（也可在服务器跑） | 会话目录、内参文件、板描述 | `measurements_<会话>.json`（`g1d_calib_measurements_v1`）| `03` |
| 动态测试器 | 测试计划 JSON | `dyn_<会话>/commands.jsonl`、`states.jsonl`、`meta.json` | `05` |
| 轨迹回放器 | `replay_<run>.json`（`g1d_replay_trajectory_v1`） | `replay_<会话>/states.jsonl`、检查位姿图像、`meta.json` | `06` |

所有时间戳使用同一时钟（真机 PC 单调时钟，秒）。相机帧时间戳的含义（曝光开始/结束/到达）待实测，见 `02`。

## 4. 待实测项汇总（必须在真机上确认，文档中不预设数值）

接口与约定
1. 真机控制接口（SDK/通信方式、话题或 API 名称、控制模式、控制频率），以及抽象接口各函数的实现方式。
2. 电机/编码器到 URDF 关节的映射：序号、正方向、零点、单位；腰/升降/头部关节是否存在、是否可读。
3. 关节位置环参数（kp/kd 或厂家模式）、速度/力矩限制、是否允许外部设定。
4. 夹爪接口：指令和状态单位、与仿真 `finger_joint` 行程（−0.02…0.025 m）的换算。
5. 指令到运动的延迟、状态读数延迟、相机帧延迟与时间戳含义。

相机
6. 每个相机的实际分辨率、帧率、像素格式、是否已由驱动去畸变/裁剪/缩放、自动曝光/对焦能否关闭。
7. 内参与畸变模型（针孔+径向切向，或鱼眼），以及头部双目基线。仿真中的 640×480、fx≈245/222 只是合成实验占位值。
8. 头部相机名义外参是否与 `camera_contract_v5.json` 接近（相差几度/几厘米以内即可收敛）。

标定板与夹具
9. 板类型、字典、格数、格长/码长（打印后用卡尺实测）、平面度。
10. 夹爪板夹具的几何（板坐标系相对 `*_dex1_base_link` 的名义位姿）、是否有定位基准（决定能否辨识 wrist_yaw 零位）。
11. 桌面板固定方式与相对机器人的大致位置（名义值只需厘米级）。

安全与动态
12. 安全工作空间、关节限位余量、最大速度、碰撞检测/力矩阈值、急停方式。
13. 稳定判据（等待时间、速度阈值）在真机上的实际值。
14. 负载（杯+水）质量、动态测试允许的幅值和频率范围。
15. 编码器分辨率和回差（影响噪声模型 `joint_sigma`）。

数值
16. 所有关节零位偏差的数值和符号（包括左肩 roll 的 2.6°），由 `04`/`05` 流程重新测得。

## 交付物验收标准（建议）

- 辨识：留出残差接近像素噪声（≤1 px），`flags` 中无 `unidentifiable`；参数 std < 0.05°。
- 回放：抓取位形 TCP 位置误差 ≤5 mm、姿态 ≤1°（以板测量为准）；关节跟踪 RMS 误差阈值由 `05` 实测后确定。
