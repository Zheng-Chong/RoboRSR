# 03 板角点检测、质量筛选与测量文件导出

## 目的

把 `02` 的会话目录转换成 `identify.py` / `compare_sim_real.py` 读取的测量文件（`g1d_calib_measurements_v1`）。这一步可以在真机 PC 上做，也可以把会话目录拷到服务器后做（服务器环境有 OpenCV 4.11）。脚本待用户实现，本文给出精确格式和伪代码。

## 1. 坐标与编号约定（必须严格一致）

- 像素坐标：OpenCV 约定，(0,0) 是左上像素中心，u 向右、v 向下；畸变图像上的原始检测坐标，不要先去畸变。投影模型（含畸变）在 `calib_model.project` 里。
- 相机坐标：测量文件中的 `T_parent_camera` 使用 "+X 前、+Y 左、+Z 上" 约定（与 `camera_contract_v5.json` 的 `T_parent_camera_world_convention` 相同），代码内部再转到 OpenCV 光学系（`OPTICAL_FROM_CAMERA`）。
- 板坐标：OpenCV 板坐标系，原点在棋盘外角，x 沿 `squares_x`，y 沿 `squares_y`，z 指向板内（打印面朝 −z）。
- ChArUco 角点 ID：内角点按行优先编号 `id = r·(squares_x−1) + c`，板系坐标 `((c+1)·s, (r+1)·s, 0)`，`s` = 格长。这与 `calib_model.board_points` 一致。OpenCV 4.6 以后，`squares_y` 为偶数时存在 legacy pattern 差异，因此导出时一律把 `points_m` 显式写入文件：用 `board.getChessboardCorners()` 生成，ID 为数组下标。显式写入后以文件为准。
- AprilGrid：`calib_model` 默认第 k 个码的 4 个角 ID 为 `4k+c`，角顺序 (0,0)、(t,0)、(t,t)、(0,t)。不同检测器的角顺序不同（待确认），同样建议显式写 `points_m`。

## 2. 检测（伪代码，OpenCV ≥4.7）

```python
board = cv2.aruco.CharucoBoard((sx, sy), square_m, marker_m, cv2.aruco.getPredefinedDictionary(DICT))
board.setLegacyPattern(LEGACY)                     # 与打印时一致，待确认
det = cv2.aruco.CharucoDetector(board)
pts_board = board.getChessboardCorners()          # (N,3)，写入 points_m

def detect(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    corners, ids, _, _ = det.detectBoard(gray)     # 已做亚像素细化
    if ids is None: return {}
    return {int(i): c.ravel() for i, c in zip(ids.ravel(), corners)}
```

AprilTag/AprilGrid 可用 `cv2.aruco`（DICT_APRILTAG_36h11）检测每个码的 4 角，再用 `cv2.cornerSubPix` 细化。

## 3. 每个位姿的多帧融合与质量筛选

每个位姿、每个相机有 `frames_per_pose` 帧（默认 5）：

```python
obs = [detect(f) for f in frames]
ids = [i for i in union(obs) if count(i in o for o in obs) >= 0.6 * len(obs)]
uv  = {i: median([o[i] for o in obs if i in o]) for i in ids}
jit = {i: std([o[i] for o in obs if i in o]) for i in ids}
```

剔除规则（逐条记录剔除原因）：
1. 模糊：Laplacian 方差低于该相机中位数的 0.3 倍的帧不参与。
2. 边缘：距离图像边界 <8 px 的角点删除。
3. 抖动：`jit` >0.5 px 的角点删除（说明未稳定）。
4. 单图位姿一致性：用已标定内参对剩余角点做 `cv2.solvePnP`（IPPE 或迭代），重投影 RMS >1.0 px 时删除最大残差角点后重试，仍超限则整个观测作废。
5. 数量：A 设置每相机至少 6 个角点，B 至少 12 个，否则作废。
6. 视角：板法线与视线夹角 >65° 作废（透视压缩，角点精度差）。

`sigma_px` = max(0.2, 角点 `jit` 的中位数)，按观测给出（`identify.py` 用 1/sigma 作权重）。

## 4. 关节值

样本的 `joints` = `joints_before.q` 与 `joints_after.q` 的平均，只写 URDF 关节名（rad），包含全部可读关节。辨识只用到相机/板父 link 链上的关节，其余关节用于一致性检查。

## 5. 测量文件格式 `g1d_calib_measurements_v1`

```json
{
  "format": "g1d_calib_measurements_v1",
  "root_link": "torso_link",
  "source_sessions": ["calib_20261101_1030_B_wrist_table_board_left"],
  "cameras": {
    "left_wrist": {
      "parent": "left_dex1_base_link",
      "T_parent_camera": [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],
      "model": "opencv",
      "K": [[fx,0,cx],[0,fy,cy],[0,0,1]],
      "dist": [k1,k2,p1,p2,k3],
      "resolution": [W,H],
      "intrinsics_sigma": {"fx": 0.3, "fy": 0.3, "cx": 0.4, "cy": 0.4, "k1": 0.002, "k2": 0.002, "p1": 0.0002, "p2": 0.0002, "k3": 0.0005}
    }
  },
  "boards": {
    "table": {
      "type": "charuco", "dictionary": "DICT_5X5_100", "squares_x": 9, "squares_y": 7,
      "square_length_m": 0.0350, "marker_length_m": 0.0260,
      "parent": "torso_link",
      "T_parent_board": [[1,0,0,0.26],[0,-1,0,0.11],[0,0,-1,-0.088],[0,0,0,1]],
      "points_m": [[0, 0.035, 0.035, 0.0], [1, 0.070, 0.035, 0.0]]
    }
  },
  "samples": [
    {
      "id": "B_left_007",
      "joints": {"left_shoulder_pitch_joint": -0.31, "left_shoulder_roll_joint": 0.42},
      "observations": [
        {"type": "board_pixels", "camera": "left_wrist", "board": "table",
         "corner_ids": [0, 1, 2], "pixels": [[312.41, 201.77], [330.02, 202.10], [347.66, 202.51]], "sigma_px": 0.3}
      ],
      "image_files": {"left_wrist": "images/B_left_007/left_wrist_0.png"}
    }
  ]
}
```

字段说明
- `cameras.<name>.T_parent_camera`：名义外参，取自 `real2sim_g1d_20261015/assembled/camera_contract_v5.json` 中同名 view 的 `T_parent_camera_world_convention`（parent 也取自该文件）。`K`、`dist`、`model`、`resolution`、`intrinsics_sigma` 取自 `01` 的内参文件。
- `boards.<name>.T_parent_board`：板坐标系在父 link 中的名义位姿（夹具 CAD 或桌面摆放的粗测值）。夹爪板 parent 为 `<side>_dex1_base_link`，桌面板 parent 为 `torso_link`（要求躯干在会话中不动）。
- `points_m`：`[id, x, y, z]` 列表；有它时优先于 `squares_x` 等参数化描述。
- `samples[].joints`：URDF 关节名 → rad。缺失的关节按 0 处理，所以链上关节必须齐全。
- `image_files`（可选）：相对会话目录的路径，`compare_sim_real.py --overlay-dir` 用来画叠加图。
- 多个会话可分别导出，`identify.py a.json b.json` 合并读取；同名相机/板的描述必须完全一致（否则报错），不同会话的桌面板若位置不同，应命名为不同的板（如 `table_s1`、`table_s2`）。
- 可选 `pose6d` 观测类型（外部 6D 测量）在代码中已支持，本项目不使用。

服务器上的实际可运行示例：
- `examples/measurements_tiny_example.json`：2 个样本、每个观测只保留 4 个角点的小样例（A 双目 + B）。
- `examples/measurements_example_B_wrist_left.json` / `..._A_stereo_left.json`：50 位姿合成数据（含 `synthetic_truth_for_testing`，真机文件不需要此字段）。

## 6. 在服务器上辨识

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=$ISAAC_ENV/bin/python   # unitree_sim_env 的 python（GPU 服务器上）
# 先快速对比（04）
$PY compare_sim_real.py real_data/<日期>/meas_B_left.json --out real_data/<日期>/check_nominal.json
# 完整辨识：B 左右臂 + 双臂 A 合并
$PY identify.py real_data/<日期>/meas_*.json --preset auto --refine-intrinsics --loss soft_l1 --f-scale 1.0 --folds 5 \
    --out real_data/<日期>/identify_result.json --params-out real_data/<日期>/params_identified.json
```

结果检查
- `residuals`：每个相机-板块的 RMS 应接近 `sigma_px`（≤1 px）。中位数小但 p95 很大，说明有离群点，应查看 `compare_sim_real.py` 的逐样本残差。
- `validation.heldout_rms_by_block`：`calibrated` 应明显低于 `nominal_joints`（后者只估计相机/板，关节用名义值）。合成数据上的对比是 0.84 px vs 10.5 px。
- `identifiability.flags`：不应出现 `unidentifiable`；`strongly_correlated` 只出现在相机外参与主点之间是正常的。
- `identifiability.std`：关节参数 std 应 <0.05°。
- 输出的 `params_identified.json` 中 `sign_verified` 默认是 `false`；完成 `04` §3 的方向检查后再人工改为 `true`。

## 7. 检查清单

- [ ] `points_m` 由实际 board 对象生成；legacy pattern 设置与打印一致
- [ ] 内参、分辨率与采集一致；未对图像做去畸变或缩放
- [ ] 每个会话剔除率 <20%，剔除原因已记录
- [ ] `T_parent_camera` 与 `camera_contract_v5.json` 一致；`T_parent_board` 已按实际夹具/摆放填写
- [ ] 辨识残差接近噪声，留出残差下降明显
