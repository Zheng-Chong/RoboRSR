# 01 相机内参与畸变标定

## 目的

为 `head_left`、`head_right`、`left_wrist`、`right_wrist` 四个相机得到内参矩阵 K、畸变参数及其不确定度。几何标定（`identify.py`）以这些值为初值和先验。内参误差会和相机外参旋转强相关（主点 cx/cy ↔ 外参 rz/ry，相关系数 0.90–0.95），因此要单独、认真地标定。

## 待实测前提

- 每个相机实际输出的分辨率、帧率、像素格式；是否经过驱动去畸变、裁剪或缩放。标定和后续采集必须使用完全相同的流设置。
- 能否关闭自动对焦和自动曝光；不能关闭时要记录，并在标定和采集中保持相同光照。
- 畸变模型：先用 OpenCV 标准模型（k1,k2,p1,p2,k3）；如果视场 >110° 且边缘重投影误差明显偏大，再试鱼眼模型（`cv2.fisheye`，k1..k4），以留出重投影误差决定。`calib_model.project` 支持 `opencv` 和 `fisheye` 两种。

## 标定板

- 推荐 ChArUco（局部遮挡也能给出带 ID 的角点）。参数（字典、squares_x/y、格长、码长）在打印后用卡尺实测格长并记录；纸板需贴在平整硬板上，平面度 <0.5 mm。
- 内参标定用的板应足够大，在 0.3–0.8 m 距离能覆盖大部分视场；可与几何标定用的小板不同。
- AprilGrid 也可用，但角点顺序约定需确认（见 `03`）。

## 采集步骤

1. 机器人静止，手持标定板（或固定板、移动机器人头/手腕）。
2. 每个相机采 40–80 张：覆盖整个视场（四角、边缘必须有），板相对光轴倾斜 ±45°（绕两个轴），至少 3 个距离档。
3. 避免运动模糊：板静止后再取帧，或者对每个位置取 3 帧选最清晰的（Laplacian 方差最大）。
4. 头部双目：额外采 20–30 对同时可见的图像，用于双目外参（基线）检查。
5. 保存无损 PNG 和每张图的时间戳。

## 求解（伪代码）

```python
for cam in cameras:
    obj_pts, img_pts = [], []
    for img in images[cam]:
        corners, ids = detect_charuco(img, board)      # 见 03，亚像素细化
        if len(ids) < 12: continue
        obj_pts.append(board_xyz[ids]); img_pts.append(corners)
    rms, K, dist, rvecs, tvecs, std_intr, std_extr, per_view = cv2.calibrateCameraExtended(
        obj_pts, img_pts, image_size, None, None, flags=0)
    # 剔除 per_view 误差 > 3×中位数的图片后重算
    # 留出验证：随机 20% 图片不参与，求其 solvePnP 后的重投影误差
```

鱼眼模型使用 `cv2.fisheye.calibrate`，ChArUco 角点需整理成每张图 Nx1x3 / Nx1x2。

## 验收

- 总 RMS ≤0.3 px（标准模型）/ ≤0.4 px（鱼眼）；留出 RMS 不超过训练 RMS 的 1.3 倍。
- 角点覆盖热图在四角都有数据。
- fx、fy、cx、cy 的标准差 <0.5 px（来自 `std_intr`）。
- 头部双目：`cv2.stereoCalibrate`（固定各自内参）得到的基线与设计值一致（设计值待实测/查厂家资料）；该外参只作检查，最终外参由 `identify.py` 给出。

## 输出文件 `camera_intrinsics_<camera>.json`

```json
{
  "format": "g1d_camera_intrinsics_v1",
  "camera": "head_left",
  "resolution": [W, H],
  "model": "opencv",
  "K": [[fx, 0, cx], [0, fy, cy], [0, 0, 1]],
  "dist": [k1, k2, p1, p2, k3],
  "intrinsics_sigma": {"fx": 0.3, "fy": 0.3, "cx": 0.4, "cy": 0.4, "k1": 0.002, "k2": 0.002, "p1": 0.0002, "p2": 0.0002, "k3": 0.0005},
  "rms_px": 0.21, "heldout_rms_px": 0.25, "n_images": 62,
  "board": {"type": "charuco", "dictionary": "DICT_5X5_100", "squares_x": 9, "squares_y": 7, "square_length_m": 0.0350, "marker_length_m": 0.0260},
  "stream": {"fps": 30, "pixel_format": "...", "auto_exposure": false, "autofocus": false, "driver_rectified": false},
  "camera_serial": "...", "created": "2026-..-..T..:..:.."
}
```

- 鱼眼时 `"model": "fisheye"`，`dist` 为 `[k1, k2, k3, k4]`。
- `intrinsics_sigma` 取 `std_intr` 的 1–2 倍；`identify.py --refine-intrinsics` 把它用作先验。键名必须与 `calib_model.INTRINSIC_KEYS` 一致。
- 这些字段会原样拷入测量 JSON 的 `cameras.<name>`（见 `03` §5）。

## 检查清单

- [ ] 分辨率 / 帧率 / 格式与几何采集一致
- [ ] 自动对焦、自动曝光状态已记录（能关则关）
- [ ] 驱动是否已去畸变：若是，`dist` 全 0，并注明
- [ ] 板格长已卡尺实测
- [ ] 四个相机都有文件，RMS 与留出 RMS 达标
- [ ] 文件已拷到服务器 `real2sim_calib_20261015/real_data/<日期>/intrinsics/`
