# 02 几何标定数据采集工具（真机 PC，待用户实现）

## 目的

按 `poses_left.json` / `poses_right.json` 让手臂依次到达标定位姿，完全静止后同时记录全部编码器值（含腰、升降、头部及双臂）和所需相机的同步图像，输出会话目录，供 `03` 检测导出、`identify.py` 辨识。

## 1. 两种标定设置

| 设置 | 板 | 相机 | 位姿表中的键 | 关节信息来源 |
|---|---|---|---|---|
| A | 刚性固定在 `*_dex1_base_link`（夹爪基座）上的小板 `gripper_<side>` | `head_left`、`head_right`（同时取帧）| `setups.A_head_board_on_gripper` | 运动臂 7 关节 + 躯干链 |
| B | 固定在桌面（机器人前方）的大板 `table` | 运动臂腕相机 `<side>_wrist` | `setups.B_wrist_table_board` | 运动臂 7 关节；要求躯干/腰/升降在整个会话中不动 |

推荐：每臂 B 50 位姿 + A 50 位姿（每表约 4.5 min 运动时间，不含操作）。双臂 A 数据共享头部相机，可把左右肩的相对安装误差分开（见 `error_model_zh.md`）。

## 2. 标定板安装

夹爪板（A）
- 板必须刚性连接在夹爪基座（`dex1_base_link` 所在的刚体）上，不能夹在手指之间（手指有间隙和柔性）。建议 3D 打印或铝件夹具，螺钉固定在夹爪壳体上，板面朝外，离开手指运动范围。
- 夹具几何（板坐标系原点和方向相对 `*_dex1_base_link`）按 CAD 给出名义值 `T_parent_board`，精度到 5 mm / 3° 以内即可收敛。若夹具有定位销/基准面，加工精度可作为先验（σ≈0.3°/0.5 mm），使 `wrist_yaw` 零位可辨识；否则 wrist_yaw 零位不可辨识（被板安装吸收）。
- 采集期间夹爪保持一个固定开度（待实测：用哪个指令值不与夹具干涉）。
- 碰撞模型：`pose_design.py` 默认夹爪板为 5×4 格、28 mm 格长、中心位于 `dex1_base` 系 (0.02, 0, 0.095) m，板面朝 +Z。这些都是占位值；实际夹具确定后，把板描述写进测量头文件并用 `pose_design.py --scene` 重新生成位姿表。

桌面板（B）
- 粘在平整刚性底板上，底板用夹钳固定在桌面，整个会话中不移动、不触碰。
- 记录板相对机器人的大致位置（厘米级即可）。位姿表默认板中心在躯干系 (0.40, 0, 桌面高度)，桌面高度为躯干系 z=−0.09 m（占位）；实际值不同时需重新生成位姿表。

## 3. 关节映射文件 `joint_mapping.json`（采集前必须实测确认）

```json
{
  "format": "g1d_joint_mapping_v1",
  "robot_serial": "...",
  "joints": {
    "left_shoulder_pitch_joint": {"motor_index": "待实测", "sign": "待实测(+1/-1)", "offset_rad": 0.0, "unit": "rad"},
    "...": {}
  },
  "non_arm_joints_recorded": ["待实测：腰、升降、头部等可读关节的名称"],
  "verified_by": "04 的方向检查日期与结论"
}
```

规则：URDF 关节值 = `sign × 电机读数 + offset_rad`。这里的 `offset_rad` 只用于厂家或驱动层已知的固定换算（如单位或半圈偏移），默认 0。标定得到的零位偏差不写在这里，而是写进 URDF。每个关节的正方向必须用 `04` §3 的方向检查确认。

## 4. 抽象接口与采集伪代码

```python
poses = load_json('poses_left.json')
setup = poses['setups']['B_wrist_table_board']          # 或 A_head_board_on_gripper
cams = [v['camera'] for v in setup['views']]
S = poses['settle']        # min_wait_s, velocity_threshold_rad_s, window_s, frames_per_pose, timeout_s

assert robot_ok()
q0_all = get_joint_state()                               # 记录全部关节（含躯干/腰/升降/头/另一臂）
check_hold_fixed(q0_all, poses['hold_fixed'])            # 另一臂在 hold_fixed.other_arm 附近，否则先慢速移过去
move_safely(poses['home'], v_max=poses['motion']['v_max_rad_s'])

for p in setup['poses']:
    if p['transition_before'] == 'via_home':
        move_safely(poses['home'])
    elif p['transition_before'] == 'unverified':
        if not operator_confirms(p['id']): log_skip(p); continue    # 或以 1/3 速度点动
    target = p['joints']
    duration = max(p['move_duration_s'], max_abs_delta(current(), target) / V_MAX_REAL)
    send_joint_targets(target, duration)
    wait(duration)
    settled = wait_settle(S)                              # 见下
    if not settled: log_abort(p, 'not settled'); continue
    js_before = get_joint_state()
    frames = {c: [get_camera_frame(c) for _ in range(S['frames_per_pose'])] for c in cams}
    js_after = get_joint_state()
    drift = max_abs(js_after.q - js_before.q)
    if drift > 0.002: log_reject(p, 'moved during capture'); continue
    save_sample(p, js_before, js_after, frames, target)
    abort_checks()                                        # 见 §6

move_safely(poses['home'])

def wait_settle(S):
    sleep(S['min_wait_s'])
    t_end = now() + S['timeout_s']
    while now() < t_end:
        window = sample_joint_states(S['window_s'])     # ≥100 Hz
        if max_abs(window.dq) < S['velocity_threshold_rad_s'] and range(window.q) < 0.0005:
            return True
    return False
```

要点
- 测量值始终是读回的编码器值，不是指令值。指令与读数之差另行记录（用于 `05` 的重力下垂分析）。
- 编码器在取帧前后各读一次，取平均作为样本值；两次差值超过 0.002 rad 的样本作废。
- 稳定阈值（1.5 s、0.005 rad/s）是起始值，待实测：在 5 个位姿上连续录 5 s 关节和图像，看板角点抖动 <0.1 px 需要多长时间。
- 速度上限 `V_MAX_REAL` 由安全评估确定（位姿表默认 0.35 rad/s）。

## 5. 输出：会话目录

```text
calib_<YYYYMMDD_HHMM>_<setup>_<side>/
  session.json
  samples.jsonl
  images/<pose_id>/<camera>_<k>.png
```

`session.json`
```json
{
  "format": "g1d_calib_session_v1",
  "setup": "B_wrist_table_board", "side": "left",
  "pose_list": {"file": "poses_left.json", "sha256": "..."},
  "joint_mapping": {"file": "joint_mapping.json", "sha256": "..."},
  "intrinsics_files": {"left_wrist": "camera_intrinsics_left_wrist.json"},
  "boards": {"table": {"type": "charuco", "dictionary": "...", "squares_x": 0, "squares_y": 0,
                       "square_length_m": 0.0, "marker_length_m": 0.0, "measured_by": "卡尺",
                       "parent": "torso_link", "T_parent_board_nominal": [[...]], "mount_note": "..."}},
  "clock": "真机 PC 单调时钟，秒", "camera_timestamp_meaning": "待实测",
  "joint_state_start": {"t": 0.0, "joints": {"<所有可读关节>": 0.0}},
  "joint_state_end": {"t": 0.0, "joints": {}},
  "operator": "...", "software": {"collector": "git hash"}, "notes": "..."
}
```

`samples.jsonl`（每个成功位姿一行）
```json
{"id": "B_left_007", "pose_id": "B_left_007",
 "t_command": 1234.50, "t_settled": 1239.12,
 "q_target": {"left_shoulder_pitch_joint": 0.1, "...": 0.0},
 "joints_before": {"t": 1239.13, "q": {"<所有可读关节>": 0.0}, "dq": {}, "tau": {}},
 "joints_after":  {"t": 1239.61, "q": {}, "dq": {}, "tau": {}},
 "frames": {"left_wrist": [{"file": "images/B_left_007/left_wrist_0.png", "t": 1239.20}, "..."]},
 "settle": {"waited_s": 2.1, "max_dq": 0.002},
 "flags": []}
```

`joints_*` 必须包含全部可读关节（双臂 14 个、腰/升降/头部等），名称使用 URDF 关节名（经 `joint_mapping.json` 转换）。

## 6. 中止条件

立即 `stop()` 并结束会话：
- `robot_ok()` 为假（故障、过温、模式切换）；
- 任一关节跟踪误差 >0.1 rad（阈值待实测）或力矩超过阈值（待实测）；
- 腰/升降/头部或另一臂相对会话开始的值漂移 >0.005 rad（B 设置中桌面板相对躯干必须固定）；
- 相机断流或帧时间戳停滞 >0.5 s；
- 操作员按下停止或发现接触/碰撞；
- 连续 3 个位姿未稳定或角点检测失败（可能是板松动）。

只跳过当前位姿：`unverified` 过渡未获确认；稳定超时；取帧时漂移超限。

## 7. 检查清单

- [ ] `joint_mapping.json` 已确认（`04` 方向检查通过）
- [ ] 内参文件就绪，相机流设置与内参标定一致
- [ ] 板格长已实测；夹具已拧紧，`T_parent_board_nominal` 已填写
- [ ] 位姿表与实际板/桌面布局一致（否则用 `pose_design.py --scene` 重新生成）
- [ ] 首次运行用 25% 速度，人工看完整个位姿序列
- [ ] 急停可用，工作空间内无人
- [ ] 会话开始和结束的全关节快照都已记录
- [ ] 会话目录已拷到服务器 `real2sim_calib_20261015/real_data/<日期>/`
