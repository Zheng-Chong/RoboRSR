"""Board-based calibration setups on the robot's own cameras: nominal scene, feasible-pose sampling, synthetic data.

  A  board rigidly mounted on the Dex1 base, observed by the head camera(s)
  B  board fixed on the table (torso frame), observed by the wrist camera of the moving arm
Joint limits (with margin), self-collision (convex hulls, coal), table clearance, board visibility, facing angle and
occlusion by robot links are checked with the nominal model.
"""
import json
import xml.etree.ElementTree as ET
import numpy as np
import coal
import trimesh
from scipy.spatial.transform import Rotation
from calib_model import (NOMINAL, OPTICAL_FROM_CAMERA, Robot, arm_joints, board_points, expm, inv, intrinsics_dict,
                         load_camera_contract, project, rodrigues, se3, se3_of, transform)

RESOLUTION = (640, 480)
CAMERA_SPECS = {'head': dict(model='opencv', fx=245.0, dist=[-0.28, 0.07, 0.0, 0.0, -0.008]),
                'wrist': dict(model='opencv', fx=222.6, dist=[-0.30, 0.08, 0.0, 0.0, -0.009])}
INTRINSICS_SIGMA = dict(fx=0.5, fy=0.5, cx=0.5, cy=0.5, k1=0.003, k2=0.002, p1=2e-4, p2=2e-4, k3=5e-4)
GRIPPER_BOARD = dict(type='charuco', squares_x=5, squares_y=4, square_length_m=0.028, marker_length_m=0.021, dictionary='DICT_4X4_50')
TABLE_BOARD = dict(type='charuco', squares_x=9, squares_y=7, square_length_m=0.035, marker_length_m=0.026, dictionary='DICT_5X5_100')
GRIPPER_BOARD_CENTER = (0.02, 0.0, 0.095)
TABLE_Z = -0.09
TABLE_BOARD_CENTER = (0.40, 0.0, TABLE_Z + 0.002)
TORSO_GROUP = ['torso_link', 'head_link', 'logo_link']
TABLE_EDGE_X = 0.22
IDLE_Q = {'shoulder_pitch': 0.1, 'shoulder_roll': 0.25, 'elbow': 1.2}


def board_size(spec):
    return spec['squares_x'] * spec['square_length_m'], spec['squares_y'] * spec['square_length_m']


def face_up_board(spec, center):
    """Board pose whose printed face points up (+Z of the parent); OpenCV board z points into the board."""
    R = np.diag([1., -1, -1])
    w, h = board_size(spec)
    return transform(R, np.array(center) - R @ np.array([w / 2, h / 2, 0]))


def idle_arm(side):
    q = {n: 0. for n in arm_joints(side)}
    for k, v in IDLE_Q.items():
        q[f'{side}_{k}_joint'] = v if k != 'shoulder_roll' or side == 'left' else -v
    return q


def nominal_scene(sides=('left', 'right')):
    contract = load_camera_contract(NOMINAL / 'camera_contract_v5.json')
    cams = {}
    for name in ['head_left', 'head_right'] + [f'{s}_wrist' for s in sides]:
        kind = 'head' if name.startswith('head') else 'wrist'
        c = CAMERA_SPECS[kind]
        cams[name] = dict(parent=contract[name]['parent'], T_parent_camera=contract[name]['T_parent_camera_world_convention'],
                          model=c['model'], K=[[c['fx'], 0, RESOLUTION[0] / 2], [0, c['fx'], RESOLUTION[1] / 2], [0, 0, 1]],
                          dist=list(c['dist']), resolution=list(RESOLUTION), intrinsics_sigma=dict(INTRINSICS_SIGMA))
    boards = {f'gripper_{s}': dict(GRIPPER_BOARD, parent=f'{s}_dex1_base_link',
                                   T_parent_board=face_up_board(GRIPPER_BOARD, GRIPPER_BOARD_CENTER).tolist()) for s in sides}
    boards['table'] = dict(TABLE_BOARD, parent='torso_link', T_parent_board=face_up_board(TABLE_BOARD, TABLE_BOARD_CENTER).tolist())
    for b in boards.values():
        b['points_m'] = [[i, *xyz] for i, xyz in sorted((k, v.tolist()) for k, v in board_points(b).items())]
    return dict(format='g1d_calib_measurements_v1', root_link='torso_link', cameras=cams, boards=boards, samples=[])


def setup_views(setup, side):
    if setup == 'A_mono':
        return [('head_left', f'gripper_{side}')]
    if setup == 'A_stereo':
        return [('head_left', f'gripper_{side}'), ('head_right', f'gripper_{side}')]
    if setup == 'B_wrist':
        return [(f'{side}_wrist', 'table')]
    raise KeyError(setup)


class Geometry:
    """Convex-hull collision model of the nominal assembly plus board plates and table."""

    def __init__(self, scene, urdf=NOMINAL / 'g1_d_upper_dex1_v4.urdf'):
        self.robot = Robot(urdf)
        xml = ET.parse(urdf).getroot()
        self.hulls = {}
        for link in xml.findall('link'):
            pts = []
            for c in link.findall('collision'):
                m = c.find('geometry/mesh')
                if m is None:
                    continue
                o = c.find('origin')
                vec = lambda k: [float(v) for v in (o.get(k, '0 0 0') if o is not None else '0 0 0').split()]
                T = transform(Rotation.from_euler('xyz', vec('rpy')).as_matrix(), vec('xyz'))
                mesh = trimesh.load(urdf.parent / m.get('filename'), force='mesh')
                pts.append(mesh.vertices @ T[:3, :3].T + T[:3, 3])
            if pts:
                vec3 = coal.StdVec_Vec3s()
                for v in trimesh.convex.convex_hull(np.vstack(pts)).vertices:
                    vec3.append(np.asarray(v, float))
                self.hulls[link.get('name')] = coal.Convex.convexHull(vec3, False, '')
        contract = json.loads((NOMINAL / 'physics_contract.json').read_text())
        self.filtered = {k: set(v) for k, v in contract['filtered_pairs'].items()}
        self.boards = {}
        for name, b in scene['boards'].items():
            w, h = board_size(b)
            T = np.array(b['T_parent_board']) @ transform(t=[w / 2, h / 2, 0.003])
            self.boards[name] = (b['parent'], coal.Box(w, h, 0.006), T)
        self.table = coal.Box(1.6, 1.6, 0.04)
        self.table_T = transform(t=[TABLE_EDGE_X + 0.8, 0, TABLE_Z - 0.02])
        self.scene = scene

    @staticmethod
    def tf(T):
        return coal.Transform3s(T[:3, :3].copy(), T[:3, 3].copy())

    def arm_links(self, side):
        return [l for l in self.hulls if l.startswith(f'{side}_') and l != f'{side}_shoulder_pitch_link']

    def collision_free(self, frames, side, board=None, table=True, clearance=0.005):
        req, res = coal.DistanceRequest(), coal.DistanceResult()
        moving = [(l, self.hulls[l], frames[l]) for l in self.arm_links(side)]
        skip = {}
        if board:
            parent, box, T = self.boards[board]
            moving.append((board, box, frames[parent] @ T))
            skip[board] = {parent, f'{side}_dex1_model_base_link'}
        other = 'right' if side == 'left' else 'left'
        static = [(l, self.hulls[l], frames[l]) for l in TORSO_GROUP + [f'{side}_shoulder_pitch_link'] +
                  [l for l in self.hulls if l.startswith(f'{other}_')] if l in self.hulls]
        if table:
            static.append(('table', self.table, self.table_T))
        for i, (a, ga, Ta) in enumerate(moving):
            for b, gb, Tb in static + moving[i + 1:]:
                if b in self.filtered.get(a, ()) or b in skip.get(a, ()) or a in skip.get(b, ()):
                    continue
                res.clear()
                if coal.distance(ga, self.tf(Ta), gb, self.tf(Tb), req, res) < clearance:
                    return False
        return True

    def occluded(self, frames, cam_T, points, ignore):
        req, res = coal.CollisionRequest(), coal.CollisionResult()
        c = cam_T[:3, 3]
        hidden = np.zeros(len(points), bool)
        links = [(l, g, frames[l]) for l, g in self.hulls.items() if l not in ignore and l in frames]
        for i, p in enumerate(points):
            d = p - c
            L = np.linalg.norm(d)
            a, b = 0.03, L - 0.02
            if b <= a:
                continue
            z = d / L
            x = np.cross(z, [0, 0, 1.]) if abs(z[2]) < 0.9 else np.cross(z, [1., 0, 0])
            x /= np.linalg.norm(x)
            R = np.stack([x, np.cross(z, x), z], 1)
            T = transform(R, c + z * (a + b) / 2)
            cap = coal.Capsule(0.002, b - a)
            for _, g, Tl in links:
                res.clear()
                if coal.collide(cap, self.tf(T), g, self.tf(Tl), req, res):
                    hidden[i] = True
                    break
        return hidden


def camera_frames(robot, scene, q, links, n):
    return {l: robot.fk(l, q, {}, scene['root_link'], n) for l in links}


def all_frames(robot, q, p=None):
    """Single-configuration FK of every link (q: name -> float)."""
    p = p or {}
    out, pending = {robot.root: np.eye(4)}, list(robot.joints.values())
    while pending:
        rest = []
        for j in pending:
            if j['parent'] not in out:
                rest.append(j)
                continue
            M = np.eye(4)
            if j['type'] in ('revolute', 'continuous'):
                M[:3, :3] = expm(j['axis'] * q.get(j['name'], 0.))
            elif j['type'] == 'prismatic':
                M[:3, 3] = j['axis'] * q.get(j['name'], 0.)
            out[j['child']] = out[j['parent']] @ robot.origin(j['name'], p) @ M
        pending = rest
    return out


def visible_corners(scene, frames, camera, board, p=None, min_depth=0.12, max_angle_deg=65, border=8):
    """Per-sample projected pixels, in-image mask and facing mask (nominal or given parameters)."""
    p = p or {}
    cs, bs = scene['cameras'][camera], scene['boards'][board]
    Tc = frames[cs['parent']] @ np.array(cs['T_parent_camera']) @ se3(se3_of(p, f'camera:{camera}'))
    Tb = frames[bs['parent']] @ np.array(bs['T_parent_board']) @ se3(se3_of(p, f'board:{board}'))
    pts = np.array([x[1:] for x in bs['points_m']])
    T = inv(Tc) @ Tb
    P = np.einsum('nij,mj->nmi', T[:, :3, :3], pts) + T[:, None, :3, 3]
    P = P @ OPTICAL_FROM_CAMERA.T
    intr = intrinsics_dict(cs)
    for k in intr:
        intr[k] += p.get(f'intrinsics:{camera}/{k}', 0.)
    uv = project(cs['model'], intr, np.where(P[..., 2:3] > 1e-3, P, 1e-3))
    w, h = cs['resolution']
    inside = (P[..., 2] > min_depth) & (uv[..., 0] > border) & (uv[..., 0] < w - border) & (uv[..., 1] > border) & (uv[..., 1] < h - border)
    r = np.sqrt((P[..., 0] / np.maximum(P[..., 2], 1e-3)) ** 2 + (P[..., 1] / np.maximum(P[..., 2], 1e-3)) ** 2)
    inside &= r < 1.25
    centre = Tb[:, :3, :3] @ pts.mean(0) + Tb[:, :3, 3]
    view = centre - Tc[:, :3, 3]
    view /= np.linalg.norm(view, axis=1, keepdims=True)
    facing = np.einsum('ni,ni->n', Tb[:, :3, 2], view) > np.cos(np.radians(max_angle_deg))
    return uv, inside & facing[:, None], Tc, Tb, pts


def synthesize(scene, robot, batches, p_true, sigma_px, joint_sigma, rng, min_corners=4):
    """Measurement document from (setup, side, [arm q dicts]) batches simulated with the true parameters p_true."""
    meas = json.loads(json.dumps(scene))
    for setup, side, poses in batches:
        other = 'right' if side == 'left' else 'left'
        views = setup_views(setup, side)
        for i, q in enumerate(poses):
            q_true = dict(idle_arm(other), **q)
            qa = {k: np.array([v]) for k, v in q_true.items()}
            links = {scene['cameras'][c]['parent'] for c, _ in views} | {scene['boards'][b]['parent'] for _, b in views}
            frames = {l: robot.fk(l, qa, p_true, scene['root_link'], 1) for l in links}
            obs = []
            for c, b in views:
                uv, mask, _, _, _ = visible_corners(scene, frames, c, b, p_true)
                ids = np.flatnonzero(mask[0])
                if len(ids) < min_corners:
                    continue
                pix = uv[0, ids] + rng.normal(0, sigma_px, (len(ids), 2))
                obs.append(dict(type='board_pixels', camera=c, board=b, corner_ids=[int(scene['boards'][b]['points_m'][k][0]) for k in ids],
                                pixels=pix.tolist(), sigma_px=max(sigma_px, 0.1)))
            if obs:
                rec = {k: v + rng.normal(0, joint_sigma) for k, v in q_true.items()}
                meas['samples'].append(dict(id=f'{setup}_{side}_{i:03d}', joints=rec, observations=obs))
    return meas


def sample_feasible(geo, scene, setup, side, n_target, rng, margin=0.15, draws=200000, min_corners=None, max_checks=6000,
                    candidates=None):
    """Random (or given candidate) joint vectors within limits passing visibility, collision and occlusion checks."""
    robot = geo.robot
    names = arm_joints(side)
    lo = np.array([robot.joints[n]['lower'] for n in names]) + margin
    hi = np.array([robot.joints[n]['upper'] for n in names]) - margin
    Q = rng.uniform(lo, hi, size=(draws, 7)) if candidates is None else np.clip(candidates, lo, hi)
    draws = len(Q)
    other = 'right' if side == 'left' else 'left'
    q = {n: Q[:, i] for i, n in enumerate(names)}
    q.update({k: np.full(draws, v) for k, v in idle_arm(other).items()})
    views = setup_views(setup, side)
    links = {scene['cameras'][c]['parent'] for c, _ in views} | {scene['boards'][b]['parent'] for _, b in views}
    frames = camera_frames(robot, scene, q, links, draws)
    ok = np.ones(draws, bool)
    min_corners = min_corners or (6 if setup.startswith('A') else 12)
    masks = {}
    for c, b in views:
        _, m, _, _, _ = visible_corners(scene, frames, c, b)
        masks[(c, b)] = m
        ok &= m.sum(1) >= min_corners
    out = []
    for i in np.flatnonzero(ok)[:max_checks]:
        fr = all_frames(robot, {k: float(v[i]) for k, v in q.items()})
        board = views[0][1]
        if not geo.collision_free(fr, side, board if board != 'table' else None):
            continue
        good = True
        for c, b in views:
            cs = scene['cameras'][c]
            Tc = fr[cs['parent']] @ np.array(cs['T_parent_camera'])
            Tb = fr[scene['boards'][b]['parent']] if b != 'table' else np.eye(4)
            pts = np.array([x[1:] for x in scene['boards'][b]['points_m']])
            Tb = Tb @ np.array(scene['boards'][b]['T_parent_board'])
            world = pts @ Tb[:3, :3].T + Tb[:3, 3]
            vis = masks[(c, b)][i]
            ignore = set(TORSO_GROUP) if c.startswith('head') else {cs['parent'], f'{side}_dex1_model_base_link'}
            hidden = geo.occluded(fr, Tc, world[vis], ignore)
            if vis.sum() - hidden.sum() < min_corners:
                good = False
                break
        if good:
            out.append({n: float(Q[i, k]) for k, n in enumerate(names)})
            if len(out) >= n_target:
                break
    return out, dict(draws=draws, visible=int(ok.sum()), checked=int(min(ok.sum(), max_checks)), feasible=len(out))
