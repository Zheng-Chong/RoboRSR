"""Sim-vs-real check: board corners detected on the real robot vs corners predicted by a model for the same joint vector.

usage examples
  compare_sim_real.py meas.json --out check.json
  compare_sim_real.py meas.json --params params.json --out check.json --overlay-dir overlays --images-root session_dir
  compare_sim_real.py meas.json --fit 'left_shoulder_roll_joint/zero' --out quick_estimate.json
Camera and board mounts are always re-estimated (6D each, intrinsics as given), so only the joint model is compared.
--fit adds the listed parameters for a quick partial estimate (biased if other joint errors exist; use for sign checks).
"""
import argparse
import json
from pathlib import Path
import numpy as np
from calib_model import NOMINAL, SE3_KEYS, Problem, Robot, expand, load_params
from identify import analyze, fit, load_measurements, observed


def nuisance(meas):
    cams, boards = observed(meas)
    return [f'camera:{c}/{k}' for c in sorted(cams) for k in SE3_KEYS] + [f'board:{b}/{k}' for b in sorted(boards) for k in SE3_KEYS]


def per_sample(problem, x):
    p = problem.params(x)
    frames = problem.link_poses(p, problem.needed_links())
    out, pred = {}, {}
    for (c, b), g in problem.groups.items():
        uv, _ = problem.predict_pixels(p, c, b, frames, g['k'], g['pts'])
        d = uv - g['uv']
        for k in np.unique(g['k']):
            m = g['k'] == k
            sid = problem.meas['samples'][k]['id']
            out.setdefault(sid, {})[c] = {'board': b, 'n': int(m.sum()), 'rms_px': float(np.sqrt(np.mean(np.sum(d[m] ** 2, 1)))),
                                         'mean_residual_px': d[m].mean(0).round(3).tolist()}
            pred.setdefault(sid, {})[c] = (g['uv'][m], uv[m])
    return out, pred


def overlay(meas, preds, images_root, out_dir):
    import cv2
    out_dir.mkdir(parents=True, exist_ok=True)
    for s in meas['samples']:
        for c, rel in s.get('image_files', {}).items():
            if c not in preds.get(s['id'], {}):
                continue
            img = cv2.imread(str(Path(images_root) / rel))
            for name, color in [('nominal', (0, 0, 255)), ('calibrated', (255, 0, 0))]:
                if name not in preds[s['id']][c]:
                    continue
                det, uv = preds[s['id']][c][name]
                for a, b in zip(det, uv):
                    cv2.line(img, tuple(np.round(a).astype(int)), tuple(np.round(b).astype(int)), color, 1)
                    cv2.circle(img, tuple(np.round(b).astype(int)), 3, color, 1)
            for a in det:
                cv2.circle(img, tuple(np.round(a).astype(int)), 2, (0, 255, 0), -1)
            cv2.imwrite(str(out_dir / f"{s['id']}_{c}.png"), img)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('measurements', nargs='+')
    ap.add_argument('--urdf', default=str(NOMINAL / 'g1_d_upper_dex1_v4.urdf'))
    ap.add_argument('--params', help='g1d_calib_params_v1 file; its joint parameters are compared against the nominal model')
    ap.add_argument('--fit', nargs='*', default=[])
    ap.add_argument('--out', required=True)
    ap.add_argument('--overlay-dir')
    ap.add_argument('--images-root', default='.')
    a = ap.parse_args()
    meas = load_measurements(a.measurements)
    robot = Robot(a.urdf)
    names = nuisance(meas)
    models = {'nominal': {}}
    if a.params:
        models['calibrated'] = {k: v for k, v in load_params(a.params)['values'].items() if ':' not in k.split('/')[0]}
    report, preds = {'measurements': a.measurements, 'estimated_nuisance': names, 'models': {}}, {}
    for label, fixed in models.items():
        problem = Problem(robot, meas, names, fixed)
        r = fit(problem)
        samples, pred = per_sample(problem, r.x)
        for sid, cams in pred.items():
            for c, v in cams.items():
                preds.setdefault(sid, {}).setdefault(c, {})[label] = v
        rms = [v['rms_px'] for cams in samples.values() for v in cams.values()]
        report['models'][label] = {'rms_px_mean_over_views': float(np.mean(rms)), 'rms_px_max_view': float(np.max(rms)),
                                   'per_sample': samples, 'nuisance': dict(zip(names, r.x.tolist()))}
    if a.fit:
        problem = Problem(robot, meas, [], {})
        extra = expand(a.fit, problem.universe())
        problem = Problem(robot, meas, extra + names, models.get('calibrated', {}))
        r = fit(problem)
        ident = analyze(problem, r.x)
        deg = lambda n, v: float(np.degrees(v)) if n.split('/')[-1] in ('zero', 'rot_u', 'rot_v', 'rx', 'ry', 'rz') else float(v)
        report['quick_fit'] = {'parameters': {n: {'value_deg_or_m': deg(n, v), 'std_deg_or_m': deg(n, ident['std'][n])} for n, v in zip(extra, r.x)},
                               'rms_px_mean_over_views': float(np.mean([v['rms_px'] for cams in per_sample(problem, r.x)[0].values() for v in cams.values()])),
                               'condition_number': ident['condition_number'], 'flags': ident['flags']}
    Path(a.out).write_text(json.dumps(report, indent=1))
    if a.overlay_dir:
        overlay(meas, preds, a.images_root, Path(a.overlay_dir))
    print(json.dumps({k: {kk: v[kk] for kk in ['rms_px_mean_over_views', 'rms_px_max_view']} for k, v in report['models'].items()}, indent=1))
    if a.fit:
        print(json.dumps(report['quick_fit']['parameters'], indent=1))


if __name__ == '__main__':
    main()
