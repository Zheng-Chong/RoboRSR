# G1-D 真机-仿真运动学标定包（2026-10-15）

从 GPU 服务器 `<GPU_SERVER>:/root/unitree_sim_isaaclab/real2sim_calib_20261015/` 打包，用于在真机电脑上完成标定实验。

- 先读 `docs/00_overview_zh.md`：总流程、真机端待实现工具清单和文件格式；所有未确认的信息都标为"待实测"。
- `nominal/` 是名义机器人模型（G1-D 上身/全身 + Dex1-1 URDF、相机外参合同）。**本工具包未附带 `nominal/meshes/`（约 17 MB STL）**：位姿设计（`board_setups.py`/`pose_design.py` 的碰撞模型）和 `build_assembly.py` 需要网格，请在 GPU 服务器上使用名义资产 `/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled/`（含 meshes），或把那里的 `meshes/` 拷到本目录 `nominal/meshes/`。在真机电脑上运行本包脚本前设置：
  `export G1D_CALIB_NOMINAL=<本包路径>/nominal`（Windows: `set G1D_CALIB_NOMINAL=...`）。
- 依赖：Python 3.10+、numpy、scipy；`board_setups.py`/`pose_design.py` 另需 trimesh、coal；标定板检测需 opencv-contrib-python。
- `poses_left.json`/`poses_right.json` 基于占位的标定板尺寸、夹具位置、桌面高度和相机内参生成，实测后用 `pose_design.py --scene` 重新生成。
- `params_test_left_shoulder_roll_2p6.json` 只是流程测试用的占位参数，数值和符号待实测。
- `examples/replay_r2s_E009_right_a1.json`、`replay_r2s_E036_left_a1.json` 是仿真已验证的倒水轨迹，用于 `docs/06_replay_validation_zh.md` 的真机回放验收。
- 辨识、写回 URDF、重建仿真资产（`identify.py`、`apply_calibration.py`、`build_assembly.py`、`tools/`）在服务器上运行，见 `docs/07_apply_parameters_zh.md`；`build_assembly.py` 和 `tools/` 依赖服务器上的 Isaac 环境和项目目录。
- `MANIFEST_sha256.txt` 记录了包内所有文件的哈希。
