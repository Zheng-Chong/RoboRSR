"""Structural comparison against cached official sources, not filename claims."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import sys
import sys
sys.path.insert(0, '/root/unitree_sim_isaaclab/codex_pour/g1d_probe')
import assemble_g1d_dex1 as source
from pathlib import Path as _P
source.G1D_URDF = _P('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/source/g1_d/g1_d.urdf')

out=Path(sys.argv[1])
actual=ET.parse(out/'g1_d_upper_dex1_v4.urdf').getroot()
body=ET.parse(source.G1D_URDF).getroot()
hand=ET.parse(source.DEX1_URDF).getroot()

def canonical(e):
    attrs=dict(e.attrib)
    if e.tag=='mesh': attrs['filename']=Path(attrs['filename']).name
    return e.tag,attrs,[canonical(c) for c in e]

checks={}
for original in body:
    name=original.get('name')
    if original.tag not in ['link','joint'] or not name: continue
    item=actual.find(f"{original.tag}[@name='{name}']")
    if item is not None:
        checks['body/'+name]=canonical(original)==canonical(item)
for side in ['left','right']:
    link_map,joint_map=source.dex1_name_maps(side)
    for original in hand.findall('link'):
        item=actual.find(f"link[@name='{link_map[original.get('name')]}']")
        expected=ET.fromstring(ET.tostring(original))
        expected.set('name',item.get('name'))
        checks[side+'/'+original.get('name')]=canonical(item)==canonical(expected)
    for original in hand.findall('joint'):
        item=actual.find(f"joint[@name='{joint_map[original.get('name')]}']")
        expected=ET.fromstring(ET.tostring(original))
        expected.set('name',item.get('name'))
        for tag in ['parent','child']:
            expected.find(tag).set('link',link_map[expected.find(tag).get('link')])
        copied=ET.fromstring(ET.tostring(item))
        mimic=copied.find('mimic')
        if mimic is not None:
            checks[side+'/mimic']=mimic.attrib=={'joint':f'{side}_dex1_finger_joint_1','multiplier':'1','offset':'0'}
            copied.remove(mimic)
        checks[side+'/'+original.get('name')]=canonical(copied)==canonical(expected)
manifest=json.loads((out/'assemble.json').read_text())
for name,digest in manifest['meshes_sha256'].items():
    checks['mesh/'+name]=hashlib.sha256((out/name).read_bytes()).hexdigest()==digest
checks['native_gripper_base_known_hash']=hashlib.sha256((out/'meshes/dex1_1/base_link.STL').read_bytes()).hexdigest()=='0469151d67b4e8230337d649e783d756582545d27944dc49c945fb6fe397cc54'
report={'passed':all(checks.values()),'checks':checks,
        'mount_registration':'Project-inferred flange alignment; no claim of official G1-D Dex1-1 complete assembly',
        'official_hand_mass_kg':sum(float(e.find('inertial/mass').get('value')) for e in hand.findall('link'))}
(out/'source_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'checks':len(checks),'failed':[k for k,v in checks.items() if not v], 'hand_mass_kg':report['official_hand_mass_kg']},indent=2))
assert {k for k, v in checks.items() if not v} <= {'body/' + j for j in json.loads((out/'calibration_provenance.json').read_text())['joints']}
