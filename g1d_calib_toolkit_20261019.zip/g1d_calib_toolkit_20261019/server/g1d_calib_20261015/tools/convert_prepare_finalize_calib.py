"""URDF->USD with the converter settings recorded in assembled_v4_coupled/config.yaml, then the shared
prepare_dex1_v4_asset.prepare() and the finalize_dex1_v4_asset.py validation, all into the new directory."""
import argparse, hashlib, json, os, sys
from pathlib import Path
from isaaclab.app import AppLauncher
parser = argparse.ArgumentParser()
AppLauncher.add_app_launcher_args(parser)
parser.set_defaults(headless=True, device='cpu')
parser.add_argument('--asset-dir', required=True)
args = parser.parse_args()
app = AppLauncher(args).app
try:
    sys.path.insert(0, '/root/unitree_sim_isaaclab/codex_pour/g1d_probe')
    from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg
    from pxr import Usd, UsdUtils, UsdPhysics, PhysxSchema
    from prepare_dex1_v4_asset import prepare
    directory = Path(args.asset_dir)
    urdf = directory / 'g1_d_upper_dex1_v4.urdf'
    assert not (directory / 'g1_d_upper_dex1_v4.usd').exists()
    UrdfConverter(UrdfConverterCfg(asset_path=str(urdf), usd_dir=str(directory),
        usd_file_name='g1_d_upper_dex1_v4.usd', fix_base=True, merge_fixed_joints=False,
        self_collision=True, collider_type='convex_decomposition',
        force_usd_conversion=True, make_instanceable=False,
        joint_drive=UrdfConverterCfg.JointDriveCfg(gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
    print('CONVERTED', flush=True)
    prepare(directory)
    print('PREPARED', flush=True)
    usd = directory / 'g1_d_upper_dex1_v4.usd'
    layers, assets, unresolved = UsdUtils.ComputeAllDependencies(str(usd))
    stage = Usd.Stage.Open(str(usd))
    flat = directory / 'g1_d_upper_dex1_v4_flat.usdc'
    stage.Flatten().Export(str(flat))
    _, _, flat_unresolved = UsdUtils.ComputeAllDependencies(str(flat))
    joints = [p for p in stage.Traverse() if p.IsA(UsdPhysics.PrismaticJoint)]
    report = {'unresolved': list(unresolved), 'flattened_unresolved': list(flat_unresolved),
              'layers': [l.realPath for l in layers], 'external_assets': [str(a) for a in assets],
              'flattened_asset': str(flat), 'prismatic_joints': len(joints),
              'drives': {p.GetName(): {'max_force': UsdPhysics.DriveAPI.Get(p, 'linear').GetMaxForceAttr().Get(),
                                       'stiffness': UsdPhysics.DriveAPI.Get(p, 'linear').GetStiffnessAttr().Get(),
                                       'mimic': p.HasAPI(PhysxSchema.PhysxMimicJointAPI)} for p in joints}}
    report['passed'] = not unresolved and not flat_unresolved and len(joints) == 4
    report['passed_ignoring_builtin_OmniPBR_mdl'] = (set(unresolved) <= {'OmniPBR.mdl'} and set(flat_unresolved) <= {'OmniPBR.mdl'} and len(joints) == 4)
    (directory / 'usd_validation.json').write_text(json.dumps(report, indent=2))
    (directory / 'sha256.json').write_text(json.dumps({str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(directory.rglob('*')) if p.is_file() and p.name != 'sha256.json'}, indent=2))
    print(json.dumps(report, indent=2), flush=True)
except BaseException:
    import traceback; traceback.print_exc(); sys.stdout.flush(); sys.stderr.flush(); os._exit(1)
sys.stdout.flush(); sys.stderr.flush(); os._exit(0)
