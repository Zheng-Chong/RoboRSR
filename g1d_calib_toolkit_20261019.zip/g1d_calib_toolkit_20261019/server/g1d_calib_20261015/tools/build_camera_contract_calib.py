"""Reference-based approximation, not real-camera calibration."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
ROOT=Path('/root/unitree_sim_isaaclab')
sys.path.insert(0,str(ROOT/'scene3_pour_pack/motion'))
from kinematics import G1Kinematics,transform
folder=Path(sys.argv[1])
urdf=folder/'g1_d_full_dex1_v4.urdf'
kin=G1Kinematics('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled/g1_d_full_dex1_v4.urdf'); frames=kin.fk({})
views=[]
for name,parent,xyz,pitch,hfov,vfov in [
 ('head_left','head_link',[101.5,29.8,1169.5],47.6,115,80),
 ('head_right','head_link',[101.5,-29.8,1169.5],47.6,115,80),
 ('left_wrist','left_dex1_base_link',[361.3,148.2,840.2],30,118,87),
 ('right_wrist','right_dex1_base_link',[361.3,-148.2,840.2],30,118,87)]:
 ref=transform(np.array(xyz)/1000,[0,np.deg2rad(pitch),0])
 local=np.linalg.inv(frames[parent])@ref
 views.append(dict(name=name,parent=parent,T_parent_camera_world_convention=local.tolist(),
   reference_position_mm=xyz,reference_pitch_down_deg=pitch,hfov_deg=hfov,vfov_deg=vfov,
   fx=480/np.tan(np.deg2rad(hfov/2)),fy=360/np.tan(np.deg2rad(vfov/2))))
doc=dict(version=5,source='https://serviceconsole.unitree.com/#/help/031354',
  assumptions=['Official dimensions interpreted as mm; diagram does not explicitly label units.',
   'Reference posture treated as G1-D full URDF zero pose based on matching bent-arm geometry, not manufacturer-certified joint values.',
   'Official base frame treated as AGV_link; final hardware calibration remains outstanding.',
   'Requested fx/fy are derived from published FOV; installed Isaac Lab renders their average as square-pixel pinhole. Actual K is recorded per frame and actual FOV in fourview_audit.json. No calibrated distortion.',
   'Reference camera pose uses +X forward,+Y left,+Z up; wrist local transforms follow the project assembly.'],
  resolution=[960,720],fps=30,urdf_sha256=hashlib.sha256(urdf.read_bytes()).hexdigest(),views=views)
(folder/'camera_contract_v5.json').write_text(json.dumps(doc,indent=2))
print(json.dumps(doc,indent=2))
