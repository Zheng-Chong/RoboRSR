"""TCP and wrist-camera displacement caused by a parameter set: nominal vs calibrated FK at zero joints, at the E036
grasp configuration and over the whole E036 trajectory.

usage: tcp_effect.py PARAMS.json OUT.json [--calibrated-urdf URDF]
"""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from calib_model import NOMINAL, Robot, arm_joints, inv, load_camera_contract, load_params, logm, pose_error, transform

RUN = Path('/mnt/data/unitree_sim_isaaclab_runs/real2sim_g1d_20261015/runs/r2s_E036_left_a1')


def read_trace(path=RUN / 'trace.jsonl'):
    return [json.loads(line) for line in open(path)]


def grasp_row(rows, phase='close'):
    return [r for r in rows if r['phase'] == phase][-1]


def displacement(Tn, Tc):
    d, a = pose_error(Tn, Tc)
    out = {'translation_mm': (1000 * d).tolist(), 'rotation_deg': np.degrees(a).tolist()}
    out['delta_xyz_mm_torso_frame'] = (1000 * (Tc[..., :3, 3] - Tn[..., :3, 3])).tolist()
    return out


def evaluate(params, calibrated_urdf=None, side='left'):
    robot = Robot(NOMINAL / 'g1_d_upper_dex1_v4.urdf')
    p = params['values']
    cams = load_camera_contract(NOMINAL / 'camera_contract_v5.json')
    cam = np.array(cams[f'{side}_wrist']['T_parent_camera_world_convention'])
    rows = read_trace()
    g = grasp_row(rows)
    configs = {'zero': {}, 'E036_grasp': dict(zip(g['joint_names'], g['joint_positions']))}
    report = {'params_status': params.get('status'), 'side': side, 'tcp_offset_m_in_dex1_base': [0.083, 0, 0],
              'grasp_source': {'trace': str(RUN / 'trace.jsonl'), 'phase': g['phase'], 'time_s': g['time_s'],
                               'arm_q_rad': {n: configs['E036_grasp'][n] for n in arm_joints(side)}}}
    x = g['robot_root_pose']
    root = transform(Rotation.from_quat([x[4], x[5], x[6], x[3]]).as_matrix(), x[:3])
    tcp_sim = np.array(g['tcp'])
    base = root @ robot.fk(f'{side}_dex1_base_link', {k: np.array([v]) for k, v in configs['E036_grasp'].items()}, n=1)[0]
    offset = inv(base) @ tcp_sim
    report['sim_recorded_tcp_in_dex1_base_at_grasp'] = {
        'translation_m': offset[:3, 3].tolist(), 'rotation_deg': float(np.degrees(np.linalg.norm(logm(offset[:3, :3])))),
        'note': 'trace.jsonl "tcp" uses the run controller offset; displacements below use kinematics.py TCP (0.083, 0, 0)'}
    other = Robot(calibrated_urdf) if calibrated_urdf else None
    for name, q in configs.items():
        qa = {k: np.array([v]) for k, v in q.items()}
        res = {}
        for label, link, offset in [('tcp', f'{side}_dex1_base_link', transform(t=[0.083, 0, 0])),
                                    ('run_recorded_tcp', f'{side}_dex1_base_link', transform(t=offset[:3, 3])),
                                    ('wrist_camera', f'{side}_dex1_base_link', cam),
                                    ('dex1_base_link', f'{side}_dex1_base_link', np.eye(4)),
                                    ('elbow_link', f'{side}_elbow_link', np.eye(4))]:
            Tn = robot.fk(link, qa, {}, n=1) @ offset
            Tc = robot.fk(link, qa, p, n=1) @ offset
            res[label] = {k: v[0] for k, v in displacement(Tn, Tc).items()}
            if other is not None:
                Tu = other.fk(link, qa, {}, n=1) @ offset
                res[label]['calibrated_urdf_vs_model_max_abs'] = float(np.abs(Tu - Tc).max())
        report[name] = res
    q = {n: np.array([r['joint_positions'][r['joint_names'].index(n)] for r in rows]) for n in rows[0]['joint_names']}
    Tn = robot.tcp(side, q, {})
    Tc = robot.tcp(side, q, p)
    d, a = pose_error(Tn, Tc)
    phases = [r['phase'] for r in rows]
    report['E036_trajectory'] = {'frames': len(rows), 'tcp_translation_mm': {'mean': 1000 * float(d.mean()), 'max': 1000 * float(d.max()),
                                 'min': 1000 * float(d.min())}, 'tcp_rotation_deg': {'mean': float(np.degrees(a).mean()),
                                 'max': float(np.degrees(a).max())},
                                 'per_phase_mean_mm': {ph: 1000 * float(d[[i for i, x in enumerate(phases) if x == ph]].mean())
                                                       for ph in dict.fromkeys(phases)}}
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('params')
    ap.add_argument('out')
    ap.add_argument('--calibrated-urdf')
    a = ap.parse_args()
    report = evaluate(load_params(a.params), a.calibrated_urdf)
    Path(a.out).write_text(json.dumps(report, indent=2))
    for k in ['zero', 'E036_grasp']:
        print(k, {lab: (round(v['translation_mm'], 2), round(v['rotation_deg'], 3)) for lab, v in report[k].items()})
    print('trajectory', report['E036_trajectory']['tcp_translation_mm'], 'recorded tcp', report['sim_recorded_tcp_in_dex1_base_at_grasp'])


if __name__ == '__main__':
    main()
