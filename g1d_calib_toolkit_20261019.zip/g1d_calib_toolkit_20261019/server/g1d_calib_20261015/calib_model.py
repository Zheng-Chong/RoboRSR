"""Kinematic error model of the G1-D + Dex1 assembly: joint-origin parameters, cameras and calibration boards.

All parameters are deltas from the nominal model (radians / metres / pixels); see docs/error_model_zh.md.
  <revolute joint>/zero            rotation about the joint axis, q_model = q_encoder + zero
  <prismatic joint>/zero           displacement along the axis, same sign convention
  <moving joint>/rot_u, /rot_v     mounting rotation of the joint frame about u, v (unit vectors orthogonal to the axis)
  <fixed joint>/rx, /ry, /rz       mounting rotation (rotation-vector components in the joint frame)
  <any joint>/dx, /dy, /dz         translation of the joint origin, parent-link frame
  camera:<name>/rx..dz             right-multiplied delta of T_parent_camera (+X forward, +Y left, +Z up)
  intrinsics:<name>/fx..           additive delta of the camera intrinsics / distortion
  board:<name>/rx..dz              right-multiplied delta of the nominal board pose in its parent link
  target:<name>/rx..dz             marker frame on a link (6D pose measurements)
  base:<name>/rx..dz               pose of the robot root link in an external measurement frame
"""
from pathlib import Path
import fnmatch
import json
import os
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path('/root/unitree_sim_isaaclab')
NOMINAL = Path(os.environ.get('G1D_CALIB_NOMINAL', ROOT / 'real2sim_g1d_20261015/assembled'))
ARM = ['shoulder_pitch', 'shoulder_roll', 'shoulder_yaw', 'elbow', 'wrist_roll', 'wrist_pitch', 'wrist_yaw']
TCP_OFFSET = np.array([0.083, 0., 0.])
SE3_KEYS = ('rx', 'ry', 'rz', 'dx', 'dy', 'dz')
INTRINSIC_KEYS = {'opencv': ('fx', 'fy', 'cx', 'cy', 'k1', 'k2', 'p1', 'p2', 'k3'),
                  'fisheye': ('fx', 'fy', 'cx', 'cy', 'k1', 'k2', 'k3', 'k4')}
OPTICAL_FROM_CAMERA = np.array([[0., -1, 0], [0, 0, -1], [1, 0, 0]])


def arm_joints(side):
    return [f'{side}_{n}_joint' for n in ARM]


def hat(w):
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])


def rodrigues(axis, angles):
    K = hat(axis)
    s, c = np.sin(angles)[:, None, None], np.cos(angles)[:, None, None]
    return np.eye(3) + s * K + (1 - c) * (K @ K)


def expm(w):
    w = np.asarray(w, float)
    th = np.linalg.norm(w)
    if th < 1e-14:
        return np.eye(3) + hat(w)
    return rodrigues(w / th, np.array([th]))[0]


def logm(R):
    return Rotation.from_matrix(R).as_rotvec()


def transform(R=np.eye(3), t=(0, 0, 0)):
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = t
    return T


def se3(xi):
    return transform(expm(xi[:3]), xi[3:6])


def inv(T):
    out = np.zeros_like(T)
    R = np.swapaxes(T[..., :3, :3], -1, -2)
    out[..., :3, :3] = R
    out[..., :3, 3] = -(R @ T[..., :3, 3, None])[..., 0]
    out[..., 3, 3] = 1
    return out


def perp_basis(axis, previous=None):
    """u, v orthogonal to axis. With the previous joint axis (in this joint frame) not parallel, u is its projection, so
    rot_u is a rotation about the previous axis direction and rot_v (about axis x u) the twist between the two axes."""
    a = np.asarray(axis, float) / np.linalg.norm(axis)
    e = np.eye(3)[(np.argmax(np.abs(a)) + 1) % 3]
    if previous is not None and np.linalg.norm(np.cross(a, previous)) > 0.2:
        e = np.asarray(previous, float)
    u = e - a * (e @ a)
    u /= np.linalg.norm(u)
    return u, np.cross(a, u)


def pose_error(Ta, Tb):
    """Translation (m) and rotation angle (rad) between poses, batched."""
    d = np.linalg.norm(Ta[..., :3, 3] - Tb[..., :3, 3], axis=-1)
    R = np.swapaxes(Ta[..., :3, :3], -1, -2) @ Tb[..., :3, :3]
    c = np.clip((np.trace(R, axis1=-2, axis2=-1) - 1) / 2, -1, 1)
    return d, np.arccos(c)


def se3_of(p, prefix):
    return np.array([p.get(f'{prefix}/{k}', 0.) for k in SE3_KEYS])


class Robot:
    def __init__(self, urdf):
        self.path = Path(urdf)
        xml = ET.parse(urdf).getroot()
        self.joints = {}
        for e in xml.findall('joint'):
            o, a, lim = e.find('origin'), e.find('axis'), e.find('limit')
            vec = lambda key: np.array([float(v) for v in (o.get(key, '0 0 0') if o is not None else '0 0 0').split()])
            j = dict(name=e.get('name'), type=e.get('type'), parent=e.find('parent').get('link'),
                     child=e.find('child').get('link'), xyz=vec('xyz'), rpy=vec('rpy'),
                     axis=np.array([float(v) for v in a.get('xyz').split()]) if a is not None else np.array([1., 0, 0]),
                     lower=float(lim.get('lower', '-inf')) if lim is not None else 0.,
                     upper=float(lim.get('upper', 'inf')) if lim is not None else 0.)
            j['R'] = Rotation.from_euler('xyz', j['rpy']).as_matrix()
            if j['type'] != 'fixed':
                j['axis'] = j['axis'] / np.linalg.norm(j['axis'])
            self.joints[j['name']] = j
        self.by_child = {j['child']: j for j in self.joints.values()}
        self.root = next(j['parent'] for j in self.joints.values() if j['parent'] not in self.by_child)
        for j in self.joints.values():
            if j['type'] != 'fixed':
                prev = self.previous_axis(j)
                j['previous_joint'] = prev[0] if prev else None
                j['u'], j['v'] = perp_basis(j['axis'], prev[1] if prev else None)

    def previous_axis(self, joint):
        """Nearest movable ancestor joint and its axis expressed in the frame of `joint`."""
        R, link = np.eye(3), joint['parent']
        while link in self.by_child:
            p = self.by_child[link]
            if p['type'] != 'fixed':
                return p['name'], joint['R'].T @ R.T @ p['axis']
            R = p['R'] @ R
            link = p['parent']
        return None

    def chain(self, tip, root=None):
        root = root or self.root
        names, link = [], tip
        while link != root:
            j = self.by_child[link]
            names.append(j['name'])
            link = j['parent']
        return names[::-1]

    def param_keys(self, name):
        kind = self.joints[name]['type']
        rot = ['rx', 'ry', 'rz'] if kind == 'fixed' else ['zero', 'rot_u', 'rot_v']
        return rot + ['dx', 'dy', 'dz']

    def origin(self, name, p):
        j = self.joints[name]
        g = lambda k: p.get(f'{name}/{k}', 0.)
        R, t = j['R'], j['xyz'] + np.array([g('dx'), g('dy'), g('dz')])
        if j['type'] == 'fixed':
            R = R @ expm([g('rx'), g('ry'), g('rz')])
        else:
            R = R @ expm(g('rot_u') * j['u'] + g('rot_v') * j['v'])
            if j['type'] == 'prismatic':
                t = t + R @ j['axis'] * g('zero')
            else:
                R = R @ expm(j['axis'] * g('zero'))
        return transform(R, t)

    def fk(self, tip, q, p=None, root=None, n=None):
        """Batched T_root_tip; q maps joint name -> array (N,) (missing joints are 0)."""
        p = p or {}
        n = n if n is not None else len(next(iter(q.values()))) if q else 1
        T = np.tile(np.eye(4), (n, 1, 1))
        for name in self.chain(tip, root):
            j = self.joints[name]
            T = T @ self.origin(name, p)
            if j['type'] in ('revolute', 'continuous'):
                M = np.tile(np.eye(4), (n, 1, 1))
                M[:, :3, :3] = rodrigues(j['axis'], np.broadcast_to(np.asarray(q.get(name, 0.), float), (n,)))
                T = T @ M
            elif j['type'] == 'prismatic':
                T = T.copy()
                T[:, :3, 3] += (T[:, :3, :3] @ j['axis']) * np.broadcast_to(np.asarray(q.get(name, 0.), float), (n,))[:, None]
        return T

    def tcp(self, side, q, p=None, root=None, n=None):
        return self.fk(f'{side}_dex1_base_link', q, p, root, n) @ transform(t=TCP_OFFSET)


def project(model, intr, P):
    """Pinhole + distortion projection of optical-frame points (..., 3) -> pixels (..., 2)."""
    z = P[..., 2]
    x, y = P[..., 0] / z, P[..., 1] / z
    g = lambda k: intr.get(k, 0.)
    if model == 'fisheye':
        r = np.sqrt(x * x + y * y)
        th = np.arctan(r)
        th2 = th * th
        thd = th * (1 + g('k1') * th2 + g('k2') * th2 ** 2 + g('k3') * th2 ** 3 + g('k4') * th2 ** 4)
        s = np.where(r > 1e-12, thd / np.maximum(r, 1e-12), 1.)
        xd, yd = x * s, y * s
    else:
        r2 = x * x + y * y
        radial = 1 + g('k1') * r2 + g('k2') * r2 ** 2 + g('k3') * r2 ** 3
        xd = x * radial + 2 * g('p1') * x * y + g('p2') * (r2 + 2 * x * x)
        yd = y * radial + g('p1') * (r2 + 2 * y * y) + 2 * g('p2') * x * y
    return np.stack([g('fx') * xd + g('cx'), g('fy') * yd + g('cy')], -1)


def intrinsics_dict(cam):
    K = np.asarray(cam['K'], float)
    keys = INTRINSIC_KEYS[cam.get('model', 'opencv')]
    d = dict(fx=K[0, 0], fy=K[1, 1], cx=K[0, 2], cy=K[1, 2])
    d.update(zip(keys[4:], list(cam.get('dist', [])) + [0.] * (len(keys) - 4 - len(cam.get('dist', [])))))
    return d


def board_points(spec):
    """Board-frame corner coordinates {id: xyz} from an explicit list or a ChArUco / AprilGrid description."""
    if 'points_m' in spec:
        return {int(i): np.array(xyz, float) for i, *xyz in spec['points_m']}
    if spec['type'] == 'charuco':
        sx, sy, s = spec['squares_x'], spec['squares_y'], spec['square_length_m']
        return {r * (sx - 1) + c: np.array([(c + 1) * s, (r + 1) * s, 0.]) for r in range(sy - 1) for c in range(sx - 1)}
    if spec['type'] == 'aprilgrid':
        n, t, gap = spec['tag_cols'], spec['tag_size_m'], spec['tag_size_m'] * spec['tag_spacing']
        out = {}
        for k in range(spec['tag_rows'] * n):
            x0, y0 = (k % n) * (t + gap), (k // n) * (t + gap)
            for c, (dx, dy) in enumerate([(0, 0), (t, 0), (t, t), (0, t)]):
                out[4 * k + c] = np.array([x0 + dx, y0 + dy, 0.])
        return out
    raise ValueError(spec['type'])


def expand(patterns, universe):
    out = []
    for pat in patterns:
        hits = [n for n in universe if fnmatch.fnmatchcase(n, pat)]
        if not hits:
            raise KeyError(f'pattern {pat!r} matches no parameter')
        out += [h for h in hits if h not in out]
    return out


class Problem:
    """Residuals of board-pixel and 6D-pose observations for a parameter vector."""

    def __init__(self, robot, meas, names, fixed=None, priors=None):
        self.robot, self.meas, self.names = robot, meas, list(names)
        self.fixed = dict(fixed or {})
        self.priors = priors or {}
        self.root = meas.get('root_link', robot.root)
        self.cameras, self.boards = meas.get('cameras', {}), meas.get('boards', {})
        self.targets, self.bases = meas.get('targets', {}), meas.get('bases', {})
        self.points = {b: board_points(s) for b, s in self.boards.items()}
        samples = meas['samples']
        self.n = len(samples)
        joint_names = sorted({k for s in samples for k in s['joints']})
        self.q = {k: np.array([s['joints'].get(k, 0.) for s in samples]) for k in joint_names}
        self.groups, self.poses = {}, []
        for k, s in enumerate(samples):
            for o in s.get('observations', []):
                if o['type'] == 'board_pixels':
                    g = self.groups.setdefault((o['camera'], o['board']), dict(k=[], pts=[], uv=[], w=[]))
                    pts = self.points[o['board']]
                    for cid, uv in zip(o['corner_ids'], o['pixels']):
                        g['k'].append(k)
                        g['pts'].append(pts[int(cid)])
                        g['uv'].append(uv)
                        g['w'].append(1. / o.get('sigma_px', 0.5))
                elif o['type'] == 'pose6d':
                    self.poses.append(dict(k=k, target=o['target'], base=o['base'], T=np.array(o['T_base_target']),
                                           sm=o.get('sigma_m', 5e-4), sr=o.get('sigma_rad', np.radians(0.2))))
        for g in self.groups.values():
            for key in g:
                g[key] = np.array(g[key])

    def universe(self):
        names = []
        movable = set()
        tips = {c['parent'] for c in self.cameras.values()} | {b['parent'] for b in self.boards.values()} | \
               {t['link'] for t in self.targets.values()}
        for tip in tips:
            movable |= set(self.robot.chain(tip, self.root))
        for j in self.robot.joints:
            if j in movable:
                names += [f'{j}/{k}' for k in self.robot.param_keys(j)]
        for c, spec in self.cameras.items():
            names += [f'camera:{c}/{k}' for k in SE3_KEYS]
            names += [f'intrinsics:{c}/{k}' for k in INTRINSIC_KEYS[spec.get('model', 'opencv')]]
        for kind, d in [('board', self.boards), ('target', self.targets), ('base', self.bases)]:
            names += [f'{kind}:{b}/{k}' for b in d for k in SE3_KEYS]
        return names

    def params(self, x):
        p = dict(self.fixed)
        p.update(zip(self.names, x))
        return p

    def link_poses(self, p, links):
        return {l: self.robot.fk(l, self.q, p, self.root, self.n) for l in links}

    def camera_pose(self, c, p, frames):
        spec = self.cameras[c]
        return frames[spec['parent']] @ np.array(spec['T_parent_camera']) @ se3(se3_of(p, f'camera:{c}'))

    def board_pose(self, b, p, frames):
        spec = self.boards[b]
        return frames[spec['parent']] @ np.array(spec['T_parent_board']) @ se3(se3_of(p, f'board:{b}'))

    def predict_pixels(self, p, camera, board, frames, k, pts):
        spec = self.cameras[camera]
        T = inv(self.camera_pose(camera, p, frames)) @ self.board_pose(board, p, frames)
        P = (T[k, :3, :3] @ pts[:, :, None])[:, :, 0] + T[k, :3, 3]
        P = P @ OPTICAL_FROM_CAMERA.T
        intr = intrinsics_dict(spec)
        for key in intr:
            intr[key] += p.get(f'intrinsics:{camera}/{key}', 0.)
        return project(spec.get('model', 'opencv'), intr, P), P[:, 2]

    def needed_links(self):
        links = {self.cameras[c]['parent'] for c, _ in self.groups} | {self.boards[b]['parent'] for _, b in self.groups}
        links |= {self.targets[o['target']]['link'] for o in self.poses}
        return links

    def residual_blocks(self, x):
        p = self.params(x)
        frames = self.link_poses(p, self.needed_links())
        out = {}
        for (c, b), g in self.groups.items():
            uv, _ = self.predict_pixels(p, c, b, frames, g['k'], g['pts'])
            out[f'pixels:{c}:{b}'] = ((uv - g['uv']) * g['w'][:, None]).ravel()
        if self.poses:
            res = []
            for o in self.poses:
                t = self.targets[o['target']]
                Tb = np.array(self.bases[o['base']]['T_base_root']) @ se3(se3_of(p, f"base:{o['base']}"))
                Tp = Tb @ frames[t['link']][o['k']] @ np.array(t['T_link_target']) @ se3(se3_of(p, f"target:{o['target']}"))
                res.append(np.r_[(Tp[:3, 3] - o['T'][:3, 3]) / o['sm'], logm(o['T'][:3, :3].T @ Tp[:3, :3]) / o['sr']])
            out['pose6d'] = np.concatenate(res)
        if self.priors:
            out['prior'] = np.array([(x[i] - self.priors[n][0]) / self.priors[n][1] for i, n in enumerate(self.names) if n in self.priors])
        return out

    def residual(self, x):
        return np.concatenate(list(self.residual_blocks(x).values()))


def load_params(path):
    doc = json.loads(Path(path).read_text())
    assert doc.get('format') == 'g1d_calib_params_v1', path
    return doc


def load_camera_contract(path):
    doc = json.loads(Path(path).read_text())
    return {v['name']: v for v in doc['views']}
