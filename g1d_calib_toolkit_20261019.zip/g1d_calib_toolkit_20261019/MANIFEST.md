# MANIFEST：文件清单

状态：**核心** = 正式流程要用；**辅助** = 排查、可视化或可选步骤；**附加** = 已弃用/旧版/诊断（`extras/`）；**样例** = 数据样例；**文档**。
运行位置：机器人 = G1-D 本机（conda `tv`）；服务器 = GPU 服务器（`$ISAAC_ENV` 或 `/usr/bin/python3`）；PC = Windows。

打包说明：
- 代码从工作区原样复制，只做了 `docs/环境配置_zh.md` 开头列出的路径/主机名替换（标 ✎ 的文件）。所有 `.py`/`.sh` 都是 LF 行尾、无 BOM。
- `server/tools/render_compare.py`、`compare_overlay.py`、`run_render_compare.sh`、`make_urdf_variants.py` 是 2026-10-19 晚的快照，打包时渲染对比还在进行中。
- `SHA256SUMS.txt` 记录本包所有文件的哈希（原标定包的 `MANIFEST_sha256.txt` 因为副本有改动而未附带）。

## 顶层与文档

| 文件 | 用途 | 状态 |
|---|---|---|
| `README_zh.md` | 工具包说明、目录、快速开始 | 文档 |
| `MANIFEST.md` | 本文件 | 文档 |
| `SHA256SUMS.txt` | 所有文件的 SHA-256 | 文档 |
| `docs/使用手册_zh.md` | 端到端流程（第 0–8 步）：输入、输出、命令、通过标准、典型数值 | 文档 |
| `docs/安全规范_zh.md` | 从真机事故总结的安全规则和检查清单 | 文档 |
| `docs/环境配置_zh.md` | 所有写死的主机/路径/端口、修改方法、常见坑 | 文档 |
| `docs/项目记录_20261015-19.md` | 原始工作记录的脱敏副本（主机名、个人路径、SSH 密钥位置已替换） | 文档 |
| `skills/g1d-robot-calibration/SKILL.md` | Cursor Agent Skill：安全铁律、工作流、队列监控、恢复、汇报 | 文档 |
| `skills/g1d-robot-calibration/reference.md` | Skill 参考：服务协议、每步命令与典型值、日志关键字、恢复脚本 | 文档 |
| `examples/README_zh.md` | 样例数据说明 | 文档 |
| `extras/README_zh.md` | 每个附加脚本的来历和弃用原因 | 文档 |

## robot/（机器人上运行，部署到 `~/calib_sessions/`；服务部署到 `~/g1d_infra_calib/scripts/`）

| 文件 | 用途 | 状态 |
|---|---|---|
| `calib_arm_server.py` | 双臂位置控制服务：启动时保持当前位姿；JSON 指令 `/tmp/g1d_calib/cmd.json`、状态 `status.json`；限位/单步/速度/跟踪误差/断流保护 | 核心 |
| `start_server.sh` | 启动服务（保持当前实测位姿，不运动），已有控制程序时拒绝 | 核心 |
| `takeover2.sh` | 无缝更换服务实例：确认新实例存活并在写自己的状态后才结束旧实例 | 核心 |
| `collect_robot.py` | 设置 B 采集器（本机运行）：检查过的路径、稳定判据、5 帧腕相机 + 头部帧、板漂移监控 4 mm、单实例锁、出错停在同一直线上的上一个路径点 | 核心 |
| `run_queue.sh` | 采集后台队列（`setsid nohup`），`STOP` 文件在两只手臂之间生效 | 核心 |
| `auto_touch.py` | 视觉引导自动触碰：射线定位、绕射线旋转 15°、1.5 mm 步进接触判据、两次触碰、单应性板面点、躯干护栏、IK 收敛检查、异常不自动恢复 | 核心 |
| `touch_queue.sh` | 触碰后台队列（左臂、指尖像素 309/255、姿态列表），`STOP_TOUCH` 在两轮之间生效 | 核心 |
| `contact_point.py` | 用接触图里的 ArUco 码四角做单应性，求指尖像素下的板面点（`auto_touch.py` 调用，也可单独运行） | 核心 |
| `go_home.py` | 只在手臂位于检查过路径的姿态/连线上时回 home（`--via`、`--near`、`--dry`） | 核心 |
| `recover.py` | 跟踪误差锁定后：reset 并立即把出错臂拉回姿态表位姿、另一臂回 home | 核心 |
| `stop_now.sh` | 结束触碰队列和脚本并给服务发 `stop` | 核心 |
| `kill_touch.sh` | 只结束触碰队列和脚本，让当前移动段走完 | 核心 |
| `peek_lowstate.py` | 只读：`rt/lowstate` 是否在发布、频率、手臂关节角 | 辅助 |
| `check_env.py` | 检查 cv2（aruco / CharucoDetector）、zmq、numpy | 辅助 |
| `grab_one.py` | 从 ZMQ 流抓一帧存图 | 辅助 |
| `crop_zoom.py` | 裁剪放大并加像素刻度（读指尖像素） | 辅助 |
| `det_test.py` | 接触图上 ChArUco 检测数量（放大/细化对比） | 辅助 |
| `locate_board_robot.py` | `pc/locate_board.py` 的机器人本机版本（读本机相机流，内参放在 `~/calib_sessions/intrinsics/`，输出 `~/calib_sessions/board_locate_now/board_pose.json`）；打包前刚由同事新增的快照 | 辅助 |
| `repeat_test.py` | 重复性实验：同一姿态 4 种到达方式 + 静止 3 s 再拍 | 辅助 |
| `repeat_analyze.py` | 分析重复性：缩放（类自动对焦）/ 平移旋转（机械）/ 残差 | 辅助 |
| `run_repeat_analyze.sh` | 等 `repeat_test` 完成后运行分析 | 辅助 |
| `calib_ready_pose.py` | 最早的低层控制程序：平滑抬到 ready 位姿并保持（`--dry-run` / `--yes`；`--pose` 默认指向同事仓库的配置文件，需自备） | 辅助 |
| `check_lowcmd_free.py` | 检查 `rt/lowcmd` 是否已有其他写入者 | 辅助 |

## pc/（Windows PC）

| 文件 | 用途 | 状态 |
|---|---|---|
| `arm_client.py` | 经 `ssh unitree` 读写服务的 cmd/status（3 次重试） | 核心 |
| `capture_intrinsics.py` | 内参采图：实时预览，合格帧（9×6 角点、清晰、位姿有变化）自动保存 | 核心 |
| `calibrate_intrinsics.py` | 内参求解：180° 歧义消歧、离群剔除、80/20 留出、验收、导出 `g1d_camera_intrinsics_v1`、双目基线 | 核心 |
| `validate_intrinsics.py` | 内参三层验证：去畸变目视、双目量板、与 `calib_model.project` 对拍 | 核心 |
| `locate_board.py` | 头部双目 PnP 测桌面板在躯干系的位姿 → `board_pose.json` | 核心 |
| `dircheck.py` | 方向检查：逐关节微动并拍腕相机图 | 核心 |
| `which_wrist_cam.py` | 判断哪个 ZMQ 端口是左腕相机 | 核心 |
| `raise_to_zero2.py` | 手臂下垂 → 全 0 位姿（先外展、解开肩 yaw） | 核心 |
| `lift_back_to_zero.py` | 下坠后恢复：先抬肘，再全部回 0 | 核心 |
| `touch_plan.py` | 预测每个悬停姿态的指尖射线落点（也可在机器人上运行） | 核心 |
| `find_tip_pixel.py` | 自动找闭合手指楔形顶点像素 | 辅助 |
| `pull_frames.py` | 三路相机各抓一帧并统计帧率 | 辅助 |
| `sub_lowstate.py` | Windows 直连 DDS 订阅 `rt/lowstate`（需 unitree_sdk2_python，本包未附带） | 辅助 |
| `compare_models.py` | 标准 / 有理 / 鱼眼畸变模型对比（留出误差） | 辅助 |
| `board_timeline.py` | 从会话里每个头部帧重建板位置时间线 | 辅助 |
| `table_edge.py` | 头部相机测桌子近边位置 | 辅助 |
| `check_wrist_view.py` | 当前位姿下腕相机能否看到板 | 辅助 |

## server/tools/（GPU 服务器）

| 文件 | 用途 | 状态 |
|---|---|---|
| `inject_real_intrinsics_patch.py` | 复制标定包并把真实内参注入 `board_setups.py`（生成 `_realcam` 副本） | 核心 |
| `gen_poses.py` | 按实测板位姿生成正式姿态表：候选预过滤、D 最优、FK 离桌门槛、direct/via_home 路径检查 | 核心 |
| `export_meas.py` | ChArUco 检测、多帧融合、质量筛选 → `g1d_calib_measurements_v1`（`/usr/bin/python3`） | 核心 |
| `touch_identify_auto.py` | 触碰辨识：指尖 + 板 + 关节零位（M0/M1/M2）、留一验证、`--fixed` 交叉验证、肩安装 vs 头部 | 核心 |
| `dircheck_analyze.py` | 方向检查分析：SIFT 实测位移 vs FK 预测（`/usr/bin/python3`） | 核心 |
| `render_isaaclab.py` | Isaac Lab：真实 URDF + 真机关节角 + 标定内参渲染四路相机，探针验证主点 | 核心 |
| `run_render_isaaclab.sh` ✎ | 上面脚本的运行包装（环境变量、GPU、超时） | 核心 |
| `overlay_isaaclab.py` | 真机｜仿真｜真机 + 仿真轮廓三联图（`/usr/bin/python3`） | 核心 |
| `make_urdf_variants.py` ✎ | 生成渲染对比用的 URDF 变体（dual_trans、dual_trans_mount） | 核心 |
| `render_compare.py` | 多个 URDF 变体按会话关节角从 head_left 渲染（整体 / 仅左臂） | 核心 |
| `run_render_compare.sh` ✎ | 上面脚本的运行包装 | 核心 |
| `compare_overlay.py` | 真机头部帧去畸变 + 各变体左臂轮廓叠图、中位边缘距离 | 核心 |
| `plan_jog_signs.py` | 方向检查：每关节选让夹爪上升的微动方向 → `dircheck_plan.json` | 辅助 |
| `find_dircheck_pose.py` | 搜索安全的方向检查姿态（桌子较远时用） | 辅助 |
| `estimate_wrist_extrinsic.py` | 从采集样本反推腕相机安装，和合同名义值比较 | 辅助 |
| `repeat_diff.py` | 重复访问时图像变化能否被编码器变化解释 | 辅助 |
| `inspect_identify.py` | 打印辨识参数（度/毫米/像素）和标准差 | 辅助 |
| `pose_clearance.py` | 姿态表每个姿态的 FK 离桌余量 | 辅助 |
| `why_skip.py` | 姿态被标 skip 的原因 | 辅助 |
| `zero_pose_height.py` | 全 0 位姿下最低关键点相对桌面的高度 | 辅助 |
| `eval_layout.py` | 用真实布局跑位姿设计，比较不同机器人距离 | 辅助 |
| `run_eval_layout.sh` ✎ | 上面脚本的运行包装（两种距离并行） | 辅助 |
| `dump_head_cam_T.py` | 计算头部左右目在躯干系的位姿（`locate_board.py` 里写死值的来源） | 辅助 |
| `server_check_assets.sh` | 比较名义资产和渲染资产的哈希、网格引用、会话格式 | 辅助 |
| `build_segments_left.py` | 板在会话中被推动时生成分段文件的模板（10-16 会话） | 辅助 |
| `body_overlay.py` | 不用 IsaacSim 的点云渲染叠图（URDF 网格采样 + FK + 投影） | 辅助 |

## server/runs/（10-19 实际使用的运行脚本，作为模板；均 ✎）

| 文件 | 用途 | 状态 |
|---|---|---|
| `gen_v2.sh` | 10-19 下午布局生成姿态表（`--table-z -0.174 --table-edge-x 0.10 --idle-zero --min-clear 0.10`） | 辅助 |
| `server_left_1019.sh` | 左臂两个会话导出 + 辨识 | 辅助 |
| `server_right_1019.sh` | 右臂会话导出 + 辨识 | 辅助 |
| `server_dual_1019.sh` | 双臂共享板导出 + 辨识 → `params_dual_1019` | 辅助 |
| `server_dual_trans.sh` | 双臂 + 关节平移（3 mm 先验）→ `params_dual_trans_1019` | 辅助 |
| `server_repeat_diff.sh` | 重复性数据解包 + `repeat_diff.py` | 辅助 |

## server/g1d_calib_20261015/（标定包本体，服务器；`calib_model.py` 也部署到机器人）

| 文件 | 用途 | 状态 |
|---|---|---|
| `calib_model.py` | 误差模型：URDF 解析、带参数 FK、相机投影、板角点、残差问题；`G1D_CALIB_NOMINAL` 指定名义资产 | 核心 |
| `identify.py` | 辨识：预设参数集、鲁棒损失、先验、SVD/协方差/相关、k 折留出、参数 JSON | 核心 |
| `pose_design.py` | D 最优位姿设计（`gen_poses.py` 调用） | 核心 |
| `board_setups.py` | 名义场景、可行位姿采样（限位/自碰撞/桌面/可见/遮挡）、合成测量 | 核心 |
| `compare_sim_real.py` | sim-vs-real 角点残差、单参数快速估计 | 核心 |
| `apply_calibration.py` | 参数 JSON → 标定 URDF（upper + full）+ `calibration_provenance.json`，只改关节 origin | 核心 |
| `build_assembly.py` ✎ | 标定 URDF → USD / 物理合同 / 相机合同 / 校验（需 GPU、`ISAAC_PY`） | 核心 |
| `nominal/g1_d_upper_dex1_v4.urdf`、`nominal/g1_d_full_dex1_v4.urdf` | 名义 URDF（上身 / 全身 + Dex1）；**不含 meshes** | 核心 |
| `nominal/camera_contract_v5.json` | 四路相机的父 link 和名义外参 | 核心 |
| `nominal/physics_contract.json` | 名义物理设置 | 辅助 |
| `test_apply_calibration.py` | 单元测试（6 项） | 辅助 |
| `tcp_effect.py` | 参数集对 TCP / 腕相机位姿的影响 | 辅助 |
| `export_replay.py` | 仿真 `trace.jsonl` → 回放轨迹（docs/06） | 辅助 |
| `synthetic_validation.py` | 合成数据验证（生成 `synthetic_validation.json`，未附带，可重跑） | 辅助 |
| `synthetic_validation_table.md` | 合成验证结果表 | 文档 |
| `tools/build_camera_contract_calib.py`、`compare_usd_calib.py`、`convert_prepare_finalize_calib.py`、`make_patched_copies.py`、`validate_sources_calib.py`、`validate_usd_fk.py`、`patched_copies.json` | `build_assembly.py` 的子步骤（资产转换、校验）；依赖服务器项目目录 | 辅助 |
| `README_zh.md` ✎、`PACKAGE_README_zh.md` ✎ | 包说明（conda 路径、主机名已替换；说明未附带网格） | 文档 |
| `docs/00_overview_zh.md` … `docs/07_apply_parameters_zh.md`（8 个）、`docs/error_model_zh.md` | 方法文档：总览、内参、采集、检测导出、sim-vs-real 对比、动态辨识、回放验证、写回；误差模型（`03`、`07` ✎） | 文档 |
| `params_test_left_shoulder_roll_2p6.json` | 占位参数（只用于打通流程） | 样例 |
| `examples/measurements_tiny_example.json`、`measurements_example_A_stereo_left.json`、`measurements_example_B_wrist_left.json` | 合成测量文件样例 | 样例 |
| `examples/identify_demo/`（`params_B_left.json`、`result_B_left.json`、`compare_sim_real_B_left.json`、`quick_roll_nominal_B_left.json`、`urdf/g1_d_upper_dex1_v4.urdf`、`urdf/g1_d_full_dex1_v4.urdf`、`urdf/calibration_provenance.json`） | 辨识 → 参数 → URDF → 对比的完整演示（合成数据） | 样例 |
| `examples/replay_r2s_E009_right_a1.json`、`replay_r2s_E036_left_a1.json` | 仿真验证过的倒水轨迹（docs/06 回放验收） | 样例 |

## examples/（这台机器人的数据，PC / 机器人 / 服务器都会读）

| 文件 | 用途 | 状态 |
|---|---|---|
| `intrinsics/camera_intrinsics_head_left.json`、`_head_right.json`、`_left_wrist.json`、`_right_wrist.json` | 四路相机内参 | 样例 |
| `joint_mapping.json` | 关节映射（电机 15–28、sign +1）与相机端口 | 样例 |
| `dircheck_plan.json` | 方向检查计划 | 样例 |
| `head_cam_T.json` | 头部左右目在躯干系的位姿 | 样例 |
| `poses_20261019/poses_left.json`、`poses_right.json`、`scene_header_B.json`、`board_pose_measured.json`、`summary.json` | 10-19 正式姿态表、场景表头、板位姿、统计 | 样例 |
| `params_1019/params_left_1019.json`、`params_dual_1019.json`、`params_dual_trans_1019.json` | 10-19 辨识参数（`dual_trans` 为候选结果） | 样例 |
| `touch_auto_left_20261019_1757/touches.jsonl`、`log.txt` | 一次触碰批次的记录和日志（82 KB + 27 KB） | 样例 |

## extras/（详见 `extras/README_zh.md`）

| 文件 | 运行位置 | 状态 |
|---|---|---|
| `abandoned/af_lock_server.py` | 机器人 | 附加（用户拒绝：需停 teleimager） |
| `abandoned/touch_teach.py` | 机器人 | 附加（手动示教，被否决） |
| `abandoned/touch_identify.py`、`touch_targets_image.py` | 服务器 / PC | 附加（手动示教配套） |
| `abandoned/af_correct.py`、`per_sample_focal.py`、`server_left_afc.sh` | 服务器 | 附加（自动对焦补偿，证伪；`.sh` ✎） |
| `abandoned/render_sim.py`、`setup_isaac_env.sh` | 服务器 | 附加（IsaacSim 5.0 第一版，机器人未出图） |
| `abandoned/analyze_misalign.py` | 服务器 | 附加（自动边缘匹配不可靠） |
| `legacy/collect.py`、`go_home.py`、`raise_to_zero.py` | PC | 附加（被新版取代） |
| `legacy/takeover.sh` | 机器人 | 附加（无存活确认，勿用） |
| `legacy/add_home_ok.py` | 服务器 | 附加 |
| `legacy/swap_wrist_intrinsics.py` | PC | 附加（一次性修正） |
| `diagnostics/inspect_teleimager.sh`、`inspect_teleimager2.sh`、`grep_teleimager.sh`、`list_cams.sh`、`usb_perm.sh`、`read_arm_q.py` | 机器人 | 附加（只读诊断） |
| `diagnostics/residual_vs_torque.py` | 服务器 | 附加 |
| `diagnostics/check_charuco_legacy.py` ✎、`detect_charuco_dict.py` ✎、`compare_motors.py`、`show_board.py`、`test_detect_once.py` | PC | 附加 |

---

## 有意排除的内容

| 内容 | 原因 |
|---|---|
| 本机 SSH 密钥和 SSH 配置目录（GPU 服务器、机器人两套） | 安全原因；打包时未读取、未复制，文档里也不引用其内容 |
| 同事的仓库 `g1d_infra`（及其 worktree 里的其他文件） | 不是我们的代码；文档里只提到它的相机配置把腕相机端口写反了 |
| `pc_tools/3rd/unitree_sdk2_python/` | 第三方 SDK，从 Unitree 官方获取 |
| `server/g1d_calib_20261015/nominal/meshes/`（约 17 MB STL） | 体积大、属于厂商资产；GPU 服务器名义资产目录里有 |
| `synthetic_validation.json`（1.3 MB）、`poses_left.json` / `poses_right.json` / `pose_design_summary.json`（原包里基于占位场景生成的） | 可重新生成；占位姿态表容易和正式姿态表混淆（正式的在 `examples/poses_20261019/`） |
| 原包 `MANIFEST_sha256.txt` | 副本有改动，哈希对不上；用新的 `SHA256SUMS.txt` 代替 |
| `pc_tools/sessions/*`（采集/触碰会话的 PNG）、`frames_test/` 下的图像、`calib_data/intrinsics/{head,left_wrist,right_wrist}/`（内参采集图和时间戳）、`calib_data/detect_test/`、`calib_data/cap_*.log`、`board_screen.png`、`IsaacSim对比图/`、`触碰目标点.jpg` | 图像大数据（会话约 260 MB、内参采集约 150 MB、frames_test 约 52 MB），且与这台机器人绑定 |
| `.venv/`、`.git/`、`__pycache__/` | 本机环境 / 版本库 / 缓存 |
| 10-15 DDS 排查脚本：`robot_*.py`、`robot_*.sh`（19 个） | 一次性排查 `rt/lowstate` 读不到的问题；`robot_arm_diag.py` 还依赖同事仓库 |
| 服务器环境探测：`probe_*.py/sh`（11 个）、`check_isaac.sh`、`check_server2.sh`、`find_cv2.sh`、`retry_aliyun.sh`、`check_mesh_fmt.sh`、`dump_urdf_contract.sh`、`find_cam_extrinsics.sh`、`archive_sim.sh`、`kill_stale.sh`、`run_grip_both.sh` | 一次性环境探测 / 归档 / 清理 |
| IsaacSim 5.0 第一版调试：`render_smoke.py`、`solve_render_pose.py`、`overlay_sim.py`、`debug_view.py`、`debug_view_ab.py`、`dump_link_poses.py`、`dump_fk_poses.py`、`cmp_link_poses.py`、`inspect_stage*.py`（6 个）、`inspect_usd.py`、`check_probes_in_sim.py` | 已作废路线的调试脚本（代表性的 `render_sim.py` 保留在 `extras/abandoned/`） |
| 出图脚本：`compare_two_renders.py`、`crop_overlay.py`、`crop_sim_overlay.py`、`export_jpg.py`、`evidence_figure.py`、`zoom_isaaclab.py`、`zoom_torso.py`、`measure_arm_shift.py`、`px_to_angle.py` | 一次性图片裁剪/拼接，带本机绝对路径 |
| 被 10-19 版本取代的运行脚本：`server_export_left.sh`、`server_identify_left.sh`、`server_sessions_status.sh`、`server_swap.sh`、`run_gen_v3.sh`、`run_rvt.sh` | 由 `server/runs/` 里的版本取代 |
| 其他一次性脚本：`peek_example.py`、`smoke_realcam.py`、`dump_pose_info.py`、`diag_capture_live.py`、`choose_ref_pose.py`、`find_raise_pose.py`、`pose_dist.py` | 探查/早期方案，不再需要 |
