# G1-D 标定参考（给 Agent）

`<KIT>` = 工具包根目录。机器人 python：`PYR=~/miniconda3/envs/tv/bin/python`。服务器 python：`$ISAAC_ENV/bin/python`（下称 `$PY`）。

## 1. 手臂控制服务协议

指令：原子写 `/tmp/g1d_calib/cmd.json`（先写 `.tmp` 再 `mv`），`seq` 必须比 `status.seq_done` 大（脚本用毫秒时间戳）。

| cmd | 字段 | 说明 |
|---|---|---|
| `move` | `arm_q`（14 个：左 7 + 右 7，URDF 值 = 电机 q）、`seconds` | 最小加加速度轨迹；时长自动拉长到峰值速度 ≤ vmax |
| `jog` | `motor`（15–28）、`delta`（≤ 0.1 rad）、`seconds` | 相对当前指令 |
| `stop` | — | 冻结在当前指令点 |
| `reset` | — | 清除 ERROR，指令设为当前实测位置（会多下沉一个下垂量，用 `recover.py` 代替） |
| `return` | — | 回到服务启动时的位姿后退出（一般不用） |
| `free` / `hold` | `side` | 手动拖动示教模式（已弃用的流程，不要用） |

状态 `/tmp/g1d_calib/status.json`（每 50 ms）：`state`（idle / moving / error / free / exited）、`seq_done`、`msg`（`REJECTED: ...`、`refused ...`、`tracking error ... on motor k`）、`arm_q`、`arm_q_cmd`、`arm_dq`、`arm_tau`、`all_q`（35 个电机）、`vmax`、`n_pub`（发布计数，应持续增长）、`pid`。

服务端限制：限位内缩 0.05 rad；单条 ≤ 1.6 rad（脚本把 > 1.5 rad 的移动分段）；跟踪误差 > 0.2 rad 锁定；`rt/lowstate` 断流 0.5 s 退出。

## 2. 每步命令与通过标准

| 步骤 | 命令（简） | 通过标准 | 这台机器人的典型值 |
|---|---|---|---|
| 0 使能 | `ssh unitree "$PYR ~/calib_sessions/peek_lowstate.py"`；`ssh unitree "bash ~/calib_sessions/start_server.sh"` | 有频率和 mode_machine；日志有 `server ready` | mode_machine=5 |
| 0 回 home | `cd <KIT>/pc && python raise_to_zero2.py`（下垂时）/ `lift_back_to_zero.py`（下坠到板上方时） | 全部关节 \|q\| < 0.02 | — |
| 1 内参 | `capture_intrinsics.py <cam> N` → `calibrate_intrinsics.py all` → `validate_intrinsics.py` | 留出 ≤ 1.3× 训练；std < 0.5 px | 头 fx≈279.3/279.8、留出 0.35 px、基线 61.37 mm；左腕 fx≈315.7、右腕≈313.0 |
| 2 方向 | `plan_jog_signs.py` → `pc/dircheck.py left right` → `dircheck_analyze.py <session>` | 余弦 > 0.9，只有被指令电机变化 | 余弦 0.973–1.000，sign 全 +1 |
| 3 姿态表 | `pc/locate_board.py` → `gen_poses.py --board-json ... --table-z ... --table-edge-x ... --idle-zero --min-clear 0.10 --out ...` | 每臂可用 ≥ 40 | 左 47 / 右 43 |
| 4 采集 | `run_queue.sh left right`（后台） | 只因 STOP 结束；板漂移 ≤ 2–3 mm | 47 / 43 个样本，漂移 ≤ 2.5 / 0.9 mm，每臂约 20–25 分钟 |
| 5 导出 | `/usr/bin/python3 export_meas.py --session ... --header .../scene_header_B.json --board-name ... --out ...` | 大部分样本保留 | 47 → 43；PnP 0.23–0.94 px |
| 6 辨识 | `$PY identify.py <meas...> --preset auto --refine-intrinsics --loss soft_l1 --f-scale 1.0 --folds 5 --out ... --params-out ...` | 留出 ≤ 1 px、std < 0.05°、无 unidentifiable | **未达标**：~5 px；零位 < 1°；腕 fx −16/−17 px |
| 7 触碰 | `auto_touch.py left --tip-u 309 --tip-v 255 --tip-depth 0.100 --rolls 15 ...` / `touch_queue.sh` | 两次触碰差 < 0.5 mm（不滑动） | 0.2–0.3 mm（接近方向）；滑动时 1.5–2.6 mm |
| 7 触碰辨识 | `$PY touch_identify_auto.py <board_pose_measured.json> <touches.jsonl...> [--exclude ...] [--fixed params.json ...]` | 留一板面内误差越小越好 | 名义 5.3 mm → `params_dual_trans_1019` 1.6 mm |
| 8 写回 | `$PY apply_calibration.py <params> <out_dir>`；`build_assembly.py <params> assembled_<tag> --gpu N` | 只改关节 origin；`test_apply_calibration.py` 6/6 | — |
| 8 叠图 | `make_urdf_variants.py` → `GPU=N OUT=... bash run_render_compare.sh` → `compare_overlay.py <out> <head_left 内参>` | 轮廓贴合（目视为准） | 打包时进行中 |

关节平移变体：在步骤 6 命令上加 `--estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003'`。

触碰辨识排除写法：`--exclude B_left_001,B_left_034@-0.04@0`（整个姿态 / 某个偏移点）。上臂可能贴躯干的点（左肩 roll 实测 > −0.03 且手臂在身侧）要排除。

## 3. 日志关键字

`~/calib_sessions/queue.log`（`collect_robot.py`）：

| 关键字 | 含义 | 处理 |
|---|---|---|
| `<id>: OK corners N (exp M) ... board drift x mm` | 正常样本 | — |
| `SKIP (flagged)` / `not settled, skip` / `moved during capture` | 跳过该姿态 | 正常，个别出现即可 |
| `ABORT at <id>: BOARD MOVED x mm` | 板被推动 | 停止，汇报，检查板固定 |
| `ABORT at ...: 3 poses in a row without board detection` | 连续看不到板 | 汇报 |
| `ABORT ... other arm / waist drift` | 另一只手臂或腰漂移 | 汇报 |
| `server error latched ... Operator check required` | 服务 ERROR | 按 §4 恢复（需许可） |
| `parking on the same line at last waypoint` / `parked` | 已退回上一个路径点 | 手臂在检查过的姿态上，可 `go_home.py` |
| `DONE n samples -> <dir> (ABORTED)` / `queue stopped (rc=3)` | 结束 | 汇报 |
| `STOP file found, queue ends` | 正常停止 | — |

`touch_queue.log` / `touch_auto_*/log.txt`（`auto_touch.py`）：

| 关键字 | 含义 |
|---|---|
| `hover: N corners, ray hit [x, y] m, D d m, incidence a deg` | 悬停视图正常 |
| `... -> skip` | 该点被跳过（脚本会原路退回） |
| `IK did not converge: x mm, y deg` | IK 失败，该目标没下发 |
| `too close to the torso -> skip` | 躯干护栏拦截 |
| `REJECTED: ... -> skip` | 服务拒绝（手臂没动） |
| `A/B cmd ... CONTACT` | 第 1/2 次接触 |
| `repeat: camera at contact 1 vs 2 differs x mm` | 重复性 |
| `lag grew ... not a clean contact` | 压力保护触发 |
| `ABORT: ... arm left holding where it is` | 异常退出（返回码 3），**手臂停在原地，需要人决定** |
| `run exited 3, queue stopped` | 队列因上一条停止 |

## 4. 恢复脚本

所有恢复都需要用户许可，先 `--dry` 看计划。

| 情况 | 命令（机器人上） | 脚本行为 |
|---|---|---|
| 服务 ERROR 锁定 | `$PYR -u ~/calib_sessions/recover.py <side> <POSE_ID> --dry` → 去掉 `--dry` | 检查出错臂离该姿态 < 0.4 rad、另一臂离 home < 0.15 rad；`reset` 后立即把出错臂指令到该姿态、另一臂到 home（6 s） |
| 停在姿态表某姿态（误差 < 0.05 rad） | `$PYR -u ~/calib_sessions/go_home.py <side> --dry` | 该姿态 `home_path_ok` 时沿检查过的路径回 home，否则拒绝 |
| 停在悬停高度附近（平移/旋转后） | `go_home.py <side> --near <POSE_ID> <TOL_RAD> --dry` | 每个关节离该姿态都 < TOL 时先直线回该姿态，再回 home |
| 停在两个姿态之间的连线上 | `go_home.py <side> --via <POSE_ID> --dry` | 偏离连线 < 0.02 rad 时沿连线退回 `--via` 姿态（或继续走完到 home 的检查路径） |
| 手臂下坠到板上方（服务正常） | PC：`python lift_back_to_zero.py` | 先把两肘转到 0（手抬起），再全部回 0 |
| 换服务实例 | `VMAX=0.2 bash ~/calib_sessions/takeover2.sh` | 新实例确认存活并写自己的状态后才结束旧实例；失败时旧实例继续运行 |

## 5. 进程与文件

```bash
ssh unitree "pgrep -af '[c]alib_arm_server.py|[c]ollect_robot.py|[a]uto_touch.py|[r]un_queue.sh|[t]ouch_queue.sh'"
ssh unitree "ls -dt ~/calib_sessions/calib_* ~/calib_sessions/touch_auto_* | head -5"
ssh unitree "wc -l ~/calib_sessions/<会话目录>/samples.jsonl"
```

- `collect_robot.py` 单实例锁：`/tmp/g1d_calib/collector.lock.d/`（进程不在时自动接管旧锁）。
- `touch_queue.sh` 每轮之间 `sleep 61`：输出目录名精确到分钟。
- 返回码：`collect_robot.py` 0 正常 / 3 中止；`auto_touch.py` 3 异常中止；`sys.exit("abort: ...")` 为 1（启动前检查不通过，手臂没动）。

## 6. 传数据到服务器

```bash
ssh unitree "cd ~/calib_sessions && tar czf /tmp/<name>.tgz <会话目录>"
scp unitree:/tmp/<name>.tgz .
scp <name>.tgz <GPU_SERVER>:/dev/shm/isaac_work/
# 服务器：解到 /root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/<日期>/sessions/
```

GPU 服务器的 sshd 会拒绝过多并发连接：串行执行，失败时等几秒重试，把多条命令写进一个脚本一次执行。
