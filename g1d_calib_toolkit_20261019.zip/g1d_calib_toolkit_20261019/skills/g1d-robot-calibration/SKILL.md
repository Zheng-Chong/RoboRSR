---
name: g1d-robot-calibration
description: 安全地操作 G1-D（Unitree 轮式底盘 + 升降柱 + 双 7 自由度手臂 + Dex1 夹爪 + 头部双目 + 左右腕相机）真机→仿真标定工具包：相机内参、关节方向检查、姿态表生成、机器人本机后台采集队列（calib_arm_server / collect_robot / run_queue）、测量导出与运动学辨识（export_meas / identify.py）、视觉引导自动触碰标定（auto_touch / touch_identify_auto）、URDF 写回和 IsaacSim 渲染对比。在需要移动 G1-D 手臂做标定、监控或恢复标定队列、处理 status.json 报错（REJECTED / tracking error）、或解读辨识与触碰结果时使用。
---

# G1-D 真机标定

工具包根目录（下称 `<KIT>`）：`robot/`（机器人上运行）、`server/`（GPU 服务器）、`pc/`（Windows PC）、`docs/`、`examples/`（这台机器人的数据样例）。完整步骤见 `<KIT>/docs/使用手册_zh.md`，事故来源见 `<KIT>/docs/安全规范_zh.md`。

## 安全铁律

每次让手臂运动之前对照一遍。违反任何一条都可能让手臂撞板、撞躯干或失去控制下坠。

1. **先问人**：启动任何会让手臂运动的命令（采集队列、触碰、回 home、恢复）之前，向用户确认有人守在急停旁，并得到这一次的明确许可。
2. **不碰系统服务和权限**：不停止/修改 Unitree 的 `teleimager` 服务；不执行或索取 sudo；不修改同事仓库 `~/g1d_infra`。
3. **不重启手臂控制服务**：服务停止发布时手臂会下坠。必须换实例时只用 `takeover2.sh`（确认新实例在写自己的状态后才结束旧实例）。不要 `kill` 正在运行的 `calib_arm_server.py`。
4. **只走检查过的路径**：不要从一个悬停姿态直接去另一个悬停姿态；跳过任何姿态都先回 home（全 0 位姿）。不去 `skip=true` 的姿态；`home_path_ok=false` 的姿态不能直接回 home。
5. **REJECTED / refused = 手臂没动**：当作跳过，沿走过的路原路退回；不要重发，不要当成卡死。
6. **板附近出异常不自动恢复**：脚本退出后手臂由服务保持在原地，先汇报，由用户决定。
7. **ERROR 锁定时不要只发 `reset`**：`reset` 会保持已下垂的实测位姿，两臂再下沉约 0.04 rad。用 `recover.py <side> <POSE_ID>`（先 `--dry`）。
8. **躯干护栏**：左肩 roll 在身侧 ≥ +0.05 rad、身前（肩 pitch < −0.4）≥ −0.10 rad，右臂取反。手写 IK 目标也要满足。
9. **IK 不收敛不执行**：残差 > 2 mm 或 > 0.5° 就放弃这个目标。
10. **板附近不做单腕关节旋转**（指尖会画弧）；要改姿态就绕指尖射线做笛卡尔旋转。
11. **板必须固定、余量 ≥ 10 cm**：姿态表用 `--min-clear 0.10` 生成；采集开启 4 mm 板漂移监控（`collect_robot.py` 默认）。
12. **长任务放到机器人本机后台**：`setsid nohup ... &`，不要从 PC 用 ssh 循环驱动机器人。
13. **查进程用 `pgrep -f '[a]uto_touch.py'` 这种写法**，避免匹配到命令行本身。
14. **同一时间只有一个程序给服务发指令**。

## 文件位置

| 位置 | 内容 |
|---|---|
| 机器人 `~/calib_sessions/` | `robot/` 下脚本、`queue.log`、`touch_queue.log`、`STOP`/`STOP_TOUCH`、会话目录 |
| 机器人 `~/calib_sessions/model/`、`poses_20261019/` | `calib_model.py` + URDF + 相机合同；姿态表 + `scene_header_B.json` |
| 机器人 `~/g1d_infra_calib/scripts/calib_arm_server.py` | 手臂控制服务 |
| 机器人 `/tmp/g1d_calib/{cmd.json,status.json}` | 服务指令 / 状态 |
| 机器人 python | `~/miniconda3/envs/tv/bin/python` |
| 服务器 `/root/unitree_sim_isaaclab/real2sim_calib_20261015[_realcam]/` | 标定包 / 真实内参副本；数据在 `real_data/<日期>/` |
| 服务器 `/dev/shm/isaac_work/` | 临时工作目录（重启清空） |
| 服务器 python | `$ISAAC_ENV/bin/python`（unitree_sim_env）；导出用 `/usr/bin/python3` |

## 工作流

复制这个清单并逐项更新：

```text
- [ ] 0 使能（L2+R2 调试模式）→ peek_lowstate.py → start_server.sh → 双臂回 home
- [ ] 1 相机内参（pc/capture_intrinsics.py → calibrate_intrinsics.py all）
- [ ] 2 方向检查（plan_jog_signs.py → pc/dircheck.py → dircheck_analyze.py；余弦 > 0.9）
- [ ] 3 测板位姿（pc/locate_board.py）→ 服务器 gen_poses.py --min-clear 0.10 → 拷姿态表到机器人
- [ ] 4 采集：run_queue.sh left right（后台）→ 监控 queue.log
- [ ] 5 导出：export_meas.py（同一块板、机器人没动时两臂用同一个 --board-name）
- [ ] 6 辨识：identify.py --preset auto --refine-intrinsics --loss soft_l1 --folds 5（可加关节平移 3 mm 先验）
- [ ] 7 触碰：auto_touch.py / touch_queue.sh（后台）→ touch_identify_auto.py（--fixed 交叉验证）
- [ ] 8 写回：apply_calibration.py →（build_assembly.py）→ render_compare.py + compare_overlay.py
```

每一步的命令、通过标准、典型数值见 [reference.md](reference.md)。

## 后台队列

```bash
# 启动（先确认：服务 idle、双臂在 home、用户已许可）
ssh unitree "setsid nohup bash ~/calib_sessions/run_queue.sh left right > /dev/null 2>&1 < /dev/null &"
ssh unitree "setsid nohup bash ~/calib_sessions/touch_queue.sh > /dev/null 2>&1 < /dev/null &"
# 监控（每 1–2 分钟一次即可）
ssh unitree "tail -n 15 ~/calib_sessions/queue.log"
ssh unitree "grep -v '^     [AB] cmd' ~/calib_sessions/touch_queue.log | tail -n 15"
ssh unitree "cut -c1-220 /tmp/g1d_calib/status.json; echo"
# 停止：两任务之间停 / 立即停 / 只结束脚本
ssh unitree "touch ~/calib_sessions/STOP"        # 或 STOP_TOUCH
ssh unitree "bash ~/calib_sessions/stop_now.sh"
ssh unitree "bash ~/calib_sessions/kill_touch.sh"
```

等待时用真正的后台计时（例如后台 `Start-Sleep 90` 后再读结果），并确认等待确实发生了；不要在 PC 上紧循环轮询 ssh。PowerShell 里不要在 `ssh "..."` 中写含 `$`、嵌套引号的 bash：写成本地 `.sh`，`scp` 后 `ssh unitree "bash /tmp/x.sh"`。

## 出错时

1. 读 `status.json` 的 `state`/`msg` 和日志最后 30 行，**先汇报，不动手臂**。
2. 按情况给用户建议，得到许可再执行（都先加 `--dry`）：
   - `state=error`（tracking error）：`recover.py <side> <最近的姿态 ID>`。
   - `idle` 但手臂停在姿态表某姿态附近：`go_home.py <side>`、`--near POSE TOL` 或 `--via POSE`。
   - 脚本拒绝（"not on a line" / "not parked at a pose with a checked path"）：交给用户手动处理，不要自己编路径。
   - 服务进程不在了：立即告诉用户（手臂可能已下坠），不要自行启动服务去"接住"手臂，除非用户确认现场安全。
3. 采集中止原因 `BOARD MOVED`：板被碰了，后续数据需要按 `board_timeline.py` 分段；先让用户检查板的固定。

## 向用户汇报

```markdown
## <步骤> 结果
- 做了什么：<命令 / 会话目录>
- 结果：<样本数、残差、留出误差、重复性……与 reference.md 的典型值对比>
- 异常：<中止原因、跳过的姿态、REJECTED 次数>；手臂当前状态：<home / 某姿态 / error>
- 下一步建议：<……>（需要用户许可的动作单独列出）
```

## 参考

- [reference.md](reference.md)：每步命令、通过标准、典型数值、日志关键字、恢复脚本参数
- `<KIT>/docs/安全规范_zh.md`、`<KIT>/docs/环境配置_zh.md`、`<KIT>/docs/使用手册_zh.md`
