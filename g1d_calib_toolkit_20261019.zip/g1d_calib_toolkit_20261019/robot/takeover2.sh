#!/bin/bash
# seamless restart of calib_arm_server: new instance holds the old instance's commanded pose, then kill -9 the old one.
# The old instance is killed ONLY after the new one is verified alive AND publishing its own status.
# usage: VMAX=0.2 bash takeover2.sh
PY=/home/unitree/miniconda3/envs/tv/bin/python
OLD=$(pgrep -f '[c]alib_arm_server.py' | head -1)
[ -z "$OLD" ] && { echo "no running server"; exit 1; }
$PY -c "import json;s=json.load(open('/tmp/g1d_calib/status.json'));assert s['state']=='idle',s['state'];json.dump({'arm_q':s['arm_q_cmd']},open('/tmp/g1d_calib/init_pose.json','w'));print('hold target',[round(v,3) for v in s['arm_q_cmd']])" || { echo "old server not idle"; exit 1; }
cd /home/unitree/g1d_infra_calib/scripts
nohup $PY -u calib_arm_server.py --yes --vmax ${VMAX:-0.2} --init-pose /tmp/g1d_calib/init_pose.json > /tmp/g1d_calib_server_new.log 2>&1 &
NEW=$!
for i in $(seq 1 30); do sleep 0.5; grep -q "server ready" /tmp/g1d_calib_server_new.log && break; done
cat /tmp/g1d_calib_server_new.log
grep -q "server ready" /tmp/g1d_calib_server_new.log || { echo "NEW SERVER NOT READY -> old one keeps running"; kill -9 $NEW 2>/dev/null; exit 1; }
sleep 3
if ! kill -0 "$NEW" 2>/dev/null; then echo "NEW SERVER DIED -> old one keeps running"; cat /tmp/g1d_calib_server_new.log; exit 1; fi
$PY - "$NEW" <<'EOF' || { echo "NEW SERVER NOT PUBLISHING ITS STATUS -> killing new, old one keeps running"; kill -9 $NEW; exit 1; }
import json, sys, time
new = int(sys.argv[1]); seen = []
for _ in range(20):
    try:
        s = json.load(open('/tmp/g1d_calib/status.json'))
        if s.get('pid') == new:
            seen.append(s['n_pub'])
            if len(seen) >= 2 and seen[-1] > seen[0]:
                sys.exit(0)
    except Exception:
        pass
    time.sleep(0.2)
sys.exit(1)
EOF
kill -9 "$OLD" && echo "old server $OLD killed (no motion)"
sleep 1.5
if ! kill -0 "$NEW" 2>/dev/null; then echo "!!! NEW SERVER DIED AFTER TAKEOVER - NO CONTROLLER RUNNING !!!"; exit 2; fi
cp /tmp/g1d_calib_server_new.log /tmp/g1d_calib_server.log
$PY -c "import json;s=json.load(open('/tmp/g1d_calib/status.json'));print('state',s['state'],'vmax',s['vmax'],'pid',s.get('pid'),'n_pub',s['n_pub'])"
