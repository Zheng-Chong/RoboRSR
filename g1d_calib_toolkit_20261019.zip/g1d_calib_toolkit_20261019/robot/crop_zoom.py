# crop_zoom.py -- crop + nearest-neighbour zoom with a pixel grid label every 10 px (for reading fingertip pixels)
# usage: python crop_zoom.py in.png out.png u0 v0 u1 v1 [zoom] [mark_u mark_v ...]
import sys

import cv2

f, out, u0, v0, u1, v1 = sys.argv[1], sys.argv[2], *map(int, sys.argv[3:7])
z = int(sys.argv[7]) if len(sys.argv) > 7 else 4
marks = list(map(float, sys.argv[8:]))
im = cv2.imread(f)[v0:v1, u0:u1]
big = cv2.resize(im, None, fx=z, fy=z, interpolation=cv2.INTER_NEAREST)
for u in range(u0 - u0 % 10 + 10, u1, 10):
    x = (u - u0) * z
    cv2.line(big, (x, 0), (x, 6), (0, 0, 255), 1)
    cv2.putText(big, str(u), (x + 1, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1)
for v in range(v0 - v0 % 10 + 10, v1, 10):
    y = (v - v0) * z
    cv2.line(big, (0, y), (6, y), (0, 0, 255), 1)
    cv2.putText(big, str(v), (8, y + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1)
for mu, mv in zip(marks[::2], marks[1::2]):
    cv2.circle(big, (int((mu - u0 + 0.5) * z), int((mv - v0 + 0.5) * z)), 3 * z // 2, (0, 255, 0), 1)
cv2.imwrite(out, big)
