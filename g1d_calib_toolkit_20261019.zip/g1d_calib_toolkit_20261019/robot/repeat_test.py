# repeat_test.py -- repeatability test ON THE ROBOT: same pose reached 4 ways, wrist images compared offline.
#   A1: home -> q        P: q -> q+d -> q (all joints +d)      N: q -> q-d -> q      A2: q -> home -> q
# each visit: settle, 5 wrist frames + encoders; then hold 3 s and capture again (autofocus drift at rest)
# usage: python -u repeat_test.py <left|right> [--n 4] [--delta 0.03]
import argparse
import json
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

BASE = Path.home() / "calib_sessions"
POSES = BASE / "poses_20261019"
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
WRIST_PORT = {"left": 55557, "right": 55556}
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
ALLJ = [f"{s}_{j}_joint" for s in ("left", "right") for j in ARM]

ap = argparse.ArgumentParser()
ap.add_argument("side", choices=["left", "right"])
ap.add_argument("--n", type=int, default=4)
ap.add_argument("--delta", type=float, default=0.03)
ap.add_argument("--session", default="", help="collection session used to pick well-detected poses")
a = ap.parse_args()
side = a.side
off = 0 if side == "left" else 7


def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.1)
    return json.loads(STATUS.read_text())


def send(cmd):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(dict(cmd, seq=seq)))
    os.replace(tmp, CMD)
    return seq


def move(arm_q, seconds=3.0, timeout=180):
    seq = send({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds})
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] == "error":
            raise RuntimeError(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith(("REJECTED", "refused")):
                raise RuntimeError(s["msg"])
            return s
        time.sleep(0.05)
    raise TimeoutError("move timeout")


def move_line(q7, seconds=3.0):
    start = np.array(status()["arm_q_cmd"])
    goal = start.copy(); goal[off:off + 7] = q7
    n = max(1, int(np.ceil(np.abs(goal - start).max() / 1.5)))
    for k in range(1, n + 1):
        move(start + (goal - start) * k / n, seconds / n)


def settle():
    time.sleep(1.5)
    hist = []
    for _ in range(200):
        s = status()
        hist.append(np.array(s["arm_q"]))
        if len(hist) >= 10 and np.ptp(np.array(hist[-10:]), axis=0).max() < 0.001:
            return
        time.sleep(0.05)


ctx = zmq.Context.instance()


def grab(n):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://127.0.0.1:{WRIST_PORT[side]}")
    s.recv(); s.recv()
    out = [cv2.imdecode(np.frombuffer(s.recv(), np.uint8), cv2.IMREAD_COLOR) for _ in range(n)]
    s.close(0)
    return out


doc = json.loads((POSES / f"poses_{side}.json").read_text())
P = {p["id"]: p for p in doc["setups"]["B_wrist_table_board"]["poses"]}
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])
# pick poses: best live detection in the given collection session, direct path home checked
cands = []
for line in open(a.session):
    r = json.loads(line)
    p = P.get(r["id"])
    if p and p.get("home_path_ok") and not p.get("skip"):
        cands.append((r["live_charuco_corners"], r["id"]))
picks = [pid for _, pid in sorted(cands, reverse=True)[: a.n]]
st0 = status()
if st0["state"] != "idle" or np.abs(np.array(st0["arm_q"])[off:off + 7] - home).max() > 0.1:
    sys.exit("abort: server not idle or arm not at home")
out = BASE / time.strftime(f"repeat_%Y%m%d_%H%M_{side}")
out.mkdir(parents=True)
print(f"repeat test {out.name}: poses {picks}, delta {a.delta}", flush=True)
recs = []
try:
    for pid in picks:
        q = np.array([P[pid]["joints"][f"{side}_{j}_joint"] for j in ARM])
        plan = [("A1", [q]), ("P", [q + a.delta, q]), ("N", [q - a.delta, q]), ("A2", [home, q])]
        move_line(q, P[pid]["move_duration_s"])        # first arrival from home
        for tag, way in plan:
            if tag != "A1":
                for w in way:
                    move_line(w, 3.0)
            settle()
            for phase in ("t0", "t3"):
                if phase == "t3":
                    time.sleep(3.0)
                jb = status()["arm_q"]
                imgs = grab(5)
                ja = status()["arm_q"]
                files = []
                for k, im in enumerate(imgs):
                    fn = f"{pid}_{tag}_{phase}_{k}.png"
                    cv2.imwrite(str(out / fn), im)
                    files.append(fn)
                recs.append({"pose": pid, "visit": tag, "phase": phase, "q_before": jb, "q_after": ja, "files": files,
                             "t": time.time()})
            print(f"  {pid} {tag}: captured", flush=True)
        move_line(home, 3.0)
finally:
    (out / "repeat.json").write_text(json.dumps({"side": side, "delta": a.delta, "poses": picks, "records": recs}, indent=1))
    try:
        if np.abs(np.array(status()["arm_q_cmd"])[off:off + 7] - home).max() > 0.01:
            print("  returning home", flush=True)
            move_line(home, 3.0)
    except Exception as e:
        print(f"  return home failed: {e}", flush=True)
print(f"DONE {len(recs)} captures -> {out}", flush=True)
