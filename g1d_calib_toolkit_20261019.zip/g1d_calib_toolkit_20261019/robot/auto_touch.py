# auto_touch.py -- automatic, vision-guided touch calibration ON THE ROBOT (closed gripper fingertip corner as probe)
# per hover pose:
#   1 home -> hover pose (checked path from the pose table)
#   2 wrist-camera PnP of the table board; ray through the fingertip-corner pixel must hit the board interior
#   3 roll the gripper about that ray (ray through the camera centre is invariant -> corner stays on it)
#     so that the chosen fingertip corner leads; each roll magnitude in --rolls gives one touch point
#     (orientation diversity separates the fingertip offset from the board pose)
#   4 approach along the ray in small Cartesian steps; contact = after free motion, the measured camera advances
#     < STALL_FRAC of the command over STALL_STEPS steps (the contact is compliant: it still creeps ~25%)
#   5 record the per-step history (for the contact-onset knee), encoders, contact images and the board point under
#     the fingertip pixel from the markers seen at contact (homography, focal-independent);
#     back off 1 cm and touch again (repeatability / real-contact check)
#   6 retract along the ray; back to hover; home. EVERY exit after reaching the hover goes hover -> home
# usage: python -u auto_touch.py <left|right> --tip-u U --tip-v V [--max N] [--poses id1,id2,...] [--center]
import argparse
import json
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq
from scipy.spatial.transform import Rotation

BASE = Path.home() / "calib_sessions"
sys.path.insert(0, str(BASE / "model"))
sys.path.insert(0, str(BASE))
os.environ.setdefault("G1D_CALIB_NOMINAL", str(BASE / "model"))
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402
from contact_point import contact_point  # noqa: E402

POSES = BASE / "poses_20261019"
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
WRIST_PORT = {"left": 55557, "right": 55556}
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
ALLJ = arm_joints("left") + arm_joints("right")
STEP = 0.0015            # m per approach step
PRE_MARGIN = 0.03        # stop the fast approach this far before the predicted contact
TIP_DEPTH_GUESS = 0.16   # m camera -> fingertip along the ray; deliberately LONG (short fast approach) until measured
TIP_DEPTH_MIN = 0.05     # step limit assumes the tip could be this close to the camera
FREE_FRAC = 0.6          # a step advancing more than this fraction of the command counts as free motion
FREE_MIN = 3             # free steps required before a stall may count as contact (reversal backlash stalls too)
STALL_STEPS = 4          # measured motion over this many steps must be < STALL_FRAC of the commanded motion
STALL_FRAC = 0.35
EXCESS_MAX = 0.008       # m lag growth since the last free step: hard stop (limits the pressing force)
BACKOFF = 0.010          # m retract between the two touches of one point
MAX_INCIDENCE = 35.0     # deg between the ray and the board normal
CENTER_MAX = 0.12        # m max lateral camera shift used to bring the ray hit into the board interior
MARGIN = 0.06            # m keep the ray hit this far inside the board edge
W_ROLL = [4, 4, 4, 1, 1, 1, 1]   # IK motion cost for the roll: keep the shoulder as still as possible

ap = argparse.ArgumentParser()
ap.add_argument("side", choices=["left", "right"])
ap.add_argument("--max", type=int, default=1)
ap.add_argument("--poses", default="")
ap.add_argument("--tip-u", type=float, required=True, help="fingertip corner pixel u")
ap.add_argument("--tip-v", type=float, required=True, help="fingertip corner pixel v")
ap.add_argument("--fx-scale", type=float, default=0.963, help="identified wrist focal / calibrated focal (AF state)")
ap.add_argument("--center", action="store_true", help="shift the camera sideways if the ray misses the board interior")
ap.add_argument("--tip-depth", type=float, default=TIP_DEPTH_GUESS, help="camera -> fingertip along the ray, m")
ap.add_argument("--rolls", default="15", help="roll magnitudes about the ray (deg), one touch point each")
ap.add_argument("--offsets", default="0:0", help="board-plane shifts dx:dy (m) from the hover hit, one point each, "
                                                 "e.g. 0:0,0.04:0,-0.04:0,0:0.04,0:-0.04")
a = ap.parse_args()
ROLLS = [float(v) for v in a.rolls.split(",")]
OFFSETS = [tuple(float(x) for x in o.split(":")) for o in a.offsets.split(",")]
side = a.side
off = 0 if side == "left" else 7

robot = Robot(BASE / "model" / "g1_d_upper_dex1_v4.urdf")
contract = {v["name"]: v for v in json.loads((BASE / "model" / "camera_contract_v5.json").read_text())["views"]}
hdr = json.loads((POSES / "scene_header_B.json").read_text())
cam = hdr["cameras"][f"{side}_wrist"]
K, dist = np.array(cam["K"]), np.array(cam["dist"])
K[0, 0] *= a.fx_scale; K[1, 1] *= a.fx_scale
T_pc = np.array(contract[f"{side}_wrist"]["T_parent_camera_world_convention"])
parent = contract[f"{side}_wrist"]["parent"]
doc = json.loads((POSES / f"poses_{side}.json").read_text())
P = {p["id"]: p for p in doc["setups"]["B_wrist_table_board"]["poses"]}
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners().astype(float)
ctx = zmq.Context.instance()
OUT = BASE / time.strftime(f"touch_auto_{side}_%Y%m%d_%H%M")
OUT.mkdir(parents=True)


def log(msg):
    print(msg, flush=True)
    with open(OUT / "log.txt", "a") as f:
        f.write(msg + "\n")


# ---------------- server client ----------------
def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.05)
    return json.loads(STATUS.read_text())


def move(arm_q, seconds=1.0, timeout=120):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds, "seq": seq}))
    os.replace(tmp, CMD)
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] == "error":
            raise RuntimeError(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith(("REJECTED", "refused")):
                raise RuntimeError(s["msg"])
            return s
        time.sleep(0.02)
    raise TimeoutError("move timeout")


def set_arm(q7, seconds=1.0):
    t = np.array(status()["arm_q_cmd"]); t[off:off + 7] = q7
    return move(t, seconds)


ROLL_OUT = 1.0 if side == "left" else -1.0    # sign of shoulder roll that swings the upper arm away from the torso
# the left upper arm hanging beside the body (shoulder pitch ~0) touched the torso at shoulder roll ~ -0.03;
# raised forward (pitch < -0.4) it passes in front of the torso
ROLL_MIN_SIDE, ROLL_MIN_FRONT, PITCH_FRONT = 0.05, -0.10, -0.4


def torso_ok(q7):
    lim = ROLL_MIN_FRONT if q7[0] < PITCH_FRONT else ROLL_MIN_SIDE
    return q7[1] * ROLL_OUT >= lim


def try_set_arm(q7, seconds, ref=None):
    """False if an IK target ('ref' given) brings the upper arm too close to the torso (not sent) or if the server
    rejected it (the arm did not move)"""
    if ref is not None and not torso_ok(q7):
        log(f"   target shoulder pitch {q7[0]:+.3f} roll {q7[1]:+.3f} rad is too close to the torso -> skip")
        return False
    try:
        set_arm(q7, seconds)
        return True
    except RuntimeError as e:
        if not str(e).startswith("REJECTED"):
            raise
        log(f"   {e} -> skip")
        return False


def move_line(q7, seconds=3.0):
    start = np.array(status()["arm_q_cmd"])
    goal = start.copy(); goal[off:off + 7] = q7
    n = max(1, int(np.ceil(np.abs(goal - start).max() / 1.5)))
    for k in range(1, n + 1):
        move(start + (goal - start) * k / n, seconds / n)


def meas_q7(avg=0.3):
    qs = []; t0 = time.time()
    while time.time() - t0 < avg:
        qs.append(status()["arm_q"]); time.sleep(0.02)
    return np.mean(qs, axis=0)[off:off + 7]


# ---------------- kinematics ----------------
def q_full(q7):
    q = np.zeros(14); q[off:off + 7] = q7
    return {n: np.array([v]) for n, v in zip(ALLJ, q)}


def T_cam(q7):
    return robot.fk(parent, q_full(q7), {}, None, 1)[0] @ T_pc       # camworld frame (+X fwd)


def jac_cam(q7, eps=1e-4):
    """6x7 Jacobian of the camera pose (translation in torso, rotation vector in torso)"""
    T0 = T_cam(q7); Jm = np.zeros((6, 7))
    for j in range(7):
        dq = q7.copy(); dq[j] += eps
        T1 = T_cam(dq)
        Jm[:3, j] = (T1[:3, 3] - T0[:3, 3]) / eps
        Jm[3:, j] = Rotation.from_matrix(T1[:3, :3] @ T0[:3, :3].T).as_rotvec() / eps
    return Jm


def cart_target(q7, dpos, drot, about=None, w=None):
    """joint target that moves the camera by dpos (torso) and rotates it by rotvec drot about point 'about';
    w: optional per-joint motion cost (weighted least-norm), e.g. to keep the shoulder still"""
    q = q7.copy()
    T0 = T_cam(q7)
    p_goal = T0[:3, 3] + dpos
    if about is not None:
        R = Rotation.from_rotvec(drot).as_matrix()
        p_goal = about + R @ (T0[:3, 3] - about) + dpos
    R_goal = Rotation.from_rotvec(drot).as_matrix() @ T0[:3, :3]
    Wi = np.diag(1.0 / np.asarray(w if w is not None else np.ones(7), float))
    for _ in range(60):
        T = T_cam(q)
        e = np.concatenate([p_goal - T[:3, 3], Rotation.from_matrix(R_goal @ T[:3, :3].T).as_rotvec()])
        if np.linalg.norm(e[:3]) < 2e-4 and np.linalg.norm(e[3:]) < 1e-3:
            return q
        Jm = jac_cam(q)
        q = q + Wi @ Jm.T @ np.linalg.solve(Jm @ Wi @ Jm.T + 1e-4 * np.eye(6), e) * 0.8
    T = T_cam(q)
    e = np.concatenate([p_goal - T[:3, 3], Rotation.from_matrix(R_goal @ T[:3, :3].T).as_rotvec()])
    if np.linalg.norm(e[:3]) > 2e-3 or np.linalg.norm(e[3:]) > np.radians(0.5):
        raise IKFail(f"IK did not converge: {np.linalg.norm(e[:3]) * 1000:.1f} mm, "
                     f"{np.degrees(np.linalg.norm(e[3:])):.2f} deg")
    return q


class IKFail(Exception):
    pass


def safe_cart(q7, dpos, drot=np.zeros(3), **kw):
    """cart_target or None (logged) if the IK did not converge"""
    try:
        return cart_target(q7, dpos, drot, **kw)
    except IKFail as e:
        log(f"   {e}")
        return None


# ---------------- vision ----------------
def grab(n=3):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://127.0.0.1:{WRIST_PORT[side]}")
    s.recv(); s.recv()
    imgs = [cv2.imdecode(np.frombuffer(s.recv(), np.uint8), cv2.IMREAD_COLOR) for _ in range(n)]
    s.close(0)
    return imgs


def board_in_cam(img):
    """board pose in the camworld frame of the camera, or None"""
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(g)
    if ci is None or len(ci) < 8:
        return None, 0
    imgp = ((cc.reshape(-1, 2) + 0.5) / 2 - 0.5).astype(np.float64)
    ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()], imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
    T = np.eye(4); T[:3, :3] = cv2.Rodrigues(rv)[0]; T[:3, 3] = tv.ravel()
    C2O = np.eye(4); C2O[:3, :3] = OPTICAL_FROM_CAMERA.T
    return C2O @ T, len(ci)                # board -> camworld


def tip_ray_cam():
    d = cv2.undistortPoints(np.array([[[a.tip_u, a.tip_v]]], np.float64), K, dist).ravel()
    v = OPTICAL_FROM_CAMERA.T @ np.array([d[0], d[1], 1.0])
    return v / np.linalg.norm(v)


def ray_board_hit(T_cb, ray_c):
    """intersection of the camera ray with the board plane: (distance along ray, board-frame xy)"""
    n = T_cb[:3, 2]; p0 = T_cb[:3, 3]
    s = (p0 @ n) / (ray_c @ n)
    X = s * ray_c
    xb = T_cb[:3, :3].T @ (X - p0)
    return s, xb[:2]


# ---------------- one touch ----------------
def q_cmd7():
    return np.array(status()["arm_q_cmd"])[off:off + 7]


def inside(xy):
    return MARGIN < xy[0] < 0.40 - MARGIN and MARGIN < xy[1] < 0.28 - MARGIN


def look(tag):
    """board pose seen now -> (T_cb, ray hit distance, ray hit board xy, incidence deg) or None"""
    img = grab(1)[0]
    T_cb, n = board_in_cam(img)
    if T_cb is None:
        f = OUT / f"nodetect_{tag}_{time.strftime('%H%M%S')}.png"
        cv2.imwrite(str(f), img)
        log(f"   {tag}: board not detected ({n} corners), frame saved {f.name}")
        return None
    ray_c = tip_ray_cam()
    D, xy = ray_board_hit(T_cb, ray_c)
    inc = float(np.degrees(np.arccos(abs(ray_c @ T_cb[:3, 2]))))
    log(f"   {tag}: {n} corners, ray hit {np.round(xy, 3).tolist()} m, D {D:.3f} m, incidence {inc:.1f} deg")
    return T_cb, D, xy, inc


def approach(qc, ray_t, max_travel, tag):
    """1.5 mm commanded steps along ray_t from the commanded pose qc
    -> (contact, last command, lag, history [(cmd travel, measured travel, measured q7), ...])"""
    q0 = meas_q7(0.2)
    p0 = T_cam(q0)[:3, 3]
    hist = [(0.0, 0.0, q0.tolist())]
    travelled, lag, n_free, lag_free = 0.0, 0.0, 0, 0.0
    q_start = qc.copy()
    while travelled < max_travel:
        q_next = safe_cart(qc, STEP * ray_t)
        if q_next is None or not try_set_arm(q_next, 0.5, ref=q_start):
            return False, qc, lag, hist
        qc = q_next
        time.sleep(0.35)
        travelled += STEP
        qm = meas_q7(0.15)
        m = float((T_cam(qm)[:3, 3] - p0) @ ray_t)
        dm = m - hist[-1][1]
        hist.append((travelled, m, qm.tolist()))
        lag = travelled - m
        if dm > FREE_FRAC * STEP:
            n_free += 1
        # contact: the last STALL_STEPS advance less than STALL_FRAC of the command, or less than 0.55 x the
        # average advance ratio before them (soft / sliding contacts still creep ~40-50%);
        # force guard reference = lag at the last window that was clearly free (single fast steps do not reset it)
        stalled = False
        if len(hist) > STALL_STEPS:
            c0, m0 = hist[-1 - STALL_STEPS][:2]
            recent = (m - m0) / (STALL_STEPS * STEP)
            avg = m0 / c0 if c0 > 0 else 1.0
            if recent >= 0.8 * avg:
                lag_free = lag
            stalled = n_free >= FREE_MIN and (recent < STALL_FRAC or recent < 0.55 * avg)
        elif dm > FREE_FRAC * STEP:
            lag_free = lag
        log(f"     {tag} cmd {travelled * 1000:5.1f}  meas {m * 1000:5.1f}  step {dm * 1000:4.1f}  lag {lag * 1000:4.1f} mm"
            f"{'  CONTACT' if stalled else ''}")
        if stalled:
            return True, qc, lag, hist
        if lag - lag_free >= EXCESS_MAX:
            log(f"     lag grew {(lag - lag_free) * 1000:.1f} mm without a clean stall -> stop, not a clean contact")
            return False, qc, lag, hist
    return False, qc, lag, hist


def record_contact(pid, k, lag, hist, p_ref, ray_t):
    q_c = meas_q7(0.5)
    imgs = grab(3)
    for i, im in enumerate(imgs):
        cv2.imwrite(str(OUT / f"{pid}_c{k}_{i}.png"), im)
    pts = [contact_point(im, (a.tip_u, a.tip_v), K, dist) for im in imgs]
    pts = [p for p in pts if p is not None]
    hit = None
    if pts:
        xy = np.median([p[0] for p in pts], axis=0)
        hit = {"board_xy_m": xy.tolist(), "n_markers": int(min(p[1] for p in pts)),
               "homography_rms_mm": float(max(p[2] for p in pts)),
               "spread_mm": float(np.ptp([p[0] for p in pts], axis=0).max() * 1000)}
    s = status()
    depth = float((T_cam(q_c)[:3, 3] - p_ref) @ ray_t)
    log(f"   CONTACT {k}: lag {lag * 1000:.1f} mm, camera travelled {depth * 1000:.1f} mm from the rolled view, "
        f"board point {None if hit is None else np.round(hit['board_xy_m'], 4).tolist()} m "
        f"({0 if hit is None else hit['n_markers']} markers)")
    return {"arm_q_full": s["arm_q"], "arm_q_cmd_full": s["arm_q_cmd"], "arm_q7": q_c.tolist(), "lag_m": lag,
            "cam_pos_torso": T_cam(q_c)[:3, 3].tolist(), "travel_from_rolled_m": depth, "contact": hit,
            "history": hist}


def touch_from_hover(pid, tip_depth, stack):
    """everything between arriving at the hover and leaving it; joint targets visited are pushed on 'stack'
    so that the caller can retrace them back to the hover"""
    time.sleep(1.0)
    v = look("hover")
    if v is None:
        return None
    T_cb, D, xy, inc = v
    if inc > MAX_INCIDENCE or not (0.08 < D < 0.6):
        log("   incidence / distance out of range -> skip"); return None
    if not inside(xy):
        tgt = np.clip(xy, MARGIN + 0.02, [0.38 - MARGIN, 0.26 - MARGIN])
        dc = T_cb[:3, :3] @ np.array([tgt[0] - xy[0], tgt[1] - xy[1], 0.0])     # camworld
        if not a.center or np.linalg.norm(dc) > CENTER_MAX:
            log(f"   ray misses the board interior by {np.linalg.norm(dc) * 100:.1f} cm -> skip"); return None
        Tm = T_cam(meas_q7())
        q_s = safe_cart(q_cmd7(), Tm[:3, :3] @ dc)
        log(f"   centering: camera shift {np.linalg.norm(dc) * 100:.1f} cm parallel to the board")
        if q_s is None or not try_set_arm(q_s, 3.0, ref=q_cmd7()):
            return None
        stack.append(q_s)
        time.sleep(1.0)
        v = look("centered")
        if v is None or not inside(v[2]):
            log("   still outside the interior -> skip"); return None
        T_cb, D, xy, inc = v
    # roll about the ray through the camera centre (the fingertip corner and the board hit stay on the ray);
    # the sign makes the camera-left fingertip corner lead, every roll magnitude uses the same sign
    Tm = T_cam(meas_q7()); ray_c = tip_ray_cam()
    ray_t = Tm[:3, :3] @ ray_c
    n_t = Tm[:3, :3] @ T_cb[:3, 2]
    edge_t = Tm[:3, :3] @ np.array([0.0, 1.0, 0.0])        # camworld +Y (image left) ~ fingertip edge direction
    sgn = 1.0 if (np.cross(ray_t, edge_t) @ n_t) > 0 else -1.0
    q_base = q_cmd7()
    recs = []
    for k, (ox, oy) in enumerate(OFFSETS):
        q_o = q_base
        if ox or oy:
            if not inside(xy + np.array([ox, oy])):
                log(f"   offset {k} ({ox:+.2f}, {oy:+.2f}) m would leave the board interior -> skip"); continue
            d_t = Tm[:3, :3] @ (T_cb[:3, :3] @ np.array([ox, oy, 0.0]))      # board-plane shift in torso
            q_o = safe_cart(q_base, d_t)
            log(f"   offset {k}: camera shift ({ox:+.2f}, {oy:+.2f}) m parallel to the board")
            if q_o is None or not try_set_arm(q_o, 2.0, ref=q_base):
                continue
            time.sleep(0.8)
        for roll in ROLLS:
            sub = []
            rec = touch_rolled(f"{pid}_o{k}", pid, sgn * roll, q_o, ray_t, tip_depth, sub)
            for q in reversed(sub):
                set_arm(q, 2.0)
            set_arm(q_o, 2.0)
            if rec is not None:
                rec["offset_m"] = [ox, oy]
                recs.append(rec)
                tip_depth = rec["tip_depth_m"]
        if q_o is not q_base:
            set_arm(q_base, 2.0)
    return recs


def touch_rolled(tag, pid, roll_deg, q_base, ray_t, tip_depth, stack):
    """roll by roll_deg about the ray through the camera centre (the fingertip stays on the ray, its distance to the
    board does not change) from the commanded base pose, touch twice; visited targets go on 'stack'"""
    ray_c = tip_ray_cam()
    tag = f"{tag}_r{abs(roll_deg):.0f}"
    q_r = safe_cart(q_base, np.zeros(3), np.radians(roll_deg) * ray_t, about=T_cam(q_base)[:3, 3], w=W_ROLL)
    if q_r is None:
        return None
    log(f"   roll {roll_deg:+.0f} deg about the ray (joint change {np.round(q_r - q_base, 3).tolist()})")
    if not try_set_arm(q_r, 2.0, ref=q_base):
        return None
    stack.append(q_r)
    time.sleep(1.0)
    v = look("rolled")
    if v is None or not inside(v[2]) or v[3] > MAX_INCIDENCE:
        log("   rolled view not usable -> skip"); return None
    T_cb, D, xy, inc = v
    q_m = meas_q7()
    ray_t = T_cam(q_m)[:3, :3] @ ray_c
    p_ref = T_cam(q_m)[:3, 3]
    # fast approach to PRE_MARGIN before the predicted contact, then steps
    pre = max(0.0, D - tip_depth - PRE_MARGIN)
    q_pre = safe_cart(q_r, pre * ray_t)
    log(f"   fast approach {pre * 1000:.0f} mm (tip depth guess {tip_depth:.3f} m)")
    if q_pre is None or not try_set_arm(q_pre, 2.0, ref=q_r):
        return None
    stack.append(q_pre)
    time.sleep(0.6)

    def retract(qc, lag):
        # along the ray if the IK converges, otherwise straight back to q_pre (= the approach path reversed)
        q_back = safe_cart(qc, -(lag + 0.04) * ray_t)
        stack.append(q_back if q_back is not None else q_pre)

    ok, qc, lag, hist = approach(q_pre, ray_t, D - TIP_DEPTH_MIN - pre, "A")
    if not ok:
        log("   no contact -> back along the ray, skip")
        retract(qc, lag)
        return None
    rec = {"pose": pid, "roll_deg": roll_deg, "tip_pixel": [a.tip_u, a.tip_v], "fx_scale": a.fx_scale,
           "rolled_view": {"D_m": float(D), "board_xy_m": xy.tolist(), "incidence_deg": inc,
                           "cam_pos_torso": p_ref.tolist(), "ray_torso": ray_t.tolist()},
           "touches": [record_contact(tag, 1, lag, hist, p_ref, ray_t)], "t": time.time()}
    rec["tip_depth_m"] = float(D - rec["touches"][0]["travel_from_rolled_m"])
    # back off BACKOFF and touch the same point again
    q_b = safe_cart(qc, -(lag + BACKOFF) * ray_t)
    if q_b is None:
        log("   back-off IK failed -> no second touch")
        rec["repeat_mm"] = None
        retract(qc, lag)
        return rec
    set_arm(q_b, 1.0)
    time.sleep(0.6)
    ok2, qc, lag, hist = approach(q_b, ray_t, lag + BACKOFF + 0.010, "B")
    if ok2:
        rec["touches"].append(record_contact(tag, 2, lag, hist, p_ref, ray_t))
        t1, t2 = rec["touches"]
        rec["repeat_mm"] = float(np.linalg.norm(np.subtract(t2["cam_pos_torso"], t1["cam_pos_torso"])) * 1000)
        msg = f"   repeat: camera at contact 1 vs 2 differs {rec['repeat_mm']:.2f} mm"
        if t1["contact"] and t2["contact"]:
            msg += (f", board point differs "
                    f"{np.linalg.norm(np.subtract(t2['contact']['board_xy_m'], t1['contact']['board_xy_m'])) * 1000:.2f} mm")
        log(msg)
    else:
        log("   second touch found no contact -> first contact is suspect")
        rec["repeat_mm"] = None
    retract(qc, lag)
    return rec


def touch(pid, tip_depth):
    q_h = np.array([P[pid]["joints"][f"{side}_{j}_joint"] for j in ARM])
    log(f"== {pid}: home -> hover")
    move_line(q_h, P[pid]["move_duration_s"])
    stack = []
    recs = touch_from_hover(pid, tip_depth, stack) or []
    for q in reversed(stack):
        set_arm(q, 2.0)
    log("   hover -> home")
    move_line(q_h, 2.0)
    move_line(home, P[pid]["move_duration_s"])
    return recs


st0 = status()
if st0["state"] != "idle" or np.abs(np.array(st0["arm_q"])[off:off + 7] - home).max() > 0.1:
    sys.exit("abort: server not idle or arm not at home")
order = a.poses.split(",") if a.poses else [p["id"] for p in doc["setups"]["B_wrist_table_board"]["poses"]
                                            if p.get("home_path_ok") and not p.get("skip")]
bad = [pid for pid in order if pid not in P or not P[pid].get("home_path_ok") or P[pid].get("skip")]
if bad:
    sys.exit(f"abort: poses without a checked home path: {bad}")
tip_depth = a.tip_depth
recs = []
try:
    for pid in order:
        if len(recs) >= a.max:
            break
        for r in touch(pid, tip_depth):
            recs.append(r)
            tip_depth = r["tip_depth_m"]
            with open(OUT / "touches.jsonl", "a") as f:
                f.write(json.dumps(r) + "\n")
except Exception as e:
    # no automatic recovery motion: the arm may be next to the board; the server keeps holding it
    log(f"ABORT: {e}\n   arm left holding where it is; operator decides the next step")
    log(f"DONE {len(recs)} touches -> {OUT}")
    sys.exit(3)
log(f"DONE {len(recs)} touches -> {OUT}")
