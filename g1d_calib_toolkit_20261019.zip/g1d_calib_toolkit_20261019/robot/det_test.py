# det_test.py -- how many ChArUco corners are found in contact images, with/without 2x upscale
import sys

import cv2

board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
for up in (1, 2):
    for refine in (False, True):
        dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
        cp = cv2.aruco.CharucoParameters()
        if refine:
            dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
            cp.tryRefineMarkers = True
        det = cv2.aruco.CharucoDetector(board, cp, dp)
        for f in sys.argv[1:]:
            g = cv2.cvtColor(cv2.imread(f), cv2.COLOR_BGR2GRAY)
            if up == 2:
                g = cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
            cc, ci, mc, mi = det.detectBoard(g)
            print(f"up{up} refine={refine} {f.split('/')[-1]}: markers {0 if mi is None else len(mi)} "
                  f"corners {0 if ci is None else len(ci)}")
