# repeat_analyze.py -- analyse a repeat_test run: for every capture vs the pose's first capture (A1/t0), fit
#   x' - c = s * R(theta) * (x - c) + t   on undistorted ChArUco corners (c = principal point)
# scale s -> autofocus-like;  t / theta -> mechanical (backlash / play);  residual -> unexplained
# usage: python repeat_analyze.py <repeat_dir>
import json
import sys
from pathlib import Path

import cv2
import numpy as np

d = Path(sys.argv[1])
rep = json.loads((d / "repeat.json").read_text())
side = rep["side"]
hdr = json.loads((Path.home() / "calib_sessions" / "poses_20261019" / "scene_header_B.json").read_text())
cam = hdr["cameras"][f"{side}_wrist"]
K, dist = np.array(cam["K"]), np.array(cam["dist"])
c = K[:2, 2]
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)


def corners(files):
    """median over the 5 frames of undistorted corner pixels; also frame-to-frame jitter"""
    per = []
    for fn in files:
        g = cv2.imread(str(d / fn), cv2.IMREAD_GRAYSCALE)
        big = cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
        cc, ci, _, _ = det.detectBoard(big)
        if ci is None:
            continue
        uv = (cc.reshape(-1, 2) + 0.5) / 2 - 0.5
        und = cv2.undistortPoints(uv.reshape(-1, 1, 2).astype(np.float64), K, dist, P=K).reshape(-1, 2)
        per.append({int(i): p for i, p in zip(ci.ravel(), und)})
    ids = [i for i in set().union(*[set(p) for p in per]) if sum(i in p for p in per) >= 3] if per else []
    med = {i: np.median([p[i] for p in per if i in p], axis=0) for i in ids}
    jit = np.median([np.linalg.norm(np.std([p[i] for p in per if i in p], axis=0)) for i in ids]) if ids else np.nan
    return med, float(jit)


def fit_similarity(a, b):
    """b - c = s R (a - c) + t ; returns s, theta(deg), t(px), rms residual(px)"""
    A = a - c; B = b - c
    n = len(A)
    M = np.zeros((2 * n, 4)); y = B.reshape(-1)
    M[0::2] = np.column_stack([A[:, 0], -A[:, 1], np.ones(n), np.zeros(n)])
    M[1::2] = np.column_stack([A[:, 1], A[:, 0], np.zeros(n), np.ones(n)])
    p, *_ = np.linalg.lstsq(M, y, rcond=None)
    s = float(np.hypot(p[0], p[1])); th = float(np.degrees(np.arctan2(p[1], p[0])))
    res = (M @ p - y).reshape(-1, 2)
    return s, th, p[2:], float(np.sqrt(np.mean(np.sum(res ** 2, 1))))


groups = {}
for r in rep["records"]:
    groups.setdefault(r["pose"], []).append(r)
print(f"{'pose':11s} {'visit':5s} {'ph':3s} {'n':>3s} {'jit':>5s} {'max|dq|':>8s} {'raw_rms':>7s} "
      f"{'scale%':>7s} {'rot_deg':>7s} {'tx':>6s} {'ty':>6s} {'res':>5s}")
summary = []
for pose, rs in groups.items():
    ref, _ = corners(rs[0]["files"])
    q_ref = np.array(rs[0]["q_before"])
    for r in rs:
        cur, jit = corners(r["files"])
        ids = sorted(set(ref) & set(cur))
        dq = np.abs(np.array(r["q_before"]) - q_ref).max()
        if len(ids) < 8:
            print(f"{pose:11s} {r['visit']:5s} {r['phase']:3s} {len(ids):3d}  too few common corners"); continue
        a_ = np.array([ref[i] for i in ids]); b_ = np.array([cur[i] for i in ids])
        raw = float(np.sqrt(np.mean(np.sum((b_ - a_) ** 2, 1))))
        s, th, t, res = fit_similarity(a_, b_)
        summary.append((pose, r["visit"], r["phase"], raw, (s - 1) * 100, th, np.hypot(*t), res, dq))
        print(f"{pose:11s} {r['visit']:5s} {r['phase']:3s} {len(ids):3d} {jit:5.2f} {dq:8.4f} {raw:7.2f} "
              f"{(s - 1) * 100:7.3f} {th:7.3f} {t[0]:6.2f} {t[1]:6.2f} {res:5.2f}")
S = np.array([x[3:] for x in summary if not (x[1] == "A1" and x[2] == "t0")], float)
if len(S):
    print("\nover all non-reference captures:")
    print(f"  raw corner change   median {np.median(S[:, 0]):.2f} px, max {S[:, 0].max():.2f} px")
    print(f"  scale change        median |{np.median(np.abs(S[:, 1])):.3f}| %, max |{np.abs(S[:, 1]).max():.3f}| %")
    print(f"  translation         median {np.median(S[:, 3]):.2f} px, max {S[:, 3].max():.2f} px")
    print(f"  residual after fit  median {np.median(S[:, 4]):.2f} px")
    print(f"  encoder max |dq|    median {np.median(S[:, 5]):.4f} rad, max {S[:, 5].max():.4f} rad")
