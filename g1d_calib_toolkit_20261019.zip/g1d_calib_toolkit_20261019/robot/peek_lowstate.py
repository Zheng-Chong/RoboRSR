# peek_lowstate.py -- read-only: is rt/lowstate publishing? print mode and arm joint positions
import time
import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_ as hg_LowState

ChannelFactoryInitialize(0, "eth0")
sub = ChannelSubscriber("rt/lowstate", hg_LowState)
sub.Init()
t0, n, last = time.time(), 0, None
while time.time() - t0 < 3.0:
    m = sub.Read(500)
    if m is not None:
        n += 1; last = m
if last is None:
    print("NO_LOWSTATE (debug mode not enabled?)")
else:
    q = np.array([last.motor_state[i].q for i in range(35)])
    print(f"lowstate {n / 3.0:.0f} Hz, mode_machine={last.mode_machine}")
    print("left  arm q:", np.round(q[15:22], 3).tolist())
    print("right arm q:", np.round(q[22:29], 3).tolist())
