# recover.py -- after a latched tracking error: reset, then IMMEDIATELY command <side> back to a pose-table pose and
# the other arm back to home (reset alone re-holds the sagged measured pose and both arms sink one more sag)
# usage: python -u recover.py <left|right> <POSE_ID> [--dry]
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

POSES = Path.home() / "calib_sessions" / "poses_20261019"
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
TOL_SIDE, TOL_OTHER = 0.4, 0.15
side, pid = sys.argv[1], sys.argv[2]
off = 0 if side == "left" else 7
other = 7 - off
doc = json.loads((POSES / f"poses_{side}.json").read_text())
pose = next(p for p in doc["setups"]["B_wrist_table_board"]["poses"] if p["id"] == pid)
q_pose = np.array([pose["joints"][f"{side}_{j}_joint"] for j in ARM])


def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.05)
    return json.loads(STATUS.read_text())


def send(c):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(dict(c, seq=seq)))
    os.replace(tmp, CMD)
    return seq


def wait(seq, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["seq_done"] >= seq and s["state"] in ("idle", "error"):
            return s
        time.sleep(0.01)
    sys.exit("timeout")


s = status()
q = np.array(s["arm_q"])
d_side = np.abs(q[off:off + 7] - q_pose)
d_other = np.abs(q[other:other + 7])
print(f"state {s['state']}; {side} offsets from {pid}: {np.round(q[off:off + 7] - q_pose, 3).tolist()}")
print(f"other arm offsets from home: {np.round(q[other:other + 7], 3).tolist()}")
if d_side.max() > TOL_SIDE or d_other.max() > TOL_OTHER:
    sys.exit("abort: too far from the recovery targets; operator decides")
if "--dry" in sys.argv:
    sys.exit(0)
tgt = np.zeros(14); tgt[off:off + 7] = q_pose
if s["state"] == "error":
    r = wait(send({"cmd": "reset"}), 5)
    print("reset:", r["msg"])
r = wait(send({"cmd": "move", "arm_q": tgt.tolist(), "seconds": 6.0}))
print("move:", r["state"], r["msg"])
time.sleep(1.0)
print("now:", np.round(np.array(status()["arm_q"]), 3).tolist())
