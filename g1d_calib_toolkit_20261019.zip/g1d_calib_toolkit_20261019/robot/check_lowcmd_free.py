# check_lowcmd_free.py — 独立进程检查：rt/lowcmd 是否已有写入者（有=别的控制者在线）
# 退出码: 0=空闲, 3=有写入者, 2=异常
import os
import sys
import time

os.environ["CYCLONEDDS_URI"] = (
    '<CycloneDDS><Domain Id="any"><General><Interfaces>'
    '<NetworkInterface name="eth0" priority="default" multicast="default"/>'
    '</Interfaces></General></Domain></CycloneDDS>')

from cyclonedds.builtin import BuiltinDataReader, BuiltinTopicDcpsPublication
from cyclonedds.domain import DomainParticipant

dp = DomainParticipant(0)
bp = BuiltinDataReader(dp, BuiltinTopicDcpsPublication)
time.sleep(2.5)
writers = [w for w in bp.read() if getattr(w, "topic_name", "") == "rt/lowcmd"]
if writers:
    print("BUSY: rt/lowcmd 已有 %d 个写入者" % len(writers))
    sys.exit(3)
print("FREE: rt/lowcmd 无写入者")
sys.exit(0)
