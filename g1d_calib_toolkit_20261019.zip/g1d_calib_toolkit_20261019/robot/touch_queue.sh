#!/bin/bash
# touch_queue.sh -- background queue of auto_touch.py runs (left arm); stops on the first abort or if STOP_TOUCH exists
# start: setsid nohup bash ~/calib_sessions/touch_queue.sh > /dev/null 2>&1 < /dev/null &
cd /home/unitree/calib_sessions || exit 1
PY=/home/unitree/miniconda3/envs/tv/bin/python
LOG=/home/unitree/calib_sessions/touch_queue.log
COMMON="left --tip-u 309 --tip-v 255 --tip-depth 0.100"
echo "=== queue start $(date '+%F %T')" >> $LOG
run() {
    [ -f STOP_TOUCH ] && { echo "=== STOP_TOUCH present, queue stopped $(date '+%T')" >> $LOG; exit 0; }
    echo "=== run: $* ($(date '+%T'))" >> $LOG
    $PY -u auto_touch.py $COMMON "$@" >> $LOG 2>&1
    rc=$?
    [ $rc -ne 0 ] && { echo "=== run exited $rc, queue stopped $(date '+%T')" >> $LOG; exit $rc; }
    sleep 61
}
run --rolls 15 --offsets 0.04:0,-0.04:0,0:0.04,0:-0.04 --max 25 \
    --poses B_left_013,B_left_033,B_left_034,B_left_036
echo "=== queue done $(date '+%T')" >> $LOG
