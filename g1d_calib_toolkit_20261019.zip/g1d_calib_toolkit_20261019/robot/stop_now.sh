#!/bin/bash
# stop_now.sh -- stop the touch queue / auto_touch and send 'stop' to the arm server (holds the current command)
pkill -f '[t]ouch_queue.sh'
pkill -f '[a]uto_touch.py'
S=$(date +%s%3N)
echo "{\"cmd\": \"stop\", \"seq\": $S}" > /tmp/g1d_calib/cmd.json.tmp && mv /tmp/g1d_calib/cmd.json.tmp /tmp/g1d_calib/cmd.json
sleep 1
date '+%T'
cut -c1-220 /tmp/g1d_calib/status.json; echo
grep -v '^     [AB] cmd' /home/unitree/calib_sessions/touch_queue.log | tail -n 5
